# PM Readiness Note — Symphony Follow-up P1

**Status**: PRE-DRAFT (等 Codex/监护人创建 sprint 合约后由 PM finalize 为正式 product brief)
**Predecessor**: sprint-20260507-010946 (status=passed, 2026-05-07T02:28Z)
**Author**: PM
**Created**: 2026-05-07

## 触发原因

010946 PASS 附条件:
- D6 runner.sh 的 `CLAUDECODE` guard 在 Claude Code 环境内会让 `--dry-run` exit 1 — 设计正确但环境冲突, **P1 接真实执行前必修**
- 010946 Not Done 列表显式留下: P1 Linear API / P1 真实 Codex app-server / P2 PR landing

## 推荐 P1 Sprint 范围 (按优先级)

| # | 主题 | 必须 / 可选 | 备注 |
|---|------|-----------|------|
| 1 | 修复 D6 `CLAUDECODE` guard 环境冲突 | **必须** | 阻塞所有真实执行路径 |
| 2 | Issue Adapter 接 Linear API (replace stub) | 必须 | Symphony SPEC 第一公里 |
| 3 | Runner 接真实 Codex app-server (`--unsafe-run-codex` → safe path) | 必须 | dry-run 已通, 现在要真跑 |
| 4 | Scheduler retry/backoff 接 watchdog 信号 | 可选 | 监护人原始痛点之一 |
| 5 | Workspace 隔离 + Toshiba root 路径开关 | 可选 | 已在 P0 实现, P1 加固 |

## 预定 Acceptance Criteria 雏形 (待合约对齐)

- A1. **D6 修复**: runner.sh 在 Claude Code 嵌套环境内 `--dry-run` exit 0; guard 不丢失 (真实执行路径仍能拦截误启动)
- A2. **Linear API**: issue-adapter `--source linear` 真打 Linear, 至少返回 1 条真 issue (含 identifier/title/state/url); 凭据从 `~/.solar/secrets/linear.token` 读取
- A3. **真实 Codex 执行**: runner.sh `--run-codex` (改名去 unsafe) 能启动一次真 Codex app-server 跑完一个 minimal sprint, proof artifacts 含真 stdout/stderr (≥100 行) + exit_code 落盘
- A4. **Scheduler 接 watchdog**: 当 watchdog 上报 `sprint_interrupted`, scheduler 将其推入 retry 队列, retry_count=1, backoff=300s
- A5. **No regression**: 010946 P0 dry-run 路径仍 100% 可用 (跑 4/4 测试)
- A6. **Handoff**: 含 D1-D5 验证证据 + Risks (真实 Codex 调用费用 / Linear rate limit / watchdog 信号竞态)

## Non-Goals (P1)

- ❌ 自动创建 / 合并 PR (留给 P2)
- ❌ Web UI / Dashboard
- ❌ 多机器 SSH worker
- ❌ 替换 coordinator (本仍为增量)
- ❌ 改 010946 已交付的 ADR / WORKFLOW 模板 (除非 D6 修复必须改)

## Stop Rules (建议)

- **S1**: 真实 Codex 调用费用累计 > $5 → 暂停, 上报监护人
- **S2**: builder ↔ evaluator round ≥ 3 仍未通过 → 拆解, 把 D6 单独成 patch sprint, 主 P1 sprint 退到 D6 后续
- **S3**: Linear API 无访问权 (token 缺失) → A2 降级为可选, 用 stub fixture 跑 contract test, 主线不阻塞
- **S4**: P0 dry-run 路径任何回归 → 立即停, 不接受任何换名/改路径破坏 backward compat

## Lane / Priority 建议

- **Priority**: P1 (010946 留下的 Known Issues, 不阻塞当前生产但阻塞 Symphony 真实落地)
- **Lane**: delivery (是 P0 的直接续作, 非实验/架构)
- **Handoff To**: planner

## PM Readiness 状态

- ✅ 预稿 acceptance criteria 已就绪 (6 条)
- ✅ Non-goals + stop rules 已划定
- ✅ Lane/priority 已建议
- ⏳ 等 Codex 桥或监护人创建 `sprint-<id>.contract.md` + `status.json`
- ⏳ 合约创建后 PM 在 ≤10 分钟内可 finalize 正式 brief 到 sprint 目录

## 触发路径 (建议监护人或 codex 执行)

任选其一启动 P1:
1. **Codex 桥推合约** (推荐): codex-app-server 自动从 010946 Not Done 推一份 P1 contract
2. **监护人手推**: `solar-harness sprint-create --title "Symphony P1 Follow-up: D6 fix + Linear + Real Codex" --priority P1 --lane delivery`
3. **Coordinator 自动**: 若有 chain rule 配置 010946 PASS → P1 auto-create

不论哪条路径, 一旦 sprint 出现在 drafting, PM 立即接 dispatch finalize brief。
