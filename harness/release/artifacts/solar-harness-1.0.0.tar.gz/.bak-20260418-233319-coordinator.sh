#!/bin/bash
# ================================================================
# Solar Harness — 协调器 (Coordinator)
#
# 监听 sprint status 变化，自动向对应 pane 派发任务
# 实现: 用户只在规划者输入需求，剩下全自动
#
# 架构:
#   规划者 → 写合约 → status=active
#                         ↓ (协调器检测)
#               tmux send-keys → 建设者 pane
#                         ↓
#           建设者实现 → status=reviewing
#                         ↓ (协调器检测)
#               tmux send-keys → 审判官 pane
#                         ↓
#           审判官评审 → status=passed/failed
#                         ↓ (协调器检测)
#               PASS → 完成 / FAIL → 打回建设者
#
# @module solar-farm/harness
# ================================================================
# ┌─ Bug 修复记录 ────────────────────────────────────────────
# │ D1 send-keys拆两步+sleep0.8 | 2026-04-17 | sprint-20260417-213037
# │   根因: Claude Code CLI 吞连发 text+Enter
# │ D2 mtime文件级检测           | 2026-04-17 | sprint-20260417-213037
# │   根因: macOS APFS 改文件内容不更新目录 mtime
# │ D3 pane忙检测+120s超时       | 2026-04-17 | sprint-20260417-213037
# │   根因: 目标 pane 忙碌时 tmux send-keys 被吞
# │ D4 stderr全局捕获+会话分隔符 | 2026-04-17 | sprint-20260417-213037
# │   根因: 子进程/异常 stderr 丢失
# │ D9 handle_passed/failed 调用 self-evolve-postmortem.sh
# │   根因: eval 改进建议无自动收集闭环
# │ D10 启动自愈 pending-patches.jsonl
# │   根因: 手动 patch 遗漏
# └───────────────────────────────────────────────────────────

HARNESS_DIR="$HOME/.solar/harness"
SPRINTS_DIR="$HARNESS_DIR/sprints"
SESSION_NAME="solar-harness"
COORD_STATE="$HARNESS_DIR/.coordinator-state"
SESSION_SH="$HARNESS_DIR/session.sh"

# Pane 编号: 0=左上(规划者) 1=右上(建设者) 2=左下(审判官) 3=右下(监控)
PANE_PLANNER="$SESSION_NAME:0.0"
PANE_BUILDER="$SESSION_NAME:0.1"
PANE_EVALUATOR="$SESSION_NAME:0.2"

G='\033[0;32m'; Y='\033[1;33m'; R='\033[0;31m'; C='\033[0;36m'; N='\033[0m'

# ── D4: stderr 全局捕获 (Sprint sprint-20260417-213037, 2026-04-17) ──
# 根因: 子进程/异常 stderr 丢失, 重启后无法排查
# 修复: exec 重定向所有 stderr 到日志文件
COORD_LOG="$HARNESS_DIR/.coordinator.log"
exec 2>>"$COORD_LOG"

log() { echo -e "${C}[协调器]${N} $(date '+%H:%M:%S') $*" >&2; }

# 获取活跃 sprint (优先级: 非终态 > 最新修改时间)
get_latest_sprint_file() {
  local best=""
  local best_mtime=0

  for f in "$SPRINTS_DIR"/*.status.json; do
    [[ -f "$f" ]] || continue
    local st
    st=$(python3 -c "import json; print(json.load(open('$f')).get('status',''))" 2>/dev/null)

    # 跳过终态 sprint (已完成/已失败)
    case "$st" in
      passed|done|failed|eval_pass) continue ;;
    esac

    # 取修改时间最新的活跃 sprint
    local mtime
    mtime=$(stat -f %m "$f" 2>/dev/null || stat -c %Y "$f" 2>/dev/null || echo 0)
    if [[ "$mtime" -gt "$best_mtime" ]]; then
      best_mtime="$mtime"
      best="$f"
    fi
  done

  # 如果没有活跃 sprint，取最新修改的任意 sprint
  if [[ -z "$best" ]]; then
    best=$(ls -t "$SPRINTS_DIR"/*.status.json 2>/dev/null | head -1)
  fi

  echo "$best"
}

get_field() {
  python3 -c "import json; print(json.load(open('$1')).get('$2',''))" 2>/dev/null
}

# 读取上次已处理的状态 (防止重复派发)
load_last_state() {
  [[ -f "$COORD_STATE" ]] && cat "$COORD_STATE" 2>/dev/null | head -1 | tr -d '\n' || echo ""
}

save_state() {
  local value="$1"
  # D2: 拒绝空或只含冒号的值 (防止 save_state 风暴)
  if [[ -z "$value" ]] || [[ "$value" == ":" ]]; then
    log "${R}⚠ 拒绝写入无效状态: [$value]${N}"
    return 1
  fi
  echo "$value" > "$COORD_STATE"
}

# 检查 pane 中 Claude 是否在运行且空闲 (等待输入)
is_pane_idle() {
  local pane="$1"
  # 检查 pane 是否存在
  tmux list-panes -t "$SESSION_NAME" -F '#{pane_index}' 2>/dev/null | grep -q "$(echo "$pane" | grep -oE '[0-9]+$')" || return 1
  return 0
}

# D1: 规划者静默通知 (永不 send-keys 到规划者 pane)
notify_planner_silently() {
  local sid="$1"
  local inbox="$HARNESS_DIR/.planner-inbox.md"
  local sf="$SPRINTS_DIR/${sid}.status.json"
  local title=""
  local status=""
  if [[ -f "$sf" ]]; then
    title=$(get_field "$sf" "title" | head -c 60)
    status=$(get_field "$sf" "status")
  fi
  local icon="📢"
  case "$status" in
    passed|done|eval_pass) icon="✅" ;;
    failed) icon="❌" ;;
    needs_human_review) icon="🙋" ;;
  esac
  echo "[$(date '+%Y-%m-%d %H:%M')] $icon ${status:-unknown} ${sid}: ${title:-unknown}" >> "$inbox"
  # 写事件流
  if [[ -f "$SPRINTS_DIR/${sid}.events.jsonl" ]]; then
    echo "{\"ts\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\",\"event\":\"planner_notified\",\"by\":\"coordinator\",\"data\":{\"status\":\"${status:-unknown}\"}}" >> "$SPRINTS_DIR/${sid}.events.jsonl"
  fi
  log "${C}规划者静默通知: $icon ${status:-unknown} ${sid}${N}"
}

# 向 pane 发送指令 (核心调度动作)
# 原理: 长消息写到指令文件，tmux 只发一行短命令让 Claude 读文件
dispatch_to_pane() {
  local pane="$1"
  local message="$2"
  local sid="${3:-dispatch}"

  # D1: 规划者 pane 静默处理, 永不 send-keys
  if [[ "$pane" == "$PANE_PLANNER" ]] || [[ "$pane" == "$SESSION_NAME:0.0" ]]; then
    notify_planner_silently "${sid}"
    return 0
  fi

  if ! tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
    log "${R}Harness session 不存在${N}"
    return 1
  fi

  # ── D3: pane 忙检测 (Sprint sprint-20260417-213037, 2026-04-17) ──
  # 根因: 目标 pane 仍在思考/生成时, tmux send-keys 被 Claude Code CLI 吞掉
  # 修复: 派发前 capture-pane 检查忙碌标记, 最多等 120s, 超时记录 DEFERRED
  local busy_patterns='✳|✶|⏺|Cogitated|Cooked|Propagating|Worked for'
  local wait_count=0
  local max_waits=12  # 12 * 10s = 120s
  while (( wait_count < max_waits )); do
    local pane_output
    pane_output=$(tmux capture-pane -t "$pane" -p 2>/dev/null | tail -3)
    if echo "$pane_output" | grep -qE "$busy_patterns"; then
      log "${Y}目标 pane 忙碌 (等待 ${wait_count}/${max_waits})${N}"
      sleep 10
      ((wait_count++))
    else
      break
    fi
  done
  if (( wait_count >= max_waits )); then
    log "${R}目标 pane 忙碌超时 (120s), 记录 DISPATCH_DEFERRED: ${sid}${N}"
    emit_event "$sid" "DISPATCH_DEFERRED" "coordinator"
    return 1
  fi

  # 写指令到文件 (如果 message 非空；handle_* 已经提前写好 dispatch.md)
  local instruction_file="$SPRINTS_DIR/${sid}.dispatch.md"
  if [[ -n "$message" ]]; then
    echo "$message" > "$instruction_file"
  fi

  if [[ ! -f "$instruction_file" ]]; then
    log "${R}dispatch 失败: 指令文件不存在 ${instruction_file}${N}"
    return 1
  fi

  # 发一句短指令 (直接告诉 Claude 干什么, 不靠 hook)
  local short_cmd="读取并执行 ${instruction_file}"
  # ── D1: send-keys 拆两步 (Sprint sprint-20260417-213037, 2026-04-17) ──
  # 根因: Claude Code CLI 无法处理连发 text+Enter, 吞键导致派发丢失
  # 修复: 先送 text → sleep 0.8 等待 CLI 就绪 → 再送 Enter
  # 此处覆盖所有 handle_* 调用点 (统一走 dispatch_to_pane 入口)
  tmux send-keys -t "$pane" "$short_cmd" 2>/dev/null || { log "${R}send-keys text 失败! pane=${pane}${N}"; return 1; }
  sleep 0.8
  if tmux send-keys -t "$pane" Enter 2>/dev/null; then
    log "${G}已派发到 ${pane}: ${instruction_file}${N}"
  else
    log "${R}tmux send-keys 失败! pane=${pane}${N}"
    return 1
  fi
  return 0
}

# 追加事件到 events.jsonl (D2: 事件流)
emit_event() {
  local sid="$1" event="$2" by="${3:-coordinator}"
  local data="${4:-}"
  local ts
  ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  local json="{\"ts\":\"${ts}\",\"sid\":\"${sid}\",\"event\":\"${event}\",\"by\":\"${by}\""
  [[ -n "$data" ]] && json="${json},\"data\":${data}"
  json="${json}}"
  bash "$SESSION_SH" append "$sid" "$json" &>/dev/null || true
}

# ================================================================
# D3: KV Cache 友好 dispatch 生成
# 稳定前缀 (~200 token) + CACHE_BOUNDARY + 变化后缀
# ================================================================
generate_dispatch() {
  local sid="$1" role="$2" task="$3"
  cat > "$SPRINTS_DIR/${sid}.dispatch.md" << EOF
<!-- === STABLE PREFIX (cached) === -->
# 协调器指令模板 v1

你是 solar-harness 协调系统的任务执行者。收到指令后按步骤执行。

## 通用步骤说明
1. 读取合约: 路径格式 \`~/.solar/harness/sprints/<sid>.contract.md\`
2. 按指令执行，不超出范围
3. 完成后写 handoff/eval + 更新 status.json

<!-- CACHE_BOUNDARY -->
<!-- === VARIABLE SUFFIX === -->

## 本次任务
- Sprint ID: \`${sid}\`
- 角色: ${role}
- 具体任务: ${task}
EOF
}

# 追加内容到已有 dispatch.md
append_dispatch() {
  local sid="$1"
  shift
  cat >> "$SPRINTS_DIR/${sid}.dispatch.md" << EOF

$*
EOF
}

# D4: 从 eval.json 提取失败项 (短路)
extract_fail_info() {
  local sid="$1"
  local eval_json="$SPRINTS_DIR/${sid}.eval.json"
  if [[ ! -f "$eval_json" ]]; then
    echo ""
    return 1
  fi
  python3 -c "
import json, sys
try:
    d = json.load(open('${eval_json}'))
    if d.get('verdict') != 'FAIL':
        print('')
        sys.exit(1)
    fc = d.get('failed_conditions', [])
    errors = d.get('errors', [])
    if not fc:
        print('')
        sys.exit(1)
    print(json.dumps({'failed_conditions': fc, 'errors': errors}, ensure_ascii=False))
except Exception as e:
    print('')
    sys.exit(1)
" 2>/dev/null
}

# D5: 检测 @NEEDS_HUMAN 标记
check_needs_human() {
  local sid="$1"
  local found=false
  for f in "$SPRINTS_DIR/${sid}.handoff.md" "$SPRINTS_DIR/${sid}.eval.md"; do
    [[ -f "$f" ]] || continue
    if grep -qE '@NEEDS_HUMAN:' "$f" 2>/dev/null; then
      found=true
      grep -E '@NEEDS_HUMAN:' "$f" | head -1 | sed 's/.*@NEEDS_HUMAN:[[:space:]]*//'
      break
    fi
  done
  $found && return 0 || return 1
}

# ================================================================
# 质量门禁 — status 变更前强制检查前置条件
# ================================================================

# ================================================================
# 自动检查点 — 每次状态变更前 git snapshot
# ================================================================

auto_checkpoint() {
  local sid="$1" new_status="$2"

  # 找到工作目录 (从 sprint 合约中读取，或用当前目录)
  local work_dir=""
  local contract="$SPRINTS_DIR/${sid}.contract.md"
  if [[ -f "$contract" ]]; then
    work_dir=$(grep '^Project:' "$contract" 2>/dev/null | sed 's/^Project:[[:space:]]*//')
  fi
  [[ -z "$work_dir" ]] && work_dir="$HOME/.claude"

  # 检查是否是 git 仓库
  if ! git -C "$work_dir" rev-parse --git-dir &>/dev/null; then
    return 0
  fi

  # 检查是否有变更 (避免空 commit)
  if git -C "$work_dir" diff --quiet 2>/dev/null && git -C "$work_dir" diff --cached --quiet 2>/dev/null; then
    # 检查 untracked files (只在 sprints 目录)
    local untracked
    untracked=$(git -C "$work_dir" ls-files --others --exclude-standard -- "$SPRINTS_DIR/" 2>/dev/null | head -5)
    if [[ -z "$untracked" ]]; then
      return 0  # 无变更，跳过
    fi
  fi

  local tag="checkpoint/${sid}/${new_status}/$(date +%H%M%S)"

  # stage sprint 相关文件 + 工作区变更
  git -C "$work_dir" add "$SPRINTS_DIR/${sid}"* 2>/dev/null || true

  # 创建检查点 commit
  git -C "$work_dir" commit --allow-empty -m "checkpoint: ${sid} → ${new_status}" --no-gpg-sign 2>/dev/null && {
    # 打 tag 方便回滚
    git -C "$work_dir" tag "$tag" 2>/dev/null
    log "${G}检查点: ${tag}${N}"
  } || true
}

# 回滚到指定检查点
# 用法: rollback_to_checkpoint <sprint_id> <status>
rollback_to_checkpoint() {
  local sid="$1" target_status="$2"
  local work_dir="$HOME/.claude"

  # 找到最近匹配的 tag
  local tag
  tag=$(git -C "$work_dir" tag -l "checkpoint/${sid}/${target_status}/*" --sort=-creatordate 2>/dev/null | head -1)

  if [[ -z "$tag" ]]; then
    log "${R}未找到检查点: checkpoint/${sid}/${target_status}/*${N}"
    return 1
  fi

  log "${Y}回滚到检查点: ${tag}${N}"
  git -C "$work_dir" checkout "$tag" -- "$SPRINTS_DIR/${sid}"* 2>/dev/null
}

SCHEMA_VALIDATOR="$HARNESS_DIR/schemas/validate.sh"

# 校验文档结构 (返回 0=通过, 1=失败)
validate_doc() {
  local type="$1" file="$2"
  if [[ -x "$SCHEMA_VALIDATOR" ]] && [[ -f "$file" ]]; then
    local result
    result=$(bash "$SCHEMA_VALIDATOR" "$type" "$file" 2>/dev/null)
    if [[ $? -ne 0 ]]; then
      log "${R}Schema 校验失败: $result${N}"
      echo "$result"
      return 1
    fi
  fi
  return 0
}

gate_check() {
  local sid="$1" st="$2"
  local sprint_dir="$SPRINTS_DIR"

  case "$st" in
    planning)
      # 门禁: plan.md 必须存在 + 结构校验
      if [[ ! -f "$sprint_dir/${sid}.plan.md" ]]; then
        log "${R}门禁拦截: planning 状态但 plan.md 不存在${N}"
        dispatch_to_pane "$PANE_BUILDER" "门禁拦截：你需要先写实现计划到 ~/.solar/harness/sprints/${sid}.plan.md 再更新状态为 planning。"
        python3 -c "
import json, datetime
d=json.load(open('$sprint_dir/${sid}.status.json'))
d['status']='active'
d['updated_at']=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
json.dump(d,open('$sprint_dir/${sid}.status.json','w'),indent=2)
" 2>/dev/null
        return 1
      fi
      # Schema 校验
      local plan_err
      if plan_err=$(validate_doc "plan" "$sprint_dir/${sid}.plan.md"); then :; else
        dispatch_to_pane "$PANE_BUILDER" "门禁拦截 (Schema): plan.md 结构不完整。${plan_err} 请补全后重新提交。"
        python3 -c "
import json, datetime
d=json.load(open('$sprint_dir/${sid}.status.json'))
d['status']='active'
d['updated_at']=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
json.dump(d,open('$sprint_dir/${sid}.status.json','w'),indent=2)
" 2>/dev/null
        return 1
      fi
      ;;

    reviewing)
      # 门禁: handoff.md 必须存在 + 结构校验
      if [[ ! -f "$sprint_dir/${sid}.handoff.md" ]]; then
        log "${R}门禁拦截: reviewing 状态但 handoff.md 不存在${N}"
        dispatch_to_pane "$PANE_BUILDER" "门禁拦截：你需要先写 handoff 文档到 ~/.solar/harness/sprints/${sid}.handoff.md 再更新状态为 reviewing。"
        python3 -c "
import json, datetime
d=json.load(open('$sprint_dir/${sid}.status.json'))
d['status']='approved'
d['updated_at']=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
json.dump(d,open('$sprint_dir/${sid}.status.json','w'),indent=2)
" 2>/dev/null
        return 1
      fi
      local handoff_err
      if handoff_err=$(validate_doc "handoff" "$sprint_dir/${sid}.handoff.md"); then :; else
        dispatch_to_pane "$PANE_BUILDER" "门禁拦截 (Schema): handoff.md 结构不完整。${handoff_err} 请补全后重新提交。"
        python3 -c "
import json, datetime
d=json.load(open('$sprint_dir/${sid}.status.json'))
d['status']='approved'
d['updated_at']=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
json.dump(d,open('$sprint_dir/${sid}.status.json','w'),indent=2)
" 2>/dev/null
        return 1
      fi
      ;;

    passed)
      # 门禁: eval.md 必须存在 + 结构校验 + 无未解决 FAIL
      if [[ ! -f "$sprint_dir/${sid}.eval.md" ]]; then
        log "${R}门禁拦截: passed 但 eval.md 不存在${N}"
        dispatch_to_pane "$PANE_EVALUATOR" "门禁拦截：你需要先写评估报告到 ~/.solar/harness/sprints/${sid}.eval.md 再标记为 passed。"
        python3 -c "
import json, datetime
d=json.load(open('$sprint_dir/${sid}.status.json'))
d['status']='reviewing'
d['updated_at']=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
json.dump(d,open('$sprint_dir/${sid}.status.json','w'),indent=2)
" 2>/dev/null
        return 1
      fi
      local eval_err
      if eval_err=$(validate_doc "eval" "$sprint_dir/${sid}.eval.md"); then :; else
        dispatch_to_pane "$PANE_EVALUATOR" "门禁拦截 (Schema): eval.md 结构不完整。${eval_err} 请补全后重新提交。"
        python3 -c "
import json, datetime
d=json.load(open('$sprint_dir/${sid}.status.json'))
d['status']='reviewing'
d['updated_at']=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
json.dump(d,open('$sprint_dir/${sid}.status.json','w'),indent=2)
" 2>/dev/null
        return 1
      fi
      # 检查 eval.md 中是否还有 FAIL 项
      if grep -qi 'FAIL' "$sprint_dir/${sid}.eval.md" 2>/dev/null && grep -qi '总判定.*FAIL' "$sprint_dir/${sid}.eval.md" 2>/dev/null; then
        log "${R}门禁拦截: eval.md 总判定为 FAIL 但状态标为 passed${N}"
        dispatch_to_pane "$PANE_EVALUATOR" "门禁拦截：eval.md 总判定为 FAIL，不能标记为 passed。请修正判定或让建设者修复 FAIL 项。"
        python3 -c "
import json, datetime
d=json.load(open('$sprint_dir/${sid}.status.json'))
d['status']='reviewing'
d['updated_at']=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
json.dump(d,open('$sprint_dir/${sid}.status.json','w'),indent=2)
" 2>/dev/null
        return 1
      fi
      ;;
  esac

  return 0
}

# ================================================================
# 状态转换处理器
# ================================================================

# 规划者完成合约 → 建设者先写实现计划（Plan-before-build）
handle_active() {
  local sid="$1" sf="$2"
  local title
  title=$(get_field "$sf" "title")

  log "${G}Sprint 进入 active → 建设者写实现计划${N}"
  log "  需求: ${title}"

  generate_dispatch "$sid" "建设者" "写实现计划 (Plan-before-build)"
  append_dispatch "$sid" "### 步骤

1. 读取合约:
   cat ~/.solar/harness/sprints/${sid}.contract.md

2. 写实现计划到 ~/.solar/harness/sprints/${sid}.plan.md，包含:
   - \`## 变更文件\` — 要改哪些文件、每个文件改什么
   - \`## 技术方案\` — 数据结构、算法、接口设计
   - \`## 风险点\` — 边界条件、可能出问题的地方

3. 写好后更新状态:
   \`\`\`bash
   python3 -c \"
   import json, datetime
   sf='\$HOME/.solar/harness/sprints/${sid}.status.json'
   d=json.load(open(sf))
   d['status']='planning'
   d['updated_at']=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
   json.dump(d,open(sf,'w'),indent=2)
   \"
   \`\`\`

**先写计划，不要直接写代码。**"

  dispatch_to_pane "$PANE_BUILDER" "" "$sid"
  emit_event "$sid" "dispatched" "coordinator" "{\"to\":\"builder\",\"task\":\"plan\"}"
}

# 建设者写好计划 → 审判官审批计划
handle_planning() {
  local sid="$1" sf="$2"

  log "${C}建设者已提交实现计划 → 审判官审批${N}"

  generate_dispatch "$sid" "审判官" "审批实现计划"
  append_dispatch "$sid" "### 步骤

1. 读取合约:
   cat ~/.solar/harness/sprints/${sid}.contract.md

2. 读取实现计划:
   cat ~/.solar/harness/sprints/${sid}.plan.md

3. 审批要点:
   - 计划是否覆盖所有 Done 条件？
   - 技术方案是否合理？有没有更简单的方式？
   - 风险点是否识别充分？
   - 是否超出合约范围？

4. 判定:
   - APPROVE:
     \`\`\`bash
     python3 -c \"
     import json, datetime
     sf='\$HOME/.solar/harness/sprints/${sid}.status.json'
     d=json.load(open(sf))
     d['status']='approved'
     d['updated_at']=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
     json.dump(d,open(sf,'w'),indent=2)
     \"
     \`\`\`
   - REJECT (在 plan.md 末尾写修改意见):
     \`\`\`bash
     python3 -c \"
     import json, datetime
     sf='\$HOME/.solar/harness/sprints/${sid}.status.json'
     d=json.load(open(sf))
     d['status']='active'
     d['updated_at']=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
     json.dump(d,open(sf,'w'),indent=2)
     \"
     \`\`\`"

  dispatch_to_pane "$PANE_EVALUATOR" "" "$sid"
  emit_event "$sid" "dispatched" "coordinator" "{\"to\":\"evaluator\",\"task\":\"review_plan\"}"
}

# 审判官批准计划 → 建设者开始实现
handle_approved() {
  local sid="$1" sf="$2"

  log "${G}计划已批准 → 建设者开始实现${N}"

  generate_dispatch "$sid" "建设者" "按计划实现代码"
  append_dispatch "$sid" "### 步骤

1. 读取你的计划:
   cat ~/.solar/harness/sprints/${sid}.plan.md

2. 按计划逐步实现代码

3. 实现完成后写 handoff 文档到 ~/.solar/harness/sprints/${sid}.handoff.md
   必须包含: \`## 变更文件\`, \`## Done 达成\`, \`## 验证方法\`

4. 更新状态:
   \`\`\`bash
   python3 -c \"
   import json, datetime
   sf='\$HOME/.solar/harness/sprints/${sid}.status.json'
   d=json.load(open(sf))
   d['status']='reviewing'
   d['round']=d.get('round',0)+1
   d['updated_at']=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
   json.dump(d,open(sf,'w'),indent=2)
   \"
   \`\`\`

**按计划实现，不要超出范围。**"

  dispatch_to_pane "$PANE_BUILDER" "" "$sid"
  emit_event "$sid" "dispatched" "coordinator" "{\"to\":\"builder\",\"task\":\"implement\"}"
}

# 建设者完成实现 → 通知审判官
handle_reviewing() {
  local sid="$1" sf="$2"
  local round
  round=$(get_field "$sf" "round")

  log "${C}Sprint 进入 reviewing (轮次 ${round}) → 派发给审判官${N}"

  generate_dispatch "$sid" "审判官" "代码评审 (轮次 ${round})"
  append_dispatch "$sid" "## 推荐使用 verify-all 技能

**优先路径**: 尝试调用 Skill(verify-all) 获取自动化检测。

技能提供 12 项检查:
- C1 功能完备 (无 TODO/FIXME/stub)
- C2 无断头 (有入口调用方)
- C3 自动触发 (hook/crontab/import)
- C4 默认使用 (无需额外配置)
- C5 激活口令 (intent-engine 注册)
- C6 错误处理 (异常兜底)
- C7 输出持久化 (非 /tmp)
- Q1 真的能跑吗？
- Q2 真的有效吗？
- Q3 真的会退化吗？
- Q4 真的能恢复吗？
- Q5 真的用了吗？

技能输出 READY → verdict=PASS (仍需结合合约 Done 条件逐条判定)
技能输出 NOT READY → verdict=FAIL (附具体失败项)

详细报告存 ${sid}.verify-all.md，eval.md 只放摘要 + READY/NOT READY 判定。

**降级路径**: 技能不可用时手写 bash 验证，标注 @FALLBACK_MANUAL。

### 步骤

1. 读取合约:
   cat ~/.solar/harness/sprints/${sid}.contract.md

2. 读取 handoff:
   cat ~/.solar/harness/sprints/${sid}.handoff.md

3. 逐条检查 Done 定义，查看实际代码，运行测试验证

4. 写评估报告到 ~/.solar/harness/sprints/${sid}.eval.md
   必须包含: \`## 总判定\` (PASS/FAIL), \`## Done 条件逐条\`

5. **写结构化反馈到 ${sid}.eval.json** (eval.json schema 见 evaluator.md)

6. 更新状态:
   - PASS:
     \`\`\`bash
     python3 -c \"
     import json, datetime
     sf='\$HOME/.solar/harness/sprints/${sid}.status.json'
     d=json.load(open(sf))
     d['status']='passed'
     d['updated_at']=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
     json.dump(d,open(sf,'w'),indent=2)
     \"
     \`\`\`
   - FAIL:
     \`\`\`bash
     python3 -c \"
     import json, datetime
     sf='\$HOME/.solar/harness/sprints/${sid}.status.json'
     d=json.load(open(sf))
     d['status']='failed_review'
     d['updated_at']=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
     json.dump(d,open(sf,'w'),indent=2)
     \"
     \`\`\`"

  dispatch_to_pane "$PANE_EVALUATOR" "" "$sid"
  emit_event "$sid" "dispatched" "coordinator" "{\"to\":\"evaluator\",\"task\":\"review\",\"round\":${round}}"
}

# 审判官判定 FAIL → 打回给建设者
handle_failed_review() {
  local sid="$1" sf="$2"
  local round
  round=$(get_field "$sf" "round")

  # D5: 检查 @NEEDS_HUMAN 标记
  local human_reason
  if human_reason=$(check_needs_human "$sid"); then
    log "${Y}检测到 @NEEDS_HUMAN: ${human_reason}${N}"
    python3 -c "
import json, datetime
d=json.load(open('$sf'))
d['status']='needs_human_review'
d['updated_at']=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
json.dump(d,open('$sf','w'),indent=2)
" 2>/dev/null
    return
  fi

  if [[ "$round" -ge 3 ]]; then
    log "${R}Sprint 已达最大轮次 (${round})，标记为 failed${N}"
    python3 -c "
import json, datetime
d=json.load(open('$sf'))
d['status']='failed'
d['updated_at']=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
json.dump(d,open('$sf','w'),indent=2)
" 2>/dev/null

    generate_dispatch "$sid" "规划者" "Sprint 失败"
    append_dispatch "$sid" "Sprint ${sid} 已经 3 轮未通过审判官评审。

请读取评审报告分析原因:
cat ~/.solar/harness/sprints/${sid}.eval.md

决定: 修正合约范围 or 拆分为更小的 Sprint。"

    dispatch_to_pane "$PANE_PLANNER" "" "$sid"
    emit_event "$sid" "dispatched" "coordinator" "{\"to\":\"planner\",\"task\":\"failed_max_rounds\"}"
    return
  fi

  log "${Y}审判官 FAIL → 打回建设者 (轮次 ${round})${N}"

  # 把状态改回 approved (跳过 plan 阶段，直接修)
  python3 -c "
import json, datetime
d=json.load(open('$sf'))
d['status']='approved'
d['updated_at']=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
json.dump(d,open('$sf','w'),indent=2)
" 2>/dev/null

  # D4: 尝试从 eval.json 提取失败项 (短路)
  local fail_info
  fail_info=$(extract_fail_info "$sid")

  generate_dispatch "$sid" "建设者" "修复评审反馈 (轮次 ${round})"

  if [[ -n "$fail_info" ]]; then
    # 短路: 只注入 eval.json 的失败项，不注入整个 eval.md
    append_dispatch "$sid" "## 失败项 (来自 eval.json)

\`\`\`json
${fail_info}
\`\`\`

### 步骤

1. 读取 eval.json 定位失败项:
   cat ~/.solar/harness/sprints/${sid}.eval.json

2. 按 \`failed_conditions\` 逐条修复代码

3. 更新 handoff 文档

4. 更新状态:
   \`\`\`bash
   python3 -c \"
   import json, datetime
   sf='\$HOME/.solar/harness/sprints/${sid}.status.json'
   d=json.load(open(sf))
   d['status']='reviewing'
   d['round']=d.get('round',0)+1
   d['updated_at']=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
   json.dump(d,open(sf,'w'),indent=2)
   \"
   \`\`\`"
  else
    # 无 eval.json，退回到注入 eval.md
    append_dispatch "$sid" "### 步骤

1. 读取评审报告:
   cat ~/.solar/harness/sprints/${sid}.eval.md

2. 按 FAIL 项逐条修复代码

3. 更新 handoff 文档

4. 更新状态:
   \`\`\`bash
   python3 -c \"
   import json, datetime
   sf='\$HOME/.solar/harness/sprints/${sid}.status.json'
   d=json.load(open(sf))
   d['status']='reviewing'
   d['round']=d.get('round',0)+1
   d['updated_at']=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
   json.dump(d,open(sf,'w'),indent=2)
   \"
   \`\`\`"
  fi

  dispatch_to_pane "$PANE_BUILDER" "" "$sid"
  emit_event "$sid" "dispatched" "coordinator" "{\"to\":\"builder\",\"task\":\"fix\",\"round\":${round}}"

  # FAIL 时也提取教训 (FAIL 比 PASS 更有学习价值)
  (bash ~/.claude/hooks/subconscious-learn.sh 2>> "$HARNESS_DIR/brain/learn.log") &
  # ── D9: 自进化钩子 (Sprint sprint-20260417-213037) ──
  (bash ~/.claude/hooks/self-evolve-postmortem.sh "$sid" 2>> "$COORD_LOG") &

  # ── D1: 桌面通知 (Sprint sprint-20260418-065436) ──
  (bash "$HARNESS_DIR/osascript-notify.sh" "Sprint FAIL" "Round ${round}, ${sid}" "Blow") &
  # ── D5: 规划者 inbox (Sprint sprint-20260418-065436) ──
  notify_planner_inbox "Sprint FAIL: ${sid} Round ${round}"
}

# ── D5: 规划者 inbox (Sprint sprint-20260418-065436) ──
notify_planner_inbox() {
  local msg="$1"
  local inbox_file="$HARNESS_DIR/PLANNER-INBOX.md"
  local ts
  ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  touch "$inbox_file"
  # 如果文件是空的, 写 header
  if [[ ! -s "$inbox_file" ]]; then
    echo "# Planner Inbox" > "$inbox_file"
    echo "" >> "$inbox_file"
  fi
  echo "- [ ] [${ts}] ${msg}" >> "$inbox_file"
}

# ── D2: auto-suggest 实战 (Sprint sprint-20260418-065436) ──
check_auto_suggest() {
  local imp_file="$HARNESS_DIR/pending-improvements.jsonl"
  local ts
  ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)

  [[ -f "$imp_file" ]] && [[ -s "$imp_file" ]] || return 0

  python3 << 'PYEOF' 2>> "$COORD_LOG" || true
import json, os, datetime, hashlib

imp_file = os.path.expanduser("$HARNESS_DIR/pending-improvements.jsonl")
sprints_dir = os.path.expanduser("$SPRINTS_DIR")
ts = "$ts"

# 读取已创建的 sprint 关联记录
created_refs = set()
try:
    for line in open(imp_file):
        try:
            d = json.loads(line.strip())
            if d.get("type") == "sprint_created":
                created_refs.add(d.get("ref_hash", ""))
        except: pass
except: pass

# 扫描待 Sprint 化的改进建议 (按优先级排序)
priority_order = {"high": 0, "medium": 1, "low": 2}
candidates = []
for line in open(imp_file):
    try:
        d = json.loads(line.strip())
        if d.get("type") == "sprint_created":
            continue
        if not d.get("suggestion"):
            continue
        # 计算内容 hash 去重
        ref_hash = hashlib.md5(d.get("suggestion","").encode()).hexdigest()[:12]
        if ref_hash in created_refs:
            continue
        pri = d.get("priority", "low")
        if pri in ("high", "medium"):
            candidates.append((priority_order.get(pri, 99), d, ref_hash))
    except: pass

if not candidates:
    exit(0)

candidates.sort(key=lambda x: x[0])
_, top, ref_hash = candidates[0]

# 创建 drafting Sprint
now = datetime.datetime.utcnow()
sid = "sprint-" + now.strftime("%Y%m%d-%H%M%S")
sf = os.path.join(sprints_dir, sid + ".status.json")
cf = os.path.join(sprints_dir, sid + ".contract.md")

# 写 status.json
status = {
    "status": "drafting",
    "title": top.get("suggestion", "")[:60],
    "round": 0,
    "created_at": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
    "updated_at": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
    "source_sprint": top.get("sprint_id", ""),
    "auto_generated": True
}
with open(sf, "w") as f:
    json.dump(status, f, indent=2)

# 写 contract.md (简化版, 规划者可编辑)
suggestion = top.get("suggestion", "改进建议")
priority = top.get("priority", "low")
source = top.get("sprint_id", "")
contract = f"""# Sprint Contract — {sid}
Created: {now.strftime("%Y-%m-%dT%H:%M:%SZ")}
Status: drafting
Source: auto-suggest from {source}
Priority: {priority}

## 需求

{suggestion}

## Done 定义

> (规划者填写)

## 范围

- 包含: 改进建议的实现
- 不包含: 范围扩展

## 约束

> (规划者填写)

## 实现文件清单 (建设者完成后填写)

> (files)

## 审判官评估维度

1. 功能完整性: Done 定义逐条检查
2. 代码质量: 错误处理、边界、安全
3. 合约合规: 在范围内
4. 可维护性: 命名、结构
"""
with open(cf, "w") as f:
    f.write(contract)

# 追加 sprint_created 关联记录 (append-only, 不改历史行)
record = {
    "type": "sprint_created",
    "ref_hash": ref_hash,
    "suggestion": suggestion[:60],
    "sprint_id": sid,
    "priority": priority,
    "created_at": now.strftime("%Y-%m-%dT%H:%M:%SZ")
}
with open(imp_file, "a") as f:
    f.write(json.dumps(record, ensure_ascii=False) + "\n")

print(f"[auto-suggest] 创建 drafting Sprint: {sid} ({priority}: {suggestion[:50]})")
PYEOF
}

# 审判官判定 PASS → 通知完成
handle_passed() {
  local sid="$1" sf="$2"
  local title
  title=$(get_field "$sf" "title")

  log "${G}Sprint PASSED! ${title}${N}"

  generate_dispatch "$sid" "规划者" "Sprint 通过!"
  append_dispatch "$sid" "需求「${title}」已完成，审判官评审通过。

如有新需求，请直接输入。"

  dispatch_to_pane "$PANE_PLANNER" "" "$sid"
  emit_event "$sid" "dispatched" "coordinator" "{\"to\":\"planner\",\"task\":\"passed\"}"

  # 自动归档 (兜底不阻塞)
  (bash "$HARNESS_DIR/archive.sh" auto 2>&1 | head -5 >> "$HARNESS_DIR/.archive-auto.log") || true

  # 异步 token 报告 (后台不阻塞)
  (bash "$HARNESS_DIR/token-tracker.sh" report "$sid" > "$HARNESS_DIR/.token-report.log" 2>&1) &

  # 异步教训提取 — 潜意识闭环核心入口 (不依赖 Claude Stop hook)
  (bash ~/.claude/hooks/subconscious-learn.sh 2>> "$HARNESS_DIR/brain/learn.log") &
  # ── D9: 自进化钩子 (Sprint sprint-20260417-213037) ──
  (bash ~/.claude/hooks/self-evolve-postmortem.sh "$sid" 2>> "$COORD_LOG") &

  # ── D1: 桌面通知 (Sprint sprint-20260418-065436) ──
  (bash "$HARNESS_DIR/osascript-notify.sh" "Sprint PASSED" "${title}" "Glass") &
  # ── D5: 规划者 inbox (Sprint sprint-20260418-065436) ──
  notify_planner_inbox "Sprint PASSED: ${title}"

  # ── D4: 改进自动派发 (Sprint sprint-20260417-213604) ──
  # 扫 pending-improvements.jsonl, top priority 未 Sprint 化的写入 .auto-suggest.json
  local imp_file="$HARNESS_DIR/pending-improvements.jsonl"
  local suggest_file="$HARNESS_DIR/.auto-suggest.json"
  if [[ -f "$imp_file" ]] && [[ -s "$imp_file" ]]; then
    python3 -c "
import json, sys
top = None
for line in open('$imp_file'):
    try:
        d = json.loads(line.strip())
        if not d.get('sprintified') and d.get('priority') == 'high':
            top = d; break
    except: pass
if top:
    with open('$suggest_file', 'w') as f:
        json.dump(top, f, indent=2)
    print('[D4] 高优先改进建议: ' + top.get('suggestion','')[:60])
else:
    # 也检查 medium
    for line in open('$imp_file'):
        try:
            d = json.loads(line.strip())
            if not d.get('sprintified') and d.get('priority') == 'medium':
                with open('$suggest_file', 'w') as f:
                    json.dump(d, f, indent=2)
                print('[D4] 中优先改进建议: ' + d.get('suggestion','')[:60])
                break
        except: pass
" 2>>"$COORD_LOG" || true
  fi
}

# D5: needs_human_review 处理
handle_needs_human() {
  local sid="$1" sf="$2"
  local reason
  reason=$(check_needs_human "$sid" || echo "未指定原因")

  log "${Y}Sprint ${sid} 需要人工介入: ${reason}${N}"

  generate_dispatch "$sid" "规划者" "需要人工介入"
  append_dispatch "$sid" "Sprint ${sid} 被暂停，需要你的决定。

**原因**: ${reason}

### 选项
1. 修复合约: 编辑 ~/.solar/harness/sprints/${sid}.contract.md
2. 继续 Sprint: 更新 status 为 active
   \`\`\`bash
   python3 -c \"
   import json, datetime
   sf='\$HOME/.solar/harness/sprints/${sid}.status.json'
   d=json.load(open(sf))
   d['status']='active'
   d['updated_at']=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
   json.dump(d,open(sf,'w'),indent=2)
   \"
   \`\`\`
3. 终止 Sprint:
   \`\`\`bash
   python3 -c \"
   import json, datetime
   sf='\$HOME/.solar/harness/sprints/${sid}.status.json'
   d=json.load(open(sf))
   d['status']='failed'
   d['updated_at']=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
   json.dump(d,open(sf,'w'),indent=2)
   \"
   \`\`\`

注意: needs_human_review **不计入** 3 轮失败上限。"

  dispatch_to_pane "$PANE_PLANNER" "" "$sid"
  emit_event "$sid" "dispatched" "coordinator" "{\"to\":\"planner\",\"task\":\"needs_human\",\"reason\":\"${reason}\"}"
}

# ================================================================
# 主循环 — 轮询状态变化
# ================================================================

run_coordinator() {
  # PID 互斥: 防止多实例
  local pidfile="$HARNESS_DIR/.coordinator.pid"
  if [[ -f "$pidfile" ]] && kill -0 "$(cat "$pidfile")" 2>/dev/null; then
    log "${R}协调器已在运行 (PID=$(cat "$pidfile"))，退出${N}"
    exit 1
  fi
  echo $$ > "$pidfile"
  trap "rm -f '$pidfile'" EXIT

  # ── D10: 启动自愈 (Sprint sprint-20260417-213037, 2026-04-17) ──
  # 根因: 手动 patch 遗漏或协调器升级后旧 patch 未同步
  # 修复: 启动时检查 pending-patches.jsonl, 逐条尝试 apply
  local patches_file="$HARNESS_DIR/pending-patches.jsonl"
  if [[ -f "$patches_file" ]] && [[ -s "$patches_file" ]]; then
    log "${C}检查待应用 patch...${N}"
    local patched=0 failed=0
    while IFS= read -r line; do
      local applied pfile
      applied=$(echo "$line" | python3 -c "import sys,json; print(json.load(sys.stdin).get('applied',False))" 2>/dev/null || echo "true")
      [[ "$applied" == "True" ]] && continue
      pfile=$(echo "$line" | python3 -c "import sys,json; print(json.load(sys.stdin).get('file',''))" 2>/dev/null || echo "")
      [[ -z "$pfile" ]] && continue
      if patch -p1 --dry-run < "$pfile" &>/dev/null; then
        if patch -p1 < "$pfile" &>/dev/null; then
          log "${G}自愈 patch 成功: ${pfile}${N}"
          # 标记 applied (原地替换)
          python3 -c "
import json, sys
lines = open('$patches_file').readlines()
with open('$patches_file','w') as f:
  for l in lines:
    d = json.loads(l)
    if d.get('file') == '$pfile': d['applied'] = True
    f.write(json.dumps(d)+'\n')
" 2>/dev/null || true
          ((patched++))
        else
          log "${Y}自愈 patch apply 失败 (dry-run OK): ${pfile}${N}"
          ((failed++))
        fi
      else
        log "${Y}自愈 patch 不兼容 (skip): ${pfile}${N}"
        ((failed++))
      fi
    done < "$patches_file"
    log "自愈完成: ${patched} 成功, ${failed} 跳过"
  fi

  # 启动时初始化为当前最新 sprint 状态 (避免 rm 导致风暴)
  local init_sf
  init_sf=$(get_latest_sprint_file)
  if [[ -n "$init_sf" ]]; then
    local init_sid init_st
    init_sid=$(get_field "$init_sf" "id")
    init_st=$(get_field "$init_sf" "status")
    if [[ -n "$init_sid" ]] && [[ -n "$init_st" ]]; then
      echo "${init_sid}:${init_st}" > "$COORD_STATE"
      log "协调器启动，初始状态: ${init_sid}:${init_st}"
    else
      rm -f "$COORD_STATE"
      log "协调器启动，无法读取状态，已重置"
    fi
  else
    rm -f "$COORD_STATE"
    log "协调器启动，无活跃 Sprint"
  fi

  local last_file_mtime=0
  local loop_count=0
  while true; do
    ((loop_count++))
    # ── D4: 会话分隔符 ──
    echo "═══════════════════════════════════════════════════" >> "$COORD_LOG"
    echo "[会话] 轮询开始: $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$COORD_LOG"

    # ── D2: 文件级 mtime 检测 (Sprint sprint-20260417-213037, 2026-04-17) ──
    # 根因: macOS APFS 改文件内容不更新目录 mtime → coordinator 漏检
    # 修复: 扫描 sprint-*.status.json 取 max(mtime), 单文件修改即触发
    local max_file_mtime=0
    for f in "$SPRINTS_DIR"/sprint-*.status.json; do
      [[ -f "$f" ]] || continue
      local fmtime
      fmtime=$(stat -f %m "$f" 2>/dev/null || echo 0)
      (( fmtime > max_file_mtime )) && max_file_mtime=$fmtime
    done
    if [[ "$max_file_mtime" == "$last_file_mtime" ]]; then
      # 无变化, 跳过本轮解析
      if which fswatch &>/dev/null; then
        fswatch --one-event "$SPRINTS_DIR" &>/dev/null || true
      else
        sleep 10
      fi
      continue
    fi
    last_file_mtime="$max_file_mtime"
    log "文件级 mtime 变化: max_mtime=${max_file_mtime}"

    local sf
    sf=$(get_latest_sprint_file)

    if [[ -n "$sf" ]]; then
      local sid st
      sid=$(get_field "$sf" "id")
      st=$(get_field "$sf" "status")

      # D2 护栏: sid 或 st 为空 → 跳过本轮 (防止空值风暴)
      if [[ -z "$sid" ]] || [[ -z "$st" ]]; then
        log "${Y}⚠ sid=[$sid] st=[$st] 为空, 跳过本轮${N}"
        sleep 3
        continue
      fi

      # 生成当前状态指纹
      local current_state="${sid}:${st}"
      local last_state
      last_state=$(load_last_state)

      # 只在状态变化时触发
      if [[ "$current_state" != "$last_state" ]]; then
        log "状态变化检测: ${last_state:-<初始>} → ${current_state}"
        emit_event "$sid" "state_changed" "coordinator" "{\"from\":\"${last_state:-<init>\",\"to\":\"${current_state}\"}"
        # 质量门禁检查 (不通过则回滚状态，不 save_state)
        if ! gate_check "$sid" "$st"; then
          log "${Y}门禁未通过，状态已回滚${N}"
          continue
        fi

        # 自动检查点: 在状态变更前 git snapshot
        auto_checkpoint "$sid" "$st"

        save_state "$current_state"

        case "$st" in
          active)
            handle_active "$sid" "$sf"
            ;;
          planning)
            handle_planning "$sid" "$sf"
            ;;
          approved)
            handle_approved "$sid" "$sf"
            ;;
          reviewing|ready_for_review)
            handle_reviewing "$sid" "$sf"
            ;;
          failed_review)
            handle_failed_review "$sid" "$sf"
            ;;
          needs_human_review)
            handle_needs_human "$sid" "$sf"
            ;;
          passed|done|eval_pass)
            handle_passed "$sid" "$sf"
            ;;
          failed)
            log "${R}Sprint 最终失败，需要规划者介入${N}"
            ;;
          drafting)
            log "Sprint ${sid} 草稿中，等待规划者完成 Done 定义..."
            ;;
        esac
      fi
    fi

    # D1: 降级 sleep (stat mtime 主路径已在循环开头处理, 这里是 fallback)
    # D2: auto-suggest 每 10 次迭代 (~100s) 检查一次
    if (( loop_count % 10 == 0 )); then
      check_auto_suggest
      # D4: 扫 auto-generated drafting Sprint, Done>=3 则通知规划者
      (bash ~/.claude/hooks/planner-review-drafting.sh 2>> "$COORD_LOG") || true
      # D5: 扫 PLANNER-INBOX 未读条目, 派发到规划者 (silent)
      if [[ -f "$HARNESS_DIR/PLANNER-INBOX.md" ]] && grep -q '\- \[ \]' "$HARNESS_DIR/PLANNER-INBOX.md" 2>/dev/null; then
        local unread
        unread=$(grep '\- \[ \]' "$HARNESS_DIR/PLANNER-INBOX.md" 2>/dev/null | wc -l | tr -d ' ')
        if [[ "$unread" -gt 0 ]]; then
          echo "[inbox] ${unread} 条未读通知, 已写入 .planner-inbox.md" >> "$COORD_LOG"
          grep '\- \[ \]' "$HARNESS_DIR/PLANNER-INBOX.md" >> "$HARNESS_DIR/.planner-inbox.md" 2>/dev/null || true
        fi
      fi
    fi
    # D3: 低分能力自愈 每 30 次迭代 (~5 分钟)
    if (( loop_count % 30 == 0 )); then
      (bash ~/.claude/hooks/scan-low-quality-capabilities.sh 2>> "$COORD_LOG" && \
       bash ~/.claude/hooks/auto-boost-capability.sh 2>> "$COORD_LOG") &
    fi
    sleep 10
  done
}

# 入口
run_coordinator
