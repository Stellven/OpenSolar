# Solar + solar-harness 架构审计报告

生成时间: 2026-05-08  
范围: `/Users/sihaoli/.solar`, `/Users/sihaoli/.solar/harness`, `/Users/sihaoli/.claude/core/solar-farm`, `/Users/sihaoli/Knowledge`, `/Users/sihaoli/.solar/solar.db`

## 1. 一句话结论

Solar 的正确抽象不是“一堆脚本和 pane”，而是一个 AI 研发操作系统：把老板的目标转成 PRD、方案、合同、派工、并行施工、验收、知识沉淀和下一轮默认复用。现在最大优化点是把这条生产线做成稳定闭环，而不是继续堆更多零散功能。

## 2. 能力分层

```
┌──────────────────────────────┬─────────┬────────────────────────────────────────────────────────────┐
│ 能力层                       │ 状态    │ 人话解释                                                   │
├──────────────────────────────┼─────────┼────────────────────────────────────────────────────────────┤
│ 需求工厂                     │ warn    │ 从一句话形成 PRD、边界、验收标准；还依赖人/PM pane 质量     │
│ 交付生产线                   │ ok      │ Planner/Builder/Evaluator + coordinator 能跑完整 Sprint    │
│ 并行施工队                   │ warn    │ 主屏 + Lab 已有，但角色、模型、并发、断头仍需治理           │
│ 知识飞轮                     │ warn    │ 能收集和索引，但“提取→合并→默认复用”还没完全闭环           │
│ 自动监工                     │ pending │ 能发现部分断头，但还不是稳定常驻的系统能力                 │
│ 运营驾驶舱                   │ ok      │ Status/Config/Capture/Mermaid 已有，仍要少显示机器噪声      │
│ 实现底座                     │ ok      │ tmux、shell、Python、Node、模型、Vault、Solar DB 支撑运行   │
└──────────────────────────────┴─────────┴────────────────────────────────────────────────────────────┘
```

## 2.1 上一版遗漏的关键能力

```
┌──────────────────────────────┬─────────┬────────────────────────────────────────────────────────────┐
│ 被漏掉的能力族               │ 状态    │ 真实位置/证据                                               │
├──────────────────────────────┼─────────┼────────────────────────────────────────────────────────────┤
│ 多模型大脑路由               │ ok      │ brain-router: classifier/router/executor/A-B benchmark/SROE │
│ CEO/牛马编排与人格系统        │ ok      │ solar-farm: solar-mapper/persona-bank/perf-injector         │
│ 技能生成与自进化              │ ok      │ skill-forge/skill-evolve/trace2skill/repair-loop            │
│ 绩效和互评系统                │ ok      │ collab_performance=1935, qmix_execution_episodes=1152       │
│ 记忆和语义数据层              │ ok      │ cortex/knowledge/ontology/memrl/FTS/solar_kb_entries        │
│ 分布式执行与外部 Agent        │ warn    │ HIVE/OWL/MCP/tool-rpc 存在，但未纳入 harness 主控制闭环     │
│ 系统入口与消息监听            │ warn    │ Shortcuts/iMessage/Gmail/incoming/codex-bridge 存在但分散   │
│ 轨迹、训练、benchmark         │ ok      │ trajectories/atropos/training/brain-router reports          │
│ 安全、配额、策略治理          │ warn    │ security/policies/quota/cost 有底座，未统一进一个治理面     │
└──────────────────────────────┴─────────┴────────────────────────────────────────────────────────────┘
```

## 3. 架构图（人类抽象视角）

主图表达 Solar 的产品逻辑：目标如何变成交付，交付如何变成知识，知识如何反哺下一次研发。

```mermaid
%%{init: {"theme": "base", "themeVariables": {"fontSize": "30px", "fontFamily": "Avenir Next, Gill Sans, sans-serif"}}}%%
flowchart TB
  North["老板目标<br/>一句话、一个网页、一批文件、一个项目"]
  Intent["1. 需求理解<br/>把模糊想法变成 PRD 和成功标准"]
  Design["2. 方案设计<br/>把 PRD 变成架构、合同、任务切片"]
  Dispatch["3. 自动调度<br/>选择角色、模型、并发、工作区"]
  Build["4. 并行交付<br/>主线施工 + 实验室验证 + 隔离实现"]
  Judge["5. 质量验收<br/>测试、审判、回滚、验收报告"]
  Learn["6. 知识沉淀<br/>把通过验收的结果写入知识库"]
  Observe["7. 运营治理<br/>状态、配置、健康、成本、断头监控"]
  Foundation["实现底座<br/>tmux panes · solar-harness · Symphony workspace · Obsidian/QMD/Mirage · Solar DB · 模型"]

  North --> Intent --> Design --> Dispatch --> Build --> Judge --> Learn
  Observe -. 监控并纠偏 .-> Dispatch
  Observe -. 发现断头 .-> Build
  Judge -. 失败返工 .-> Design
  Learn -. 下次默认检索 .-> Intent
  Learn --> Foundation
```

独立 Mermaid 文件:

```
┌────────────────────────┬──────────────────────────────────────────────────────────────────────────────┐
│ 图                     │ 文件                                                                         │
├────────────────────────┼──────────────────────────────────────────────────────────────────────────────┤
│ 操作系统总览           │ /Users/sihaoli/.solar/harness/reports/solar-system-architecture-20260508.mmd │
│ 技术能力地图           │ /Users/sihaoli/.solar/harness/reports/solar-technical-capability-map-20260508.mmd │
│ 大脑与学习栈           │ /Users/sihaoli/.solar/harness/reports/solar-brain-and-learning-stack-20260508.mmd │
│ 运行编排栈             │ /Users/sihaoli/.solar/harness/reports/solar-runtime-orchestration-stack-20260508.mmd │
│ 记忆数据面             │ /Users/sihaoli/.solar/harness/reports/solar-memory-data-plane-20260508.mmd    │
│ 交付生产线             │ /Users/sihaoli/.solar/harness/reports/solar-control-execution-stack-20260508.mmd │
│ 知识飞轮               │ /Users/sihaoli/.solar/harness/reports/solar-knowledge-data-stack-20260508.mmd │
│ 治理驾驶舱             │ /Users/sihaoli/.solar/harness/reports/solar-observability-config-stack-20260508.mmd │
└────────────────────────┴──────────────────────────────────────────────────────────────────────────────┘
```

## 4. 核心链路图

### 4.1 Sprint 控制链路

```mermaid
sequenceDiagram
  participant U as 用户/Codex PM
  participant P as PM pane
  participant PL as Planner pane
  participant B as Builder/Lab panes
  participant E as Evaluator pane
  participant C as coordinator.sh
  participant S as sprints/*.status.json
  participant EV as events/all.jsonl

  U->>P: 需求/目标
  P->>S: 写 PRD / status=drafting
  C->>PL: dispatch planner
  PL->>S: 写 plan / planning_complete
  C->>B: dispatch builder
  B->>S: 写 handoff / building_parallel 或 reviewing
  C->>E: dispatch evaluator
  E->>S: 写 eval / passed 或 failed_review
  C->>EV: 每次状态/派发/失败写事件
```

### 4.2 知识库入库链路

```mermaid
flowchart LR
  Upload["网页粘贴 / 文件上传 / sprint export"] --> Raw["Knowledge/_raw"]
  Raw --> Dispatch["wiki dispatch files"]
  Dispatch --> Agent["builder / Codex / Claude 执行 wiki-ingest"]
  Agent --> Pages["concepts / entities / skills / projects / synthesis"]
  Pages --> Manifest[".manifest.json / provenance"]
  Pages --> QMD["qmd update / embed"]
  Pages --> SolarImport["wiki-solar-db-import.py"]
  QMD --> Retrieval["wiki query / mirage search / Solar KB context"]
  SolarImport --> Retrieval
```

## 5. 关键事实源

```
┌──────────────────────────────────────────────┬─────────┬──────────────────────────────────────────────┐
│ 事实源                                       │ 状态    │ 说明                                         │
├──────────────────────────────────────────────┼─────────┼──────────────────────────────────────────────┤
│ sprints/*.status.json                        │ ok      │ Sprint 生命周期主状态，但字段仍不完全统一    │
│ sprints/*.prd/plan/handoff/eval.md           │ ok      │ 可验收产物事实源                             │
│ events/all.jsonl                             │ ok      │ 结构化事件事实源，但历史事件字段有 payload/data 混用 │
│ .pane-assignments                            │ warn    │ pane 指派事实源之一，和 status/pane title 重叠 │
│ tmux pane output/title                       │ warn    │ 运行态信号，不应作为完成事实                 │
│ ~/.solar/solar.db                            │ ok      │ 老 Solar/Cortex/FTS/路由/知识/绩效数据库     │
│ /Users/sihaoli/Knowledge                     │ ok      │ Obsidian 人类可读知识库                      │
│ QMD solar-wiki collection                    │ warn    │ 已索引，但仍有待 embedding 项                │
│ Mirage config/state                          │ ok      │ 统一数据访问边界和健康缓存                   │
└──────────────────────────────────────────────┴─────────┴──────────────────────────────────────────────┘
```

## 6. 本机当前运行态快照

```
┌──────────────────────────────┬─────────┬──────────────────────────────────────────────┐
│ 项目                         │ 状态    │ 证据                                         │
├──────────────────────────────┼─────────┼──────────────────────────────────────────────┤
│ tmux 主屏                    │ ok      │ solar-harness:0.0~0.3 四角色存在             │
│ lab builder                  │ ok      │ solar-harness-lab:0.0~0.3 四 builder 存在    │
│ status-server                │ ok      │ solar-harness-status-server Python 进程存在  │
│ Obsidian Wiki                │ ok      │ vault=/Users/sihaoli/Knowledge, skills installed │
│ Mirage                       │ ok      │ /knowledge /raw /sprints /solar /cortex /qmd ready │
│ Google Drive mount           │ warn    │ credentials missing, degraded                │
│ QMD                          │ warn    │ binary ok；1268 files indexed；151 pending embedding │
│ Solar DB                     │ ok      │ 251.3 MB；FTS/Cortex/knowledge 表存在        │
│ Autopilot                    │ pending │ 可检测 ready_for_builder 与 pane_asks_boss，但未常驻 │
└──────────────────────────────┴─────────┴──────────────────────────────────────────────┘
```

数据库规模快照:

```
┌──────────────────────┬─────────┐
│ 表/索引              │ 记录数  │
├──────────────────────┼─────────┤
│ cortex_sources       │ 580     │
│ cortex_passages      │ 2319    │
│ knowledge_records    │ 113     │
│ knowledge_entities   │ 4468    │
│ knowledge_claims     │ 4488    │
│ solar_kb_entries     │ 954     │
│ fts_unified_search   │ 1815    │
└──────────────────────┴─────────┘
```

Sprint artifact 快照:

```
┌──────────────────────┬─────────┐
│ 类型                 │ 数量    │
├──────────────────────┼─────────┤
│ status.json          │ 85      │
│ prd.md               │ 7       │
│ plan.md              │ 23      │
│ handoff.md           │ 15      │
│ eval.md              │ 63      │
└──────────────────────┴─────────┘
```

## 7. 主要架构问题

### P0 问题

1. 多事实源未收敛。`status.json`、`.pane-assignments`、tmux title、pane 输出、artifact 文件、events 同时表达“谁在干什么”，导致页面和真实进度容易不一致。
2. 自动决策还不是一等能力。`solar-autopilot-monitor.py` 已能发现“pane 问老板”“ready_for_builder”，但还没有常驻 daemon、SLO、重试、冷却和审计闭环。
3. 知识入库链路未完全闭合。上传能进 `_raw`，QMD 能索引部分文件，但“抽取为 concepts/entities/skills + 入 Solar DB + 可被默认检索”仍需要严格 per-source 状态机。
4. Symphony 和 coordinator 边界仍是双轨。Symphony 提供 workspace/hooks/events，但主执行仍靠 tmux/pane；如果不定义迁移边界，会长期双维护。

### P1 问题

1. `events/all.jsonl` 历史字段有 `payload` 和 `data` 混用，前端和分析器要兼容，长期应 schema normalize。
2. lab builder 的产物和运行态容易混淆。handoff 已存在不代表 pane 正在工作；需要在 UI 中把 artifact proof 与 runtime state 分开。
3. Model config、persona config、pane launcher 三处会共同影响模型，容易出现“全是 opus / 全是 glm / 并发不够”的错配。
4. Status UI 之前直接展示内部 JSON，说明缺少面向用户的 view-model 层。

### P2 问题

1. 老 Solar `.solar/core-archive` 与新 harness 的职责边界需要归档说明，否则优化时容易误改历史系统。
2. Drive/Mirage 目前是 degraded but optional；如果要统一数据底座，需要 credentials、权限和缓存策略。
3. QMD embedding 不是默认完成态，语义检索质量和成本需要单独开关、进度条、失败恢复。

## 8. 目标架构建议

```mermaid
flowchart TB
  Intent["用户意图"] --> PM["Codex/PM 需求分析"]
  PM --> Lifecycle["统一 Sprint Lifecycle API"]
  Lifecycle --> Queue["事件源队列 events v2"]
  Queue --> Workers["Pane Workers / Symphony Workers"]
  Workers --> Artifacts["验收产物"]
  Artifacts --> Evaluator["Evaluator Gate"]
  Evaluator --> Accepted["Accepted Artifact Store"]
  Accepted --> KnowledgeIngest["Knowledge Ingest State Machine"]
  KnowledgeIngest --> Vault["Obsidian Vault"]
  KnowledgeIngest --> SolarDB["Solar DB / FTS"]
  KnowledgeIngest --> QMD["QMD / MinerU"]
  Queue --> StatusVM["Status View Model"]
  StatusVM --> UI["Human Dashboard"]
  Autopilot["Autopilot Daemon"] --> Queue
  Autopilot --> Lifecycle
```

核心原则:

- 一个生命周期 API: 所有 PM/planner/builder/evaluator/autopilot 只能通过同一套状态转移函数改 Sprint。
- 一个事件 schema: `event`, `actor`, `sprint_id`, `severity`, `payload`, `correlation_id`, `artifact_path` 固定。
- 一个知识入库状态机: `raw_detected -> extracted -> resolved -> indexed_qmd -> imported_solar_db -> verified`.
- pane 只是 worker，不是事实源；事实源必须是事件 + artifact + 状态机。

## 9. 优化路线

```
┌────────┬──────────────────────────────┬────────────────────────────────────────────────────┐
│ 优先级 │ 优化项                       │ 验收标准                                           │
├────────┼──────────────────────────────┼────────────────────────────────────────────────────┤
│ P0     │ Autopilot daemon 一等化       │ 常驻监控；自动处理断头；每次决策写事件和 history   │
│ P0     │ Sprint 状态事实源收敛         │ 禁止直接改散落文件；统一 lifecycle API 和 schema   │
│ P0     │ Wiki upload ingest closure    │ 每个 _raw 源有状态；23/23 可追踪；Solar/QMD 可检索 │
│ P1     │ Status view-model             │ UI 不再显示内部 JSON；显示人类可读任务/风险/动作   │
│ P1     │ Model/pane 配置单源化         │ 配置 UI、model-config、pane-launcher 输出一致      │
│ P1     │ Event schema v2 migration     │ payload/data 统一；老事件兼容读取                  │
│ P2     │ Symphony 迁移边界             │ 明确哪些任务走 pane，哪些任务走 isolated worker    │
│ P2     │ Mirage Drive/QMD 增强         │ Drive credentials 配好；embedding 进度和失败恢复   │
└────────┴──────────────────────────────┴────────────────────────────────────────────────────┘
```

## 10. 推荐下一步合约

建议给 Solar 开一个 P0 合约: `solar-control-plane-consolidation`。

验收标准:

1. 新增 `lib/sprint-lifecycle.py|sh`，所有状态转移通过统一函数，自动写 history + events。
2. `coordinator.sh`、`autopilot`、`status-server` 全部改为读取同一 lifecycle view。
3. `events/all.jsonl` 增加 v2 emitter，兼容旧 `payload/data`。
4. `autopilot` 改为 launchd/loop daemon，默认处理 pane 问老板、ready_for_builder、ready_for_evaluator、stale active。
5. wiki ingest closure 接入 lifecycle，所有 `_raw` 文件都有 per-source manifest 状态。
6. status UI 用 view-model，不直接暴露 sprint id 和 raw JSON 给用户。

## 11. 本轮路线图回写

```
┌──────────────────────────────┬─────────┬──────────────────────────────────────────────┐
│ 路线图                       │ 状态    │ 证据                                         │
├──────────────────────────────┼─────────┼──────────────────────────────────────────────┤
│ P0 盘点真实架构              │ ok      │ 入口、状态、DB、tmux、wiki、Mirage 已盘点     │
│ P1 绘制完整架构图            │ ok      │ 本报告 Mermaid + 独立 .mmd 已落盘             │
│ P2 输出优化路线              │ ok      │ P0/P1/P2 优化表 + 下一步合约已给出            │
└──────────────────────────────┴─────────┴──────────────────────────────────────────────┘
```
