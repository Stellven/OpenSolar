# Mirage VFS — Cortex/Solar Data Access Test Report

**Date**: 2026-05-08
**Tester**: PM (Solar 战略家+治理官 双签)
**Sprint**: `sprint-20260508-mirage-unified-vfs` (S1/S2 builder, no eval yet)
**Verdict**: **PARTIAL / SECURITY GATE FAILED** — 不可宣告 PASS

---

## TL;DR

Mirage 的**读取通路通了**，agents 已能通过 `solar-harness mirage exec/search` 访问 Cortex 文件、Sprint 工件、Knowledge vault、Solar DB（cortex_sources / sys_favorites / fts_unified_search）。但**安全护栏失效** — `deny_subpaths` 和 `redact_on_read` 在执行层完全没接，agent 可通过 mirage 拿到 secrets 明文。

**必须先修 D2，再考虑接入任何自动化链路。**

---

## 测试矩阵

| # | 测试项 | 结果 | 证据 |
|---|---|---|---|
| T1 | `mirage exec "ls /cortex"` | PASS | 列出 30+ 真实 cortex 文件 (`CLOSED-LOOP-README.md` 等) |
| T3 | `mirage exec "ls /sprints"` | PASS | 列出 470+ sprint 工件，与物理目录一致 |
| T5 | `mirage exec "cat /cortex/CLOSED-LOOP-README.md"` | PASS | 7215 bytes 真实 markdown 内容 |
| T6 | `mirage search "Solar" --sources solar_db` | PASS | 8 hits，覆盖 fts_unified_search / cortex_sources / sys_favorites |
| T6b | `mirage search "Cortex"` 三源默认 | PASS | 12 hits (mirage_path 4 + solar_db 4 + qmd 4) |
| T8 | `mirage exec "echo > /knowledge/test.tmp"` | PASS | 命令前置拒绝（ro 路径），磁盘无文件 |
| T8b | `mirage exec "echo > /raw/test.tmp"` | PASS | exit=0，物理文件 16B 写入成功，cleanup ok |
| T9 | `mirage exec "rm /tmp/x"` | PASS | `error: verb not allowed: rm. Allowed: ls,find,grep,cat,head,wc,jq,echo` |
| T11 | 三源混合 search "Symphony Sprint" | WARN | qmd 5 + mirage_path 5，solar_db 0（关键词 KB 里无数据，非 adapter bug） |
| **T7c** | `mirage exec "cat /solar/secrets/solar-user-secrets.env"` | **FAIL P0** | **ZHIPU_API_KEY 真实 token 明文泄露 232 字节，deny_subpaths + redact 双失效** |
| D3 | `--json` 参数串污染 | WARN P1 | 所有 exec 调用 stderr 含 `cat: --json: No such file or directory`，exit_code 误报 1 但 stdout 正确 |
| T10 | redact_on_read on .md | BLOCKED | 样本不含真 token，未触发 4 个 redact 模式（需用真 secret 文件再测） |

---

## 缺陷清单

### D2 (P0 SECURITY) — `deny_subpaths` + `redact_on_read` 在 exec 通路失效

- **配置 (mirage.solar.yaml)**:
  ```yaml
  - path: /solar
    mode: ro
    redact_on_read: true
    deny_subpaths: ["secrets/", ".env", ".token", "credentials"]
  ```
- **实测**: `mirage exec "cat /solar/secrets/solar-user-secrets.env"` → exit=1（cat 把 --json 当文件名失败），但 stdout 仍输出 ZHIPU_API_KEY 真实 token 明文。
- **根因 (源码定位)**: `/Users/sihaoli/.solar/harness/lib/solar_mirage.py` 的 `_resolve_mount` (约 503-520 行) 只检查路径前缀匹配 + virtual mount block，**没读 `deny_subpaths` 字段**，也没在物理执行后对 stdout 跑 `redact_patterns` regex。
- **影响**: 任何能调 `solar-harness mirage exec` 的 agent / sprint / hook 都能拿到 secrets 明文。Mirage 直接绕过了 Solar 的 secret 防护。
- **临时缓解**: 在 fix 部署前，**禁止在 yaml allowlist 之外暴露 mirage exec 给非可信 agent**。

### D3 (P1 体验/正确性) — `--json` 参数串污染内部 cmd

- **现象**: `solar-harness mirage exec "ls /cortex" --json` 实际拼成 `ls /cortex --json` 跑给 ls/cat/find/head，导致 stderr 永远报 `... --json: No such file or directory`、exit_code 误报 1，但 stdout 数据正确。
- **根因**: `solar_mirage.py` 的 argparse 用 `nargs=REMAINDER` 接 cmd 时，把外层 `--json` 一起捞进了 cmd 列表。
- **修复**: argparse 用 `--` 分隔，或显式把 `--json` 在 cmd 拼接前 strip。

### D4 (P2 待补) — redact_on_read 实战覆盖未验证

- T10 用 `.md` 文档样本读 mirage，未观察到 redaction 触发；样本本身不含 4 个 redact 模式（sk-xxx / Bearer / api_key= / client_secret= / refresh_token=）。
- 真测应用 `solar-user-secrets.env` 这类样本，但已被 D2 阻塞（deny_subpaths 应先拒，结果直接读出明文）。

---

## 已验证能力（可放心用）

1. **路径映射**：`/cortex` `/sprints` `/solar` `/knowledge` `/raw` `/qmd` 物理路径正确解析
2. **读取**：ls/cat/find/grep/head/wc/jq/echo 在 ro 路径全部工作
3. **写保护**：`/knowledge` 等 ro 路径写操作前置拒绝
4. **写入 staging**：`/raw` rw 模式正常写入
5. **命令白名单**：rm/mv/cp/sh 等危险动词被拒
6. **统一搜索**：`mirage search` 三源（mirage_path / qmd / solar_db）混合检索接通
7. **Solar DB 检索**：通过 `solar-knowledge-context.py` 透传到 cortex_sources(580) / sys_favorites(157) / fts_unified_search(1815)

---

## 推荐 Fix-Dispatch

详见 `sprint-20260508-mirage-unified-vfs.fix-dispatch-test.md`。

| Fix | Owner | 优先级 | Write Scope |
|-----|-------|--------|-------------|
| F-D2-A 实现 deny_subpaths 拦截 | builder_main | P0 | `lib/solar_mirage.py` `_resolve_mount` |
| F-D2-B 在 exec 完成后对 stdout 跑 redact_patterns | builder_main | P0 | `lib/solar_mirage.py` `cmd_exec` |
| F-D3 `--json` 隔离不串到 inner cmd | builder_main | P1 | `lib/solar_mirage.py` argparse |
| F-D4 用真样本回归 redact_on_read | evaluator | P2 | tests/test-mirage-unified-vfs.sh |

---

## 复现命令（read-only，无副作用）

```bash
# Doctor
solar-harness mirage doctor --json | python3 -m json.tool | head -20

# Read /cortex
solar-harness mirage exec "ls /cortex" --json
solar-harness mirage exec "cat /cortex/CLOSED-LOOP-README.md" --json | jq -r '.stdout' | head

# Solar DB search
solar-harness mirage search "Solar" --max-hits 5 --sources solar_db --json

# Three-source search
solar-harness mirage search "Cortex" --max-hits 12 --json | jq '.hits | group_by(.source_type) | map({src: .[0].source_type, n: length})'

# Write protection (should refuse)
solar-harness mirage exec "echo X > /knowledge/test.tmp" --json

# Allowlist refusal
solar-harness mirage exec "rm /tmp/x" --json

# P0 SECURITY (do NOT run, output contains live secrets):
# solar-harness mirage exec "cat /solar/secrets/solar-user-secrets.env" --json
```

---

## 下一步

1. **立即**：把本报告 + fix-dispatch 提到 sprint-20260508-mirage-unified-vfs eval 阶段；状态从 reviewing 切到 fix_required。
2. **D2 修复后**：重跑 T7c + T10 + 新增 redact 模式回归。
3. **修复落地后**：才能让 sprint-20260508-solar-kb-obsidian-autouse 把 mirage 接成默认检索通道。

---

*Generated by Solar PM (战略家+治理官 双签) on 2026-05-08*
