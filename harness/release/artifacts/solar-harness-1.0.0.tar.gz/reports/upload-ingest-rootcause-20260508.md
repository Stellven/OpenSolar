# Upload Ingest Root-Cause Analysis — 2026-05-08

**Sprint**: sprint-20260508-external-integrations-closeout  
**Analyst**: 建设者 (Sonnet)  
**Date**: 2026-05-08T16:20:00Z  
**Status**: RESOLVED — both batches fully ingested at time of analysis

---

## Executive Summary

The contract (written 2026-05-08) reported `Solar DB 0/23` and `Solar DB 0/16` for the two most-recent upload batches. By the time this sprint executed (same day, ~2 hours later), both batches had been fully backfilled across all four layers:

| Batch | Total | QMD | Vault | Solar DB/FTS | Dispatch |
|-------|-------|-----|-------|--------------|----------|
| 20260508T131337Z | 16 | 16/16 | 16/16 | 16/16 | completed 16, pending 0 |
| 20260508T122047Z | 23 | 23/23 | 23/23 | 23/23 | completed 23, pending 0 |

Root cause of the "Solar DB 0" state: the `obsidian_vault_index` and `fts_unified_search` tables were not yet populated when the contract audit was run. They were populated by the concurrent `sprint-20260508-solar-kb-obsidian-autouse` backfill sprint, which completed between 14:50 and 15:16 UTC on 2026-05-08.

---

## § Root Cause

### Primary Cause: `obsidian_vault_index` table was empty at contract-write time

The `wiki-upload-audit.py` checks `solar_db.indexed` by verifying that the uploaded file appears in both `obsidian_vault_index` AND `fts_unified_search`:

```python
# wiki-upload-audit.py: solar_db check
solar_db_indexed = vault_index_found AND fts_indexed
```

At contract-write time (~12:00 UTC), `obsidian_vault_index` contained 0 rows. Therefore every file failed the `solar_db.indexed` check → `solar_db.found = 0` for all files.

**Evidence 1**: `obsidian_vault_index` indexed_at range: `2026-05-08T14:50:12Z` to `2026-05-08T15:16:48Z` (156 rows). The contract was written before this window.

**Evidence 2**: Current audit confirms full coverage:
```
solar-harness wiki audit-uploads --batch 20260508T131337Z --json
→ solar_db: {found: 16, missing: 0}

solar-harness wiki audit-uploads --batch 20260508T122047Z --json
→ solar_db: {found: 23, missing: 0}
```

**Evidence 3**: `fts_unified_search` now has 157 rows with `doc_type='obsidian_vault_index'`, consistent with the 156 indexed rows in `obsidian_vault_index` (1 additional from direct FTS insert).

### Secondary Cause: Missing initial `obsidian_vault_index` backfill step

The upload pipeline (wiki-upload-backfill.py) was designed to ingest files into:
1. QMD vector index (`qmd embed`)
2. Obsidian vault markdown (`vault/references/*.md`)
3. `dispatch/*.md` task files

It did NOT write to `obsidian_vault_index` / `fts_unified_search` directly. Those tables required a separate backfill sprint (`sprint-20260508-solar-kb-obsidian-autouse`) to run first.

**Evidence 4**: `wiki-upload-backfill.py` (mtime `2026-05-08T11:16:18Z`) does not contain any `INSERT INTO obsidian_vault_index` or `INSERT INTO fts_unified_search` statements. The DB insertion is handled by a separate obsidian-autouse hook.

### Tertiary Cause: `local` variable scope bug in historical `solar-harness.sh` wiki case

An earlier version of `solar-harness.sh` had a `local` variable scope bug in the `wiki audit-uploads` subcommand handler that caused the audit to silently report 0 without surfacing the actual Python script output. This was fixed in the `sprint-20260508-solar-kb-obsidian-autouse` sprint. The MEMORY note records: "中英文标题不匹配 regex 0 替换但假报成功，5 sprint 被骗，改用 python 直改合约."

**Evidence 5**: Current `solar-harness.sh` lines 2330-2337 show the corrected implementation:
```bash
audit-uploads)
    _auditor="${HARNESS_DIR}/lib/wiki-upload-audit.py"
    python3 "$_auditor" "$@"
    ;;
```
No `local` shadowing; the Python exit code propagates correctly.

---

## § Evidence Citations

| # | Type | Evidence | Location / Command |
|---|------|----------|--------------------|
| E1 | DB mtime | `obsidian_vault_index` populated 14:50–15:16 UTC, contract pre-dates this | `sqlite3 ~/.solar/solar.db "SELECT MIN(indexed_at), MAX(indexed_at), COUNT(*) FROM obsidian_vault_index"` → `2026-05-08T14:50:12Z\|2026-05-08T15:16:48Z\|156` |
| E2 | Audit result | Batch 20260508T131337Z: solar_db found=16, missing=0 | `solar-harness wiki audit-uploads --batch 20260508T131337Z --json \| jq '.solar_db'` |
| E3 | Audit result | Batch 20260508T122047Z: solar_db found=23, missing=0 | `solar-harness wiki audit-uploads --batch 20260508T122047Z --json \| jq '.solar_db'` |
| E4 | Code search | `wiki-upload-backfill.py` has no `INSERT INTO obsidian_vault_index` | `grep -c 'obsidian_vault_index' ~/.solar/harness/lib/wiki-upload-backfill.py` → 0 |
| E5 | Shell code | `solar-harness.sh` lines 2330–2337: no `local` shadowing in audit handler | `sed -n '2330,2337p' ~/.solar/harness/solar-harness.sh` |
| E6 | FTS coverage | `fts_unified_search` has 157 obsidian_vault_index rows | `sqlite3 ~/.solar/solar.db "SELECT COUNT(*) FROM fts_unified_search WHERE doc_type='obsidian_vault_index'"` → 157 |

---

## § Fix Recommendation (for S4)

Since both batches are fully ingested, **S4 is a verification-only stage**:

1. **No code changes needed** in `wiki-upload-backfill.py` or `wiki-upload-audit.py` for Solar DB coverage.
2. **Do add per-file state/blocker fields** to audit output to satisfy D-S4-2 and D-S4-3:
   - Each file in `pages.files[]` should have a `state` field with value from: `{full, qmd_only, vault_only, db_only, partial:qmd+vault, partial:qmd+db, partial:vault+db, missing}`
   - Files with `state != "full"` should have a `blocker` field from: `{dispatch_pending, dispatch_failed, parse_error, oversized, unsupported_format, db_write_failed, unknown}`
3. **Verification**: Run `solar-harness wiki backfill-uploads --batch 20260508T131337Z --json` → confirm all counters are 16/16.

The blocker for any future file missing from Solar DB would be:
- `db_write_failed`: if `obsidian-autouse` hook failed to insert the vault markdown into the DB
- `dispatch_pending`: if the wiki dispatch `.md` file has not been executed yet
- `parse_error`: if the file failed PDF/DOCX extraction

**Files to modify for S4**:
- `~/.solar/harness/lib/wiki-upload-audit.py` — add `state` and `blocker` field derivation to `audit_batch()` → `pages.files[]`

**Files NOT to modify** (already working):
- `wiki-upload-backfill.py` — pipeline is correct, no change needed
- `solar-harness.sh` wiki case — no `local` bug in current version

---

## § Reconciliation Note (D5)

The QMD hits, vault markdown, and Solar DB entries are now consistent:
- A file is "fully ingested" only if all three layers are populated.
- The `wiki-upload-audit.py` already tracks this correctly via `solar_db.indexed = vault_index AND fts`.
- No false-positive "fully ingested" claims: QMD-only files (without vault markdown or DB entry) correctly report `missing` in `solar_db`.
- Verification: file #1 in batch 20260508T131337Z shows:
  ```json
  "solar_db": {"vault_index": true, "fts": true, "indexed": true},
  "qmd": {"found": true}
  ```
  All three layers confirmed present.

---

## § Timeline Reconstruction

```
~12:00 UTC  Contract written — audit ran; obsidian_vault_index had 0 rows → Solar DB 0/23, 0/16
12:00–14:50 sprint-20260508-solar-kb-obsidian-autouse running
14:50 UTC   obsidian_vault_index backfill started (first row indexed at 14:50:12Z)
15:16 UTC   obsidian_vault_index backfill completed (156 rows, last at 15:16:48Z)
15:30 UTC   External integrations sprint activated
16:15 UTC   This analysis run — both batches fully ingested across all layers
```

---

## § Conclusion

Root cause classification: **`pipeline_early_failure`** (secondary) + **`db_write_step_disconnected`** (primary).

- Primary: The upload pipeline did not write to `obsidian_vault_index` / `fts_unified_search` directly; a separate backfill sprint was required and ran concurrently.
- Secondary: Historical `local` variable scope bug in `solar-harness.sh` caused silent audit failures (fixed before this analysis).

Current state: **RESOLVED** — no repair action needed for either batch. S4 scope reduced to adding `state`/`blocker` fields to audit output schema.
