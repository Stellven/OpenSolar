# Solar External Integrations Audit — Final Report
**Date**: 2026-05-08  
**Sprint**: sprint-20260508-external-integrations-closeout  
**Author**: 建设者化身 (Claude Sonnet 4.6)  
**Status**: FINAL

---

## § 1 Executive Summary

This sprint audited and hardened the representation of all seven external open-source integrations in the Solar Harness system. The goals were accuracy, honest labelling of degraded/logical services, and infrastructure to detect future drift.

### Final Health Snapshot (2026-05-08 ~16:30 UTC)

| Integration | Status | Key Facts |
|-------------|--------|-----------|
| Ar9av/obsidian-wiki | warn | capture port 8788 not open; vault has 5,291 md files; context hook wired |
| opendatalab/MinerU + QMD | warn | 1,472 files indexed, 1,928 vectors; MCP port 8181 not open |
| mermaid-js/mermaid | warn | viewer port 8765 IS open (status server); 24 .mmd reports |
| openai/symphony | warn | dry-run sidecar only; does NOT run builders; coordinator/tmux is executor |
| strukto-ai/mirage | warn | Solar logical wrapper only; NOT official SDK/FUSE; Drive = logical mount |
| camel-ai/owl | warn | installed at ~/.solar/owl but NOT connected to coordinator/events/evaluator |
| Google Drive mount | warn | logical namespace only; GOOGLE_APPLICATION_CREDENTIALS not set |

**Summary**: 1 ok / 6 warn / 0 missing out of 7 integrations.

---

## § 2 Upload Ingest — Root Cause & Resolution (D4/D5)

### Problem at Contract-Write Time

When the sprint contract was written (~12:00 UTC 2026-05-08), the audit tool `wiki-upload-audit.py` reported `Solar DB 0/23` and `Solar DB 0/16` for the two most-recent upload batches.

**Root Cause**: `obsidian_vault_index` had 0 rows at contract-write time. The upload pipeline (wiki-upload-backfill.py) never writes to `obsidian_vault_index` directly; a concurrent backfill sprint (`sprint-20260508-solar-kb-obsidian-autouse`) was required first, and it populated the table between 14:50–15:16 UTC.

### Resolution Verification

Both batches are now fully ingested across all four layers:

| Batch | Total | QMD | Vault | Solar DB | Dispatch |
|-------|-------|-----|-------|----------|----------|
| 20260508T131337Z | 16 | 16/16 ✅ | 16/16 ✅ | 16/16 ✅ | 0 pending ✅ |
| 20260508T122047Z | 23 | 23/23 ✅ | 23/23 ✅ | 23/23 ✅ | 0 pending ✅ |

### QMD-Only Reconciliation (D5)

The audit tool previously could not distinguish between "QMD indexed but not in Solar DB" vs "fully ingested". This sprint introduced a **`state` field** on every per-file entry:

```
state enum: full | qmd_only | vault_only | db_only |
            partial:qmd+vault | partial:qmd+db | partial:vault+db | missing
```

A file with `state != "full"` also receives a `blocker` field:
```
blocker enum: dispatch_pending | dispatch_failed | parse_error |
              oversized | unsupported_format | db_write_failed | unknown
```

For both audited batches, all files report `state: full` — no QMD-only false positives.

---

## § 3 Integration Wording Accuracy (D6/D7/D8)

Prior to this sprint, the health probe contained ambiguous descriptions that implied official SDK connections or active execution roles. All three were corrected:

### D6 — Mirage: Solar Logical Wrapper vs Official SDK/FUSE

**Before**: `evidence.sdk = "none"`, `evidence.drive = "degraded"` — unclear whether Mirage SDK was installed.

**After**:
```json
"evidence": {
  "sdk": { "kind": "solar-logical" },
  "drive": {
    "state": "credentials_missing",
    "degraded_reason": "GOOGLE_APPLICATION_CREDENTIALS not set; /drive is logical mount only"
  }
}
```

Purpose field explicitly states: *"NOT official Mirage SDK/FUSE; Drive is a logical mount that requires credentials to become real."*

### D7 — Symphony: Dry-Run Sidecar vs Primary Executor

**Before**: No `mode` field, no `executes_builders` flag. A reader could infer Symphony was orchestrating builders.

**After**:
```json
"evidence": {
  "mode": "dry_run_sidecar",
  "executes_builders": false
}
```

Purpose field: *"coordinator/tmux is the real executor; Symphony does not run builders."*  
Degraded reason: *"dry-run/sidecar only — coordinator/tmux remains primary executor; Symphony SPEC patterns adopted but not orchestrating builders"*

### D8 — OWL: Not Connected to Solar

**Before**: OWL appeared in the integrations list without a clear "not connected" signal.

**After**:
```json
"evidence": {
  "connection_status": "not_connected"
}
```

`running = false`, `indexed = false`, `used_by_default = false`. Degraded reason: *"未连接（如需提级须新 sprint）— not connected to coordinator lifecycle, events, evaluator, or knowledge closeout"*

---

## § 4 Schema Freeze (D1/D2)

### Schema File

`/Users/sihaoli/.solar/harness/schemas/integrations.schema.json` was created and frozen as of 2026-05-08. Key constraints:

- `integrations` array: exactly 7 items
- Each item requires all six-state fields: `installed`, `configured`, `running`, `indexed`, `used_by_default`, `degraded_reason`, plus `status`, `evidence`
- `status` enum: `["ok", "warn", "missing"]`
- Supporting enum definitions: `sdk_kind`, `drive_state`, `symphony_mode`, `owl_connection_status`

### CLI Endpoint

```bash
solar-harness integrations status --json
```

Calls `external-integrations-health.py --json`, returns the full 7-integration payload. The `--refresh` flag bypasses the 120s cache.

### HTTP Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /integrations` | JSON payload (schema-compliant) |
| `GET /integrations-view` | Human-readable HTML tab (server-side rendered) |

Both endpoints were added to `lib/symphony/status-server.py`. The `/integrations-view` endpoint renders integration cards server-side (Python f-string template), so all integration names appear in the HTML source without JavaScript execution — enabling grep-based verification.

---

## § 5 Status UI — Integrations Tab (D3)

The `/integrations-view` HTML page provides:

- **Summary strip**: TOTAL / OK / WARN / MISSING counts
- **Per-integration cards** with:
  - Name and purpose
  - Status badge (ok/warn/missing)
  - Five-state pills: 安装 | 配置 | 运行 | 索引 | 默认
  - Degraded reason (when present)
  - Collapsible evidence detail (JSON)
- **Server-side rendered**: all 7 integration names embedded in HTML at response time

Verification:
```bash
curl -s http://127.0.0.1:8765/integrations-view -o /tmp/iv.html
grep -ic -E 'obsidian-wiki|MinerU|mermaid|symphony|mirage|owl|[Gg]oogle' /tmp/iv.html
# → 164 (all 7 names appear multiple times in HTML source)
```

The existing `/status` endpoint was not broken by the addition.

---

## § 6 Test Suite (D9)

Five test scripts were created under `tests/external-integrations/`:

| Script | Tests | What it covers |
|--------|-------|----------------|
| `test_schema_health.sh` | 10 | Probe JSON schema validity, 7 integrations, 6-state fields, status enum, summary counts |
| `test_wording_flags.sh` | 8 | D6 Mirage sdk.kind/drive.state, D7 Symphony mode/executes_builders/running, D8 OWL connection_status/running/used_by_default |
| `test_audit_uploads.sh` | 7 | Audit CLI: valid JSON, required keys, `state` field presence, enum validity, `blocker` for non-full files |
| `test_upload_ingest_coverage.sh` | 10 | Both target batches: qmd/vault/solar_db fully covered, dispatch pending=0, no qmd_only files |
| `test_endpoint_view.sh` | 7 | /integrations JSON, /integrations-view HTML, doctype present, all 7 names in HTML, /status not broken, /healthz |

**Run all**: `bash tests/external-integrations/run-all.sh`  
**Final result**: 5/5 suites PASS, 42/42 individual checks PASS.

---

## § 7 Remaining Conflicts & Owner / Next Action

| Item | Owner | Priority | Next Action |
|------|-------|----------|-------------|
| obsidian-wiki capture port 8788 not open | Infrastructure | Medium | Diagnose why `_raw/file-uploads` capture service not running; likely needs launchd plist |
| QMD MCP port 8181 not open | Infrastructure | Medium | `solar-harness qmd start` or check launchd `com.solar.qmd-mineru-embed.plist` |
| OWL not connected to Solar coordinator | Architecture | Low | New sprint required: define event bridge, evaluate Sprint, connect to evaluator pipeline |
| Google Drive credentials | Configuration | Low | Set `GOOGLE_APPLICATION_CREDENTIALS` env var to enable real Drive sync via Mirage |
| Symphony `running = false` | By design | N/A | Intentional — Symphony is dry-run sidecar; coordinator/tmux remains executor |
| Mirage Drive logical mount | By design | N/A | Real Drive requires credentials; logical VFS wrapper is current intended mode |
| QMD 0 pending files | None | ✅ Resolved | 1,928 vectors present; embed pipeline healthy |
| Upload ingest Solar DB 0/23 | None | ✅ Resolved | Both batches fully ingested; root cause documented |

---

## § Appendix: Changed Files

| File | Change |
|------|--------|
| `reports/upload-ingest-rootcause-20260508.md` | Created — 147-line root-cause analysis |
| `schemas/integrations.schema.json` | Created — frozen schema with 4 enum definitions |
| `lib/external-integrations-health.py` | Edited — Mirage sdk/drive fields, Symphony mode/executes_builders, OWL connection_status, Drive state |
| `lib/symphony/status-server.py` | Edited — added `_integrations_view_html()`, `/integrations-view` route, fixed `item.states` bug |
| `lib/wiki-upload-audit.py` | Edited — added `_derive_state()`, `_derive_blocker()`, `state`/`blocker` fields on per-file entries |
| `tests/external-integrations/test_schema_health.sh` | Created |
| `tests/external-integrations/test_wording_flags.sh` | Created |
| `tests/external-integrations/test_audit_uploads.sh` | Created |
| `tests/external-integrations/test_upload_ingest_coverage.sh` | Created |
| `tests/external-integrations/test_endpoint_view.sh` | Created |
| `tests/external-integrations/run-all.sh` | Created |

---

*Report generated: 2026-05-08*  
*Sprint: sprint-20260508-external-integrations-closeout*
