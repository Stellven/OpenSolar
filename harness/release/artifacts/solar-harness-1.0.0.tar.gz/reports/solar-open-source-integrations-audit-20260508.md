# Solar 外部开源/外部项目集成审计

生成时间: 2026-05-08  
范围: `~/.solar/harness/vendor`, `~/.solar/harness/docs`, `~/.solar/owl`, `solar-harness` CLI, `status-server`, `qmd`, `mirage`, `wiki upload audit`

## 总结

Solar 目前已经接入或半接入多个外部项目，但成熟度不一致。最稳定的是 Mermaid、QMD/MinerU 搜索、Obsidian Wiki 基础配置；最需要修的是 Wiki 上传入库闭环、Mirage 官方 SDK/Drive、OWL 与 harness 主控制面的关系、Symphony 与 coordinator 的双轨边界。

```
┌──────────────────────────────┬─────────┬─────────┬─────────┬──────────────────────────────────────────────┐
│ 项目                         │ 可用    │ 被使用  │ 断头    │ 结论                                         │
├──────────────────────────────┼─────────┼─────────┼─────────┼──────────────────────────────────────────────┤
│ Ar9av/obsidian-wiki          │ ok      │ warn    │ warn    │ Vault/skills 可用；ingest 自动闭环不完整     │
│ MinerU Document Explorer/QMD │ ok      │ ok      │ warn    │ 搜索可用；303 文件待 embedding               │
│ mermaid-js/mermaid           │ ok      │ ok      │ ok      │ 已接入 status-server /mermaid                │
│ openai/symphony              │ warn    │ warn    │ warn    │ 只吸收 SPEC，本地 dry-run 层，不是主执行器    │
│ strukto-ai/mirage            │ warn    │ ok      │ warn    │ Solar 自写逻辑 VFS；官方 SDK 未安装          │
│ camel-ai/owl                 │ warn    │ pending │ warn    │ 仓库存在；未纳入 harness 主调度              │
│ Google Drive                 │ warn    │ pending │ warn    │ Mirage mount 存在；无 credentials            │
│ affaan-m/everything-claude-code │ pending │ pending │ warn    │ 未落地；已登记 P1 集成合约，需审计后再接入    │
└──────────────────────────────┴─────────┴─────────┴─────────┴──────────────────────────────────────────────┘
```

## 明细

```
┌──────────────────────────────┬────────────────────────────────────────────────────┐
│ 项目                         │ https://github.com/Ar9av/obsidian-wiki             │
├──────────────────────────────┼────────────────────────────────────────────────────┤
│ 是什么                       │ Agent 驱动的 Obsidian 知识库技能链                 │
│ 集成进来干啥                 │ 把 Sprint、网页、上传文档、历史会话沉淀成可读知识库 │
│ 本地位置                     │ ~/.solar/harness/vendor/obsidian-wiki              │
│ 当前状态                     │ configured=true；vault=/Users/sihaoli/Knowledge    │
│ 被用到吗                     │ 是：wiki status/query/export/capture/status UI      │
│ 可用吗                       │ 基础可用；capture server 已恢复运行                │
│ 断头                         │ ingest dispatch 依赖 agent 执行；上传批次入库不完整 │
│ 冲突                         │ 与 QMD/Solar DB 分工未完全收敛，存在多事实源        │
└──────────────────────────────┴────────────────────────────────────────────────────┘
```

```
┌──────────────────────────────┬────────────────────────────────────────────────────┐
│ 项目                         │ https://github.com/opendatalab/MinerU-Document-Explorer │
├──────────────────────────────┼────────────────────────────────────────────────────┤
│ 是什么                       │ 文档探索/索引工具；Solar 中主要通过 qmd 使用       │
│ 集成进来干啥                 │ 让 PDF/DOCX/PPTX/MD 等能进入本地检索和语义检索     │
│ 本地位置                     │ ~/.solar/harness/vendor/MinerU-Document-Explorer；qmd 全局 npm │
│ 当前状态                     │ mineru-document-explorer@1.0.9；qmd MCP running :8181 │
│ 被用到吗                     │ 是：wiki qmd-search、mirage search、status health   │
│ 可用吗                       │ 可用；solar-wiki 有 1420 files indexed             │
│ 断头                         │ 303 need embedding；上传批次 23 个里 QMD 仅 15 命中 │
│ 冲突                         │ QMD 索引存在但 Solar DB/Obsidian 页面未同步，用户会误以为已入库 │
└──────────────────────────────┴────────────────────────────────────────────────────┘
```

```
┌──────────────────────────────┬────────────────────────────────────────────────────┐
│ 项目                         │ https://github.com/mermaid-js/mermaid              │
├──────────────────────────────┼────────────────────────────────────────────────────┤
│ 是什么                       │ Mermaid 图表渲染引擎                               │
│ 集成进来干啥                 │ 让 Solar 直接浏览和渲染 .mmd 架构图                │
│ 本地位置                     │ ~/.solar/harness/vendor/mermaid-viewer/node_modules/mermaid │
│ 当前状态                     │ mermaid@11.14.0；/mermaid 可访问                   │
│ 被用到吗                     │ 是：status-server 架构图页、reports/*.mmd          │
│ 可用吗                       │ 可用                                                │
│ 断头                         │ 无核心断头；可选增强是 SVG/PNG 导出                │
│ 冲突                         │ 无；只读渲染，不影响执行链路                       │
└──────────────────────────────┴────────────────────────────────────────────────────┘
```

```
┌──────────────────────────────┬────────────────────────────────────────────────────┐
│ 项目                         │ https://github.com/openai/symphony                 │
├──────────────────────────────┼────────────────────────────────────────────────────┤
│ 是什么                       │ AI coding agents orchestration SPEC                │
│ 集成进来干啥                 │ 引入 WORKFLOW、workspace isolation、hooks、events   │
│ 本地位置                     │ ~/.solar/harness/lib/symphony/*                    │
│ 当前状态                     │ completed=1；claimed/running/retry=0；dry-run 为主 │
│ 被用到吗                     │ 部分：workspace/hooks/events/status-server          │
│ 可用吗                       │ 基础模块可用；不是主执行路径                       │
│ 断头                         │ runner 默认 dry-run；未接管主 Builder 执行          │
│ 冲突                         │ 与 coordinator 形成双轨；需要明确边界避免状态分裂  │
└──────────────────────────────┴────────────────────────────────────────────────────┘
```

```
┌──────────────────────────────┬────────────────────────────────────────────────────┐
│ 项目                         │ https://github.com/strukto-ai/mirage               │
├──────────────────────────────┼────────────────────────────────────────────────────┤
│ 是什么                       │ 虚拟/统一文件系统理念                              │
│ 集成进来干啥                 │ 让 Solar/Codex 统一访问 Knowledge、Raw、Sprints、Solar DB、QMD、Drive │
│ 本地位置                     │ ~/.solar/harness/lib/solar_mirage.py；config/mirage.solar.yaml │
│ 当前状态                     │ Solar 自写 logical VFS 可用；Mirage SDK 未安装     │
│ 被用到吗                     │ 是：mirage doctor/search/exec，status-server health │
│ 可用吗                       │ 本地逻辑模式可用；/drive degraded                  │
│ 断头                         │ 官方 SDK/FUSE 未接入；Drive 无 credentials；/projects allowlist empty │
│ 冲突                         │ 名义上是 Mirage，实际是 Solar wrapper；需避免误认为完整官方集成 │
└──────────────────────────────┴────────────────────────────────────────────────────┘
```

```
┌──────────────────────────────┬────────────────────────────────────────────────────┐
│ 项目                         │ https://github.com/camel-ai/owl                    │
├──────────────────────────────┼────────────────────────────────────────────────────┤
│ 是什么                       │ 多 Agent/浏览器/任务执行框架                       │
│ 集成进来干啥                 │ 预期作为外部 agent 执行能力或复杂任务 worker       │
│ 本地位置                     │ ~/.solar/owl                                       │
│ 当前状态                     │ repo 存在；有本地 service 脚本改动                 │
│ 被用到吗                     │ 当前未看到 harness 主链路使用                      │
│ 可用吗                       │ 未验证为 Solar 可调 worker                         │
│ 断头                         │ 未纳入 coordinator/autopilot/status-server lifecycle │
│ 冲突                         │ 如果直接跑，会绕过 Solar 的事件、验收、知识入库闭环 │
└──────────────────────────────┴────────────────────────────────────────────────────┘
```

```
┌──────────────────────────────┬────────────────────────────────────────────────────┐
│ 项目                         │ https://github.com/affaan-m/everything-claude-code │
├──────────────────────────────┼────────────────────────────────────────────────────┤
│ 是什么                       │ Claude Code agents/skills/hooks/commands/rules/MCP 配置合集 │
│ 集成进来干啥                 │ 候选增强 Solar 的 agent ecosystem、验证循环、记忆/技能/命令体系 │
│ 本地位置                     │ 未安装；目标位置 ~/.solar/harness/vendor/everything-claude-code │
│ 当前状态                     │ candidate only；已生成 sprint-20260508-everything-claude-code-integration │
│ 被用到吗                     │ 否                                                   │
│ 可用吗                       │ GitHub 可访问，本机未接入                            │
│ 断头                         │ 是：此前没有 active artifact，容易被记忆误判为已集成  │
│ 冲突                         │ 可能与 Gstack、Superpowers、Solar hooks、Claude settings 冲突 │
└──────────────────────────────┴────────────────────────────────────────────────────┘
```

```
┌──────────────────────────────┬────────────────────────────────────────────────────┐
│ 项目                         │ Google Drive external mount                         │
├──────────────────────────────┼────────────────────────────────────────────────────┤
│ 是什么                       │ 外部云盘数据源，不是开源项目                       │
│ 集成进来干啥                 │ 作为 Mirage /drive 数据源                           │
│ 本地位置                     │ config/mirage.solar.yaml                            │
│ 当前状态                     │ degraded: no credentials found                      │
│ 被用到吗                     │ 否，当前只是 optional mount                         │
│ 可用吗                       │ 不可用，缺 GOOGLE_APPLICATION_CREDENTIALS           │
│ 断头                         │ 是                                                   │
│ 冲突                         │ 无直接冲突；但 UI 应标成“未配置”，不能显示为 ready  │
└──────────────────────────────┴────────────────────────────────────────────────────┘
```

## 关键断头

```
┌────────┬──────────────────────────────┬──────────────────────────────────────────────┐
│ 优先级 │ 断头                         │ 证据                                         │
├────────┼──────────────────────────────┼──────────────────────────────────────────────┤
│ P0     │ Wiki 上传入库闭环不完整       │ 最新有效批次 16 原件: QMD 14, Vault 12, Solar DB 0；历史批次 23 原件: QMD 15, Vault 6, Solar DB 0 │
│ P0     │ Obsidian/QMD/Solar DB 多事实源 │ QMD 能搜到，不等于 Vault 页面和 Solar DB 已入库 │
│ P1     │ Mirage 官方 SDK 未接入        │ `import mirage` failed；当前是 logical wrapper │
│ P1     │ Drive mount 不可用            │ no credentials found                         │
│ P1     │ Symphony 未接管真实执行       │ status completed=1, running=0；dry-run 为主   │
│ P1     │ OWL 仓库未纳入主调度          │ repo 存在，但 harness 没有统一生命周期管理    │
└────────┴──────────────────────────────┴──────────────────────────────────────────────┘
```

## 已顺手修复

- `solar-harness wiki capture-server` 已恢复运行: `http://127.0.0.1:8788`
- 修复 `solar-harness wiki audit-uploads/backfill-uploads` 顶层 `local` shell bug
- 新增 `solar-harness integrations status [--json]`
- 新增 status-server `GET /integrations`
- 新增 `/Users/sihaoli/.solar/harness/lib/external-integrations-health.py`，统一 installed/configured/running/indexed/used_by_default/degraded_reason 六态

## 建议

下一步不应该继续加新项目。应先开一个 P0 closeout sprint：统一外部集成状态模型，至少把每个集成都变成 `installed / configured / running / indexed / used_by_default / degraded_reason` 六态，并让 status UI 按这个显示。
