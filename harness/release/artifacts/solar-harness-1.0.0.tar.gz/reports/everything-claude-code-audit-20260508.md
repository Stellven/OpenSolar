# Everything Claude Code Solar Integration Audit

Generated: 2026-05-08T17:27:08Z
Source: https://github.com/affaan-m/everything-claude-code.git
Commit: `841beea45cb25ba51f29fa45b7e272938d19b80a`
Local vendor: `/Users/sihaoli/.solar/harness/vendor/everything-claude-code`

## Verdict

Status: `candidate only`.

The upstream repo is vendored for audit. Nothing has been installed into live Claude, Codex, Gstack, or Solar config. Hooks are especially high-risk and must remain staged until allowlisted.

## Inventory Counts

```text
┌─────────────┬───────┐
│ Surface     │ Count │
├─────────────┼───────┤
│ agents      │    80 │
│ commands    │   117 │
│ contexts    │     5 │
│ hooks       │    72 │
│ mcp_configs │     2 │
│ rules       │   130 │
│ scripts     │   157 │
│ skills      │    61 │
│ tests       │   117 │
└─────────────┴───────┘
```

## Collision Summary

Collision count: `41`

```text
┌──────────┬────────────────────────────┬────────────────────────────────────────────┐
│ Surface  │ Key                        │ Local                                      │
├──────────┼────────────────────────────┼────────────────────────────────────────────┤
│ skills   │ api-design                 │ /Users/sihaoli/.agents/skills/api-design   │
│ skills   │ article-writing            │ ers/sihaoli/.agents/skills/article-writing │
│ skills   │ backend-patterns           │ rs/sihaoli/.agents/skills/backend-patterns │
│ skills   │ coding-standards           │ rs/sihaoli/.agents/skills/coding-standards │
│ skills   │ content-engine             │ sers/sihaoli/.agents/skills/content-engine │
│ skills   │ deep-research              │ Users/sihaoli/.agents/skills/deep-research │
│ skills   │ e2e-testing                │ /Users/sihaoli/.agents/skills/e2e-testing  │
│ skills   │ eval-harness               │ /Users/sihaoli/.agents/skills/eval-harness │
│ skills   │ exa-search                 │ /Users/sihaoli/.agents/skills/exa-search   │
│ skills   │ frontend-patterns          │ s/sihaoli/.agents/skills/frontend-patterns │
│ skills   │ frontend-slides            │ ers/sihaoli/.agents/skills/frontend-slides │
│ skills   │ investor-materials         │ /sihaoli/.agents/skills/investor-materials │
│ skills   │ investor-outreach          │ s/sihaoli/.agents/skills/investor-outreach │
│ skills   │ market-research            │ ers/sihaoli/.agents/skills/market-research │
│ skills   │ security-review            │ ers/sihaoli/.agents/skills/security-review │
│ skills   │ strategic-compact          │ s/sihaoli/.agents/skills/strategic-compact │
│ skills   │ tdd-workflow               │ /Users/sihaoli/.agents/skills/tdd-workflow │
│ skills   │ verification-loop          │ s/sihaoli/.agents/skills/verification-loop │
│ skills   │ article-writing            │ ers/sihaoli/.agents/skills/article-writing │
│ skills   │ content-engine             │ sers/sihaoli/.agents/skills/content-engine │
│ skills   │ frontend-slides            │ ers/sihaoli/.agents/skills/frontend-slides │
│ skills   │ investor-materials         │ /sihaoli/.agents/skills/investor-materials │
│ skills   │ investor-outreach          │ s/sihaoli/.agents/skills/investor-outreach │
│ skills   │ market-research            │ ers/sihaoli/.agents/skills/market-research │
│ skills   │ api-design                 │ /Users/sihaoli/.agents/skills/api-design   │
│ skills   │ backend-patterns           │ rs/sihaoli/.agents/skills/backend-patterns │
│ skills   │ coding-standards           │ rs/sihaoli/.agents/skills/coding-standards │
│ skills   │ database-migrations        │ sihaoli/.agents/skills/database-migrations │
│ skills   │ deployment-patterns        │ sihaoli/.agents/skills/deployment-patterns │
│ skills   │ docker-patterns            │ ers/sihaoli/.agents/skills/docker-patterns │
└──────────┴────────────────────────────┴────────────────────────────────────────────┘
```

## Compatibility

- `gstack`: present=True evidence=`/Users/sihaoli/Solar/CLAUDE.md` risk=commands/hooks may compete with existing gstack browser and intent rules
- `superpowers`: present=True evidence=`/Users/sihaoli/.codex/config.toml` risk=skills may overlap Codex Superpowers execution discipline
- `solar_hooks`: present=True evidence=`/Users/sihaoli/.claude/hooks` risk=upstream hooks must not be globally activated without allowlist

## Dry Run

- live_hook_changes: `0`
- would_stage_hooks: `72`
- would_install_live: `0`
- safe_to_sync: `False`
- reason: allowlist and collision review are required before any live sync

## Recommended Allowlist V0

- `adopt`: targeted reviewer/build-resolver agents after name collision review.
- `adapt`: verification-loop, tdd-workflow, eval-harness skills after Solar naming prefix.
- `defer`: all hooks, MCP configs, install scripts, auto-update scripts.
- `reject`: anything that overwrites global Claude settings without dry-run and rollback.

