#!/bin/bash
# ================================================================
# Solar Harness — 一键启动多化身协同环境
#
# 用法:
#   solar-harness.sh [工作目录]          启动3化身 (默认)
#   solar-harness.sh 2 [工作目录]        启动2化身
#   solar-harness.sh status              查看状态
#   solar-harness.sh kill                关闭
#   solar-harness.sh sprint "需求"       创建 Sprint
#
# @module solar-farm/harness
# ================================================================
set -eu

HARNESS_DIR="$HOME/.solar/harness"
SESSION_NAME="solar-harness"
LAB_SESSION_NAME="solar-harness-lab"
LEGACY_LAB_SESSION_NAME="solar-harness-strategy"
SPRINTS_DIR="$HARNESS_DIR/sprints"

# sprint-20260503-094659 D2: 统一 state helper
. "$HARNESS_DIR/lib/run-state.sh"

# sprint-20260503-163542 D3: bridge ledger
[[ -f "$HARNESS_DIR/lib/bridge-ledger.sh" ]] && . "$HARNESS_DIR/lib/bridge-ledger.sh"

# ---- Colors ----
G='\033[0;32m'; Y='\033[1;33m'; R='\033[0;31m'; C='\033[0;36m'; B='\033[0;34m'; N='\033[0m'
log()  { echo -e "${C}[Harness]${N} $*"; }
ok()   { echo -e "${G}[Harness]${N} $*"; }
warn() { echo -e "${Y}[Harness]${N} $*"; }
err()  { echo -e "${R}[Harness]${N} $*"; }

ensure_dirs() { mkdir -p "$SPRINTS_DIR" "$HARNESS_DIR/personas" "$HARNESS_DIR/templates"; }

cleanup_legacy_sessions() {
  if ! tmux has-session -t "$LEGACY_LAB_SESSION_NAME" 2>/dev/null; then
    return 0
  fi

  local attached="0"
  attached=$(tmux display-message -p -t "$LEGACY_LAB_SESSION_NAME" '#{session_attached}' 2>/dev/null || echo "0")
  if [[ "$attached" != "0" ]]; then
    warn "检测到旧 Strategy Lab session 仍被附着: $LEGACY_LAB_SESSION_NAME"
    warn "请先退出旧会话，再运行: tmux kill-session -t $LEGACY_LAB_SESSION_NAME"
    return 0
  fi

  tmux kill-session -t "$LEGACY_LAB_SESSION_NAME" 2>/dev/null || true
  ok "已清理旧残留 session: $LEGACY_LAB_SESSION_NAME"
}

sanitize_tmux_claude_env() {
  local session="$1"
  tmux set-environment -t "$session" -gu CLAUDECODE 2>/dev/null || true
  tmux set-environment -t "$session" -gu CLAUDE_CODE_ENTRYPOINT 2>/dev/null || true
  tmux set-environment -t "$session" -gu CLAUDE_CODE_EXECPATH 2>/dev/null || true
}

attach_or_print() {
  local session="${1:-$SESSION_NAME}"
  if [[ -t 1 && -n "${TERM:-}" && "${TERM:-}" != "dumb" ]]; then
    tmux attach -t "$session" || {
      warn "tmux attach 失败，session 已在后台运行: $session"
      log "重新接入: tmux attach -t $session"
      return 0
    }
  else
    ok "tmux session 已在后台运行: $session"
    log "重新接入: tmux attach -t $session"
  fi
}

configure_role_footer_style() {
  local session="$1" active_color="${2:-#89b4fa}"
  tmux set-window-option -t "$session:0" pane-border-status bottom 2>/dev/null || true
  tmux set-window-option -t "$session:0" pane-border-format "#[fg=${active_color},bold] #P #{pane_title} #[default]" 2>/dev/null || true
  tmux set-option -t "$session" allow-set-title off 2>/dev/null || true
}

pane_footer_label() {
  local persona="$1" label="$2" slot="${3:-}"
  bash "$HARNESS_DIR/quota-footer.sh" "$persona" "$label" "$slot" 2>/dev/null || printf "%s | 模型:N/A | 剩余:N/A | 已用:N/A tok" "$label"
}

configure_product_delivery_labels() {
  tmux has-session -t "$SESSION_NAME" 2>/dev/null || return 0
  configure_role_footer_style "$SESSION_NAME" "#89b4fa"
  tmux select-pane -t "$SESSION_NAME:Product Delivery.0" -T "$(pane_footer_label pm "PM 产品经理")" 2>/dev/null || true
  tmux select-pane -t "$SESSION_NAME:Product Delivery.1" -T "$(pane_footer_label planner "Planner 规划者")" 2>/dev/null || true
  tmux select-pane -t "$SESSION_NAME:Product Delivery.2" -T "$(pane_footer_label builder "Builder 主建设者")" 2>/dev/null || true
  tmux select-pane -t "$SESSION_NAME:Product Delivery.3" -T "$(pane_footer_label evaluator "Evaluator 审判官")" 2>/dev/null || true
}

configure_builder_lab_labels() {
  tmux has-session -t "$LAB_SESSION_NAME" 2>/dev/null || return 0
  configure_role_footer_style "$LAB_SESSION_NAME" "#f9e2af"
  tmux select-pane -t "$LAB_SESSION_NAME:Builder Lab.0" -T "$(pane_footer_label lab-builder "Builder 1" "lab-builder-1")" 2>/dev/null || true
  tmux select-pane -t "$LAB_SESSION_NAME:Builder Lab.1" -T "$(pane_footer_label lab-builder "Builder 2" "lab-builder-2")" 2>/dev/null || true
  tmux select-pane -t "$LAB_SESSION_NAME:Builder Lab.2" -T "$(pane_footer_label lab-builder "Builder 3" "lab-builder-3")" 2>/dev/null || true
  tmux select-pane -t "$LAB_SESSION_NAME:Builder Lab.3" -T "$(pane_footer_label lab-builder "Builder 4" "lab-builder-4")" 2>/dev/null || true
}

# ---- Bash 4+ 检测 ----

resolve_bash4() {
  local candidates=(
    /opt/homebrew/bin/bash
    /usr/local/bin/bash
    "$(command -v bash 2>/dev/null)"
  )
  for b in "${candidates[@]}"; do
    [[ -z "$b" || ! -x "$b" ]] && continue
    local major
    major=$("$b" -c 'echo ${BASH_VERSINFO[0]}' 2>/dev/null || echo 0)
    if [[ "$major" -ge 4 ]]; then
      echo "$b"
      return 0
    fi
  done
  return 1
}

# 缓存 bash4 路径 (启动时解析一次)
BASH4=""
_ensure_bash4() {
  [[ -n "$BASH4" ]] && return 0
  BASH4=$(resolve_bash4) || return 1
}

# ---- Doctor 自检 ----

do_doctor() {
  local failed=0

  # (a) bash 4+ 可用
  local bash4=""
  bash4=$(resolve_bash4) || {
    echo "❌ bash 4+ 不可用 (当前 /bin/bash: ${BASH_VERSINFO[0]})"
    echo "   修复: brew install bash"
    ((failed++))
  }

  # (b) tmux/claude/python3/jq 在 PATH
  for cmd in tmux claude python3 jq; do
    command -v "$cmd" &>/dev/null || {
      echo "❌ $cmd 不在 PATH"
      echo "   修复: brew install $cmd"
      ((failed++))
    }
  done

  # (c) coordinator.sh bash -n 通过
  if [[ -n "$bash4" ]]; then
    "$bash4" -n "$HARNESS_DIR/coordinator.sh" 2>/dev/null || {
      echo "❌ coordinator.sh 语法错误 (bash -n 失败)"
      echo "   修复: $bash4 -n $HARNESS_DIR/coordinator.sh 查看详情"
      ((failed++))
    }
    "$bash4" -n "$HARNESS_DIR/lib/persona-config.sh" 2>/dev/null || {
      echo "❌ persona-config.sh 语法错误 (bash -n 失败)"
      echo "   修复: $bash4 -n $HARNESS_DIR/lib/persona-config.sh 查看详情"
      ((failed++))
    }
    if [[ -x "$HARNESS_DIR/test-gateway-compat.sh" ]]; then
      "$bash4" "$HARNESS_DIR/test-gateway-compat.sh" >/dev/null 2>&1 || {
        echo "❌ 第三方网关兼容配置检查失败"
        echo "   修复: $bash4 $HARNESS_DIR/test-gateway-compat.sh 查看详情"
        ((failed++))
      }
    fi
  fi

  # (d) 关键目录可写
  [[ -w "$HARNESS_DIR" ]] || {
    echo "❌ $HARNESS_DIR 不可写"
    ((failed++))
  }

  # (e) coordinator pidfile 进程活
  if [[ -f "$HARNESS_DIR/.coordinator.pid" ]]; then
    local cpid
    cpid=$(cat "$HARNESS_DIR/.coordinator.pid" 2>/dev/null)
    if [[ -n "$cpid" ]] && ! kill -0 "$cpid" 2>/dev/null; then
      echo "⚠ coordinator pidfile 指向死进程 (PID=$cpid, 启动时会自愈)"
    fi
  fi

  # (f) coordinator.sh 语法已由 bash -n 覆盖。
  # 旧版曾用全文件双引号奇偶数做阻塞检查；它不理解 heredoc、Python
  # 三引号和跨行 dispatch 文本，会把合法脚本误判为坏脚本。

  # (g) qmd launcher Node ABI 风险可检测可修复
  if [[ -x "$HARNESS_DIR/lib/qmd-launcher-repair.sh" ]]; then
    local qmd_repair_out qmd_repair_rc
    qmd_repair_out="$("$HARNESS_DIR/lib/qmd-launcher-repair.sh" --check 2>&1)" || qmd_repair_rc=$?
    qmd_repair_rc="${qmd_repair_rc:-0}"
    if [[ "$qmd_repair_rc" == "2" ]]; then
      echo "⚠ qmd launcher 存在 Node ABI 风险"
      echo "   修复: $0 wiki qmd-repair --apply"
    elif [[ "$qmd_repair_rc" != "0" ]]; then
      echo "⚠ qmd launcher 检查异常: $qmd_repair_out"
    fi
  fi

  # (h) 所有 sprint 状态机合法
  for f in "$SPRINTS_DIR"/*.status.json; do
    [[ -f "$f" ]] || continue
    local st
    st=$(python3 -c "import json; print(json.load(open('$f')).get('status',''))" 2>/dev/null)
    case "$st" in
      drafting|queued|active|planning|approved|reviewing|ready_for_review|failed_review|passed|done|failed|eval_pass|cancelled|interrupted|superseded|needs_human_review|blocked) ;;
      *)
        echo "⚠ $(basename "$f") 非法状态: $st"
        ;;
    esac
  done

  if (( failed == 0 )); then
    echo "✅ Solar Harness doctor: 全部通过"
    return 0
  else
    echo "❌ ${failed} 项检查失败"
    return 1
  fi
}

# ---- 同步启动 Coordinator ----

find_live_coordinator_pids() {
  ps ax -o pid= -o args= | awk -v script="$HARNESS_DIR/coordinator.sh" '
    $0 ~ "^[[:space:]]*[0-9]+[[:space:]]+([^[:space:]]*/)?bash[[:space:]]+" script "([[:space:]]|$)" { print $1 }
  '
}

start_coordinator_sync() {
  _ensure_bash4 || { err "bash 4+ 不可用，无法启动 coordinator"; return 1; }

  local pidfile="$HARNESS_DIR/.coordinator.pid"

  # 已有活进程 → 跳过
  if [[ -f "$pidfile" ]]; then
    local existing_pid
    existing_pid=$(cat "$pidfile" 2>/dev/null)
    if [[ -n "$existing_pid" ]] && kill -0 "$existing_pid" 2>/dev/null; then
      ok "Coordinator 已在运行 (PID: $existing_pid)"
      # D7: doctor summary
      bash "$HARNESS_DIR/doctor.sh" --summary 2>/dev/null || true
      return 0
    fi
    # 死进程 → 清锁
    rm -f "$pidfile"
  fi

  # pidfile 缺失/过期时，先查真实进程，避免 launcher/watchdog 并发启动多个 coordinator。
  local real_pids real_pid
  real_pids=$(find_live_coordinator_pids || true)
  if [[ -n "$real_pids" ]]; then
    real_pid=$(echo "$real_pids" | head -1)
    echo "$real_pid" > "$pidfile"
    ok "Coordinator 已在运行，pidfile 已自愈 (PID: $real_pid)"
    bash "$HARNESS_DIR/doctor.sh" --summary 2>/dev/null || true
    return 0
  fi

  # 启动 (nohup 隔离 SIGHUP)
  nohup "$BASH4" "$HARNESS_DIR/coordinator.sh" >> "$HARNESS_DIR/.coordinator.log" 2>&1 &
  disown 2>/dev/null || true

  # 等待 pidfile 出现 (最多 3 秒)
  local waited=0
  while (( waited < 30 )); do
    if [[ -f "$pidfile" ]]; then
      local pid
      pid=$(cat "$pidfile" 2>/dev/null)
      if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then
        ok "Coordinator 启动成功 (PID: $pid)"
        # D7: doctor summary
        bash "$HARNESS_DIR/doctor.sh" --summary 2>/dev/null || true
        return 0
      fi
    fi
    sleep 0.1
    ((waited++))
  done

  err "Coordinator 启动失败: 3 秒内 pidfile 未出现"
  err "查看日志: cat $HARNESS_DIR/.coordinator.log"
  return 1
}

# ---- 同步启动 Watchdog ----

start_watchdog_sync() {
  _ensure_bash4 || { warn "bash 4+ 不可用，跳过 watchdog"; return 0; }

  local pidfile="$HARNESS_DIR/.watchdog.pid"

  if [[ -f "$pidfile" ]]; then
    local existing_pid
    existing_pid=$(cat "$pidfile" 2>/dev/null)
    if [[ -n "$existing_pid" ]] && kill -0 "$existing_pid" 2>/dev/null; then
      ok "Watchdog 已在运行 (PID: $existing_pid)"
      return 0
    fi
    rm -f "$pidfile"
  fi

  nohup "$BASH4" "$HARNESS_DIR/coordinator-watchdog.sh" start >> "$HARNESS_DIR/.watchdog.log" 2>&1 &
  disown 2>/dev/null || true

  sleep 0.5
  if [[ -f "$pidfile" ]] && kill -0 "$(cat "$pidfile")" 2>/dev/null; then
    ok "Watchdog 启动成功 (PID: $(cat "$pidfile"))"
  else
    warn "Watchdog 启动未确认 (可能需要手动检查)"
  fi
  return 0
}

# ---- Start Harness ----

start_harness() {
  local mode="${1:-3}"
  local work_dir="${2:-$(pwd)}"
  local skip_doctor="${3:-}"

  cleanup_legacy_sessions

  # 启动前自检 (除非 --skip-doctor)
  if [[ "$skip_doctor" != "--skip-doctor" ]]; then
    log "运行启动自检..."
    do_doctor || { err "启动前自检失败，修复后再试 (或用 --skip-doctor 跳过)"; exit 1; }
  fi

  command -v tmux &>/dev/null || { err "tmux 未安装: brew install tmux"; exit 1; }
  command -v claude &>/dev/null || { err "claude 未安装"; exit 1; }

  if tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
    # 安全优先: pane_current_command 经常是 bash/zsh，因为 Claude TUI 是子进程。
    # 旧逻辑只数 current_command=claude，容易把真实运行中的 session 误判为死
    # session 并 kill 掉用户现场。已有 session 一律复用/attach，不自动销毁。
    local panes_count
    panes_count=$(tmux list-panes -t "$SESSION_NAME" 2>/dev/null | wc -l | tr -d ' ')
    ok "Solar Harness 已在运行 (${panes_count} panes)，直接接入"
    if tmux list-windows -t "$SESSION_NAME" -F '#{window_name}' 2>/dev/null | grep -qx "Product Delivery"; then
      tmux select-window -t "$SESSION_NAME:Product Delivery" 2>/dev/null || true
    fi
    configure_product_delivery_labels
    attach_or_print
    return
  fi

  ensure_dirs

  log "启动 Solar Harness (${mode} 化身 + 监控)..."
  log "工作目录: ${work_dir}"

  # ================================================================
  # 四分屏布局 — Product Delivery (Window 0)
  #
  # ┌──────────────┬──────────────┐
  # │   产品经理    │   规划者      │
  # │   pm         │   planner    │
  # ├──────────────┼──────────────┤
  # │   建设者      │   审判官      │
  # │   builder    │   evaluator  │
  # └──────────────┴──────────────┘
  # ================================================================

  tmux new-session -d -s "$SESSION_NAME" -c "$work_dir"
  sanitize_tmux_claude_env "$SESSION_NAME"
  tmux set-environment -t "$SESSION_NAME" SOLAR_CLAUDE_BYPASS 1 2>/dev/null || true

  # D3: pane 保留现场 — 进程退出后 pane 不消失 (remain-on-exit)
  tmux set-option -t "$SESSION_NAME" remain-on-exit on

  # 创建4个 pane (tmux 会重编号！)
  # Step 1: 上下分 → 0(上) + 1(下)
  tmux split-window -v -t "$SESSION_NAME" -c "$work_dir"
  # Step 2: 上半左右分 → 0(左上) + 1(右上), 原1(下)变2
  tmux split-window -h -t "$SESSION_NAME:0.0" -c "$work_dir"
  # Step 3: 下半左右分 → 2(左下) + 3(右下)
  tmux split-window -h -t "$SESSION_NAME:0.2" -c "$work_dir"

  # Rename window 0
  tmux rename-window -t "$SESSION_NAME:0" "Product Delivery"

  # 最终编号: 0=左上 1=右上 2=左下 3=右下
  # 启动 pane-launcher (统一配置, 无交互阻塞)
  # D5 sprint-20260502-191700: printf '%q' 路径转义
  local _esc_harness _esc_work
  _esc_harness=$(printf '%q' "$HARNESS_DIR")
  _esc_work=$(printf '%q' "$work_dir")
  launch_persona_pane() {
    local target="$1" persona="$2"
    local pane_id
    pane_id=$(tmux display-message -p -t "$target" '#{pane_id}')
    tmux send-keys -t "$target" "env -u CLAUDECODE -u CLAUDE_CODE_ENTRYPOINT -u CLAUDE_CODE_EXECPATH TMUX_PANE=${pane_id} SOLAR_CLAUDE_BYPASS=1 bash ${_esc_harness}/pane-launcher.sh ${persona} ${_esc_work}" Enter
  }
  sleep 1
  launch_persona_pane "$SESSION_NAME:Product Delivery.0" "pm"
  sleep 1
  launch_persona_pane "$SESSION_NAME:Product Delivery.1" "planner"
  if [[ "$mode" == "3" ]]; then
    sleep 1
    launch_persona_pane "$SESSION_NAME:Product Delivery.2" "builder"
    sleep 1
    launch_persona_pane "$SESSION_NAME:Product Delivery.3" "evaluator"
  else
    sleep 1
    launch_persona_pane "$SESSION_NAME:Product Delivery.2" "builder"
  fi

  # 设置活跃 pane 为 PM (非监控)
  tmux select-pane -t "$SESSION_NAME:Product Delivery.0"

  # 开启鼠标支持 (点击切换 pane)
  tmux set-option -t "$SESSION_NAME" mouse on

  # tmux 样式
  tmux set-option -t "$SESSION_NAME" status-style "bg=#1a1a2e,fg=#cdd6f4"
  tmux set-option -t "$SESSION_NAME" pane-border-style "fg=#45475a"
  tmux set-option -t "$SESSION_NAME" pane-active-border-style "fg=#89b4fa"
  tmux set-option -t "$SESSION_NAME" status-right-length 60
  tmux set-option -t "$SESSION_NAME" status-right "#[fg=#89b4fa]Solar Harness #[fg=#a6e3a1]${mode}化身+并行 #[default]%H:%M"
  configure_product_delivery_labels

  # 打印帮助 (attach 前输出到 stdout)
  echo ""
  ok "══════════════════════════════════════════════════"
  ok "  Solar Harness 启动完成!"
  echo ""
  if [[ "$mode" == "3" ]]; then
    echo "  布局 (四分屏同时可见):"
    echo ""
    echo "  ┌──────────────┬──────────────┐"
    echo "  │   产品经理    │   规划者      │"
    echo "  │   pm         │   planner    │"
    echo "  ├──────────────┼──────────────┤"
    echo "  │   建设者      │   审判官      │"
    echo "  │   builder    │   evaluator  │"
    echo "  └──────────────┴──────────────┘"
  else
    echo "  布局 (三分屏):"
    echo ""
    echo "  ┌──────────────┬──────────────┐"
    echo "  │   产品经理    │   规划者      │"
    echo "  │   pm         │   planner    │"
    echo "  ├──────────────┴──────────────┤"
    echo "  │         建设者 builder       │"
    echo "  └─────────────────────────────┘"
  fi
  echo ""
  log "tmux 快捷键:"
  echo "  切 pane:   Ctrl+B → 方向键"
  echo "  全屏当前:  Ctrl+B → z (再按一次恢复)"
  echo "  后台运行:  Ctrl+B → d"
  echo "  重新接入:  tmux attach -t $SESSION_NAME"
  echo ""
  log "使用方法:"
  echo "  1. 切到化身 pane (Ctrl+B → 方向键 / 鼠标点击)"
  echo "  2. 按 Enter 启动该化身的 Claude"
  echo "  3. 处理 Claude 的确认提示 (信任文件夹等)"
  echo ""

  # ── 同步拉 Coordinator + Watchdog (SIGHUP 隔离) ──
  start_coordinator_sync || { err "Coordinator 启动失败，中止"; exit 1; }
  start_watchdog_sync

  attach_or_print
}

# ---- Status ----

show_status() {
  cleanup_legacy_sessions
  echo ""
  if tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
    ok "Solar Harness Product Delivery 运行中 ($SESSION_NAME)"
    echo ""
    tmux list-windows -t "$SESSION_NAME" 2>/dev/null | sed 's/^/  /'
    echo ""
    if tmux has-session -t "$LAB_SESSION_NAME" 2>/dev/null; then
      ok "Solar Harness Parallel Builder Lab 运行中 ($LAB_SESSION_NAME)"
      echo ""
      tmux list-windows -t "$LAB_SESSION_NAME" 2>/dev/null | sed 's/^/  /'
      echo ""
    fi
    local cnt
    cnt=$(ls "$SPRINTS_DIR"/*.status.json 2>/dev/null | wc -l | tr -d ' ')
    log "Sprints: ${cnt}"
    for f in "$SPRINTS_DIR"/*.status.json; do
      [[ -f "$f" ]] || continue
      local sid st stitle
      sid=$(python3 -c "import json; print(json.load(open('$f')).get('id','?'))" 2>/dev/null)
      st=$(python3 -c  "import json; print(json.load(open('$f')).get('status','?'))" 2>/dev/null)
      stitle=$(python3 -c "import json; print(json.load(open('$f')).get('title',''))" 2>/dev/null)
      if [[ -n "$stitle" ]]; then
        echo -e "  ${G}${stitle}${N} — ${st} (${sid})"
      else
        echo -e "  ${G}${sid}${N} — ${st}"
      fi
    done
  else
    if tmux has-session -t "$LAB_SESSION_NAME" 2>/dev/null; then
      ok "Solar Harness Parallel Builder Lab 运行中 ($LAB_SESSION_NAME)"
      echo ""
      tmux list-windows -t "$LAB_SESSION_NAME" 2>/dev/null | sed 's/^/  /'
    else
      warn "Solar Harness 未运行"
      log "启动: $0 [工作目录]"
    fi
  fi
  echo ""
}

# ---- Kill ----

kill_harness() {
  cleanup_legacy_sessions
  local killed=0
  if tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
    log "关闭..."
    # Mark active sprints as interrupted
    for f in "$SPRINTS_DIR"/*.status.json; do
      [[ -f "$f" ]] || continue
      python3 -c "
import json
with open('$f') as fh: d = json.load(fh)
if d.get('status') in ('active','reviewing'):
    d['status'] = 'interrupted'
    with open('$f','w') as fh: json.dump(d, fh, indent=2)
" 2>/dev/null
    done
    tmux kill-session -t "$SESSION_NAME"
    killed=1
  fi
  if tmux has-session -t "$LAB_SESSION_NAME" 2>/dev/null; then
    tmux kill-session -t "$LAB_SESSION_NAME"
    killed=1
  fi
  if (( killed == 1 )); then
    ok "已关闭"
  else
    warn "未运行"
  fi
}

pane_process_persona_simple() {
  local target="$1"
  local pane_pid
  pane_pid=$(tmux display-message -p -t "$target" '#{pane_pid}' 2>/dev/null || true)
  [[ -n "$pane_pid" ]] || return 1

  local queue="$pane_pid" visited=""
  while [[ -n "$queue" ]]; do
    local next_queue=""
    local pid
    for pid in $queue; do
      case " $visited " in *" $pid "*) continue ;; esac
      visited="$visited $pid"

      local args
      args=$(ps -p "$pid" -o args= 2>/dev/null || true)
      if [[ "$args" =~ start-(incarnation|launcher)\.sh[[:space:]]+([A-Za-z0-9_-]+) ]]; then
        echo "${BASH_REMATCH[2]}"
        return 0
      fi

      local children
      children=$(pgrep -P "$pid" 2>/dev/null || true)
      [[ -n "$children" ]] && next_queue="$next_queue $children"
    done
    queue="$next_queue"
  done
  return 1
}

detect_pane_by_persona_simple() {
  local session="$1" window="$2" persona="$3" fallback="$4"
  tmux has-session -t "$session" 2>/dev/null || { echo "$fallback"; return 0; }
  local idx target proc_persona content
  while IFS= read -r idx; do
    [[ -z "$idx" ]] && continue
    target="${session}:${window}.${idx}"
    proc_persona=$(pane_process_persona_simple "$target" 2>/dev/null || true)
    if [[ "$proc_persona" == "$persona" ]]; then
      echo "$target"
      return 0
    fi
    content=$(tmux capture-pane -t "$target" -p -S -80 2>/dev/null | tail -80 || true)
    if printf '%s\n' "$content" | grep -qE "Persona:[[:space:]]*${persona}([[:space:]]|$)"; then
      echo "$target"
      return 0
    fi
  done < <(tmux list-panes -t "${session}:${window}" -F '#{pane_index}' 2>/dev/null || true)
  echo "$fallback"
}

write_parallel_lab_state() {
  local work_dir="$1"
  local model_matrix="${SOLAR_LAB_BUILDER_MODEL_MATRIX:-glm,glm,glm,anthropic-sonnet}"
  mkdir -p "$HARNESS_DIR/state"
  {
    printf "WORK_DIR='%s'\n" "$work_dir"
    printf "LAB_SESSION='%s'\n" "$LAB_SESSION_NAME"
    printf "LAB_MODEL_MATRIX='%s'\n" "$model_matrix"
    printf "UPDATED_AT='%s'\n" "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  } > "$HARNESS_DIR/state/parallel-builder-lab.env"
}

ensure_parallel_builder_lab() {
  local work_dir="${1:-$(pwd)}"
  tmux has-session -t "$LAB_SESSION_NAME" 2>/dev/null || return 0
  local state_file="$HARNESS_DIR/state/parallel-builder-lab.env"
  local desired_matrix="${SOLAR_LAB_BUILDER_MODEL_MATRIX:-glm,glm,glm,anthropic-sonnet}"
  local current_matrix=""
  if [[ -f "$state_file" ]]; then
    current_matrix=$(grep '^LAB_MODEL_MATRIX=' "$state_file" 2>/dev/null | sed "s/^LAB_MODEL_MATRIX='//;s/'$//" || true)
  fi
  local rebuild_for_model_matrix=0
  if [[ "$current_matrix" != "$desired_matrix" ]]; then
    rebuild_for_model_matrix=1
    warn "Parallel Builder Lab 模型矩阵变化: ${current_matrix:-N/A} -> ${desired_matrix}; 将 respawn 四个 builder"
  fi
  write_parallel_lab_state "$work_dir"

  tmux rename-window -t "$LAB_SESSION_NAME:0" "Builder Lab" 2>/dev/null || true
  tmux set-option -t "$LAB_SESSION_NAME" status-right "#[fg=#f9e2af]Solar Builder Lab #[fg=#a6e3a1]3 GLM-5.1 + 1 Claude Sonnet #[default]%H:%M" 2>/dev/null || true
  tmux set-environment -t "$LAB_SESSION_NAME" SOLAR_CLAUDE_BYPASS 1 2>/dev/null || true
  configure_builder_lab_labels

  local pane_count
  pane_count=$(tmux list-panes -t "$LAB_SESSION_NAME:0" 2>/dev/null | wc -l | tr -d ' ')
  if [[ "$pane_count" != "4" ]]; then
    warn "Parallel Builder Lab 需要 4 个 pane，当前为 ${pane_count}；请重建 lab session"
    return 0
  fi

  local _esc_harness _esc_work i target pane_id slot content
  _esc_harness=$(printf '%q' "$HARNESS_DIR")
  _esc_work=$(printf '%q' "$work_dir")
  for i in 0 1 2 3; do
    target="$LAB_SESSION_NAME:0.$i"
    slot="lab-builder-$((i + 1))"
    content=$(tmux capture-pane -t "$target" -p -S -80 2>/dev/null | tail -80 || true)
    if (( rebuild_for_model_matrix == 0 )) && printf '%s\n' "$content" | grep -qE "Persona:[[:space:]]*lab-builder([[:space:]]|$)"; then
      continue
    fi
    pane_id=$(tmux display-message -p -t "$target" '#{pane_id}')
    tmux respawn-pane -k -t "$target" "env -u CLAUDECODE -u CLAUDE_CODE_ENTRYPOINT -u CLAUDE_CODE_EXECPATH TMUX_PANE=${pane_id} SOLAR_BUILDER_SLOT=${slot} SOLAR_CLAUDE_BYPASS=1 bash ${_esc_harness}/pane-launcher.sh lab-builder ${_esc_work}"
  done
  configure_builder_lab_labels
}

# ---- Extend: 启动独立第二四分屏 (Parallel Builder Lab) ----

start_extension() {
  local work_dir="${1:-$(pwd)}"

  cleanup_legacy_sessions
  write_parallel_lab_state "$work_dir"

  # 第二屏必须是独立 session。不要做成同一 session 的 window，否则两个终端
  # attach 同一 session 时会互相切 window，看起来像镜像。
  if tmux has-session -t "$LAB_SESSION_NAME" 2>/dev/null; then
    ensure_parallel_builder_lab "$work_dir"
    ok "Parallel Builder Lab 已在独立 session 运行 ($LAB_SESSION_NAME)"
    attach_or_print "$LAB_SESSION_NAME"
    return
  fi

  log "启动独立 Parallel Builder Lab 四分屏..."
  log "session: $LAB_SESSION_NAME"
  log "工作目录: ${work_dir}"

  tmux new-session -d -s "$LAB_SESSION_NAME" -n "Builder Lab" -c "$work_dir"
  sanitize_tmux_claude_env "$LAB_SESSION_NAME"
  tmux set-environment -t "$LAB_SESSION_NAME" SOLAR_CLAUDE_BYPASS 1 2>/dev/null || true
  tmux set-option -t "$LAB_SESSION_NAME" remain-on-exit on

  # Split into 4 panes (same layout as window 0)
  tmux split-window -v -t "$LAB_SESSION_NAME:Builder Lab" -c "$work_dir"
  tmux split-window -h -t "$LAB_SESSION_NAME:Builder Lab.0" -c "$work_dir"
  tmux split-window -h -t "$LAB_SESSION_NAME:Builder Lab.2" -c "$work_dir"

  # Launch four isolated builders. SOLAR_BUILDER_SLOT gives each pane its own
  # git worktree under .worktrees/, so parallel work does not collide.
  local _esc_harness _esc_work
  _esc_harness=$(printf '%q' "$HARNESS_DIR")
  _esc_work=$(printf '%q' "$work_dir")
  launch_persona_pane() {
    local target="$1" persona="$2" slot="$3"
    local pane_id
    pane_id=$(tmux display-message -p -t "$target" '#{pane_id}')
    tmux send-keys -t "$target" "env -u CLAUDECODE -u CLAUDE_CODE_ENTRYPOINT -u CLAUDE_CODE_EXECPATH TMUX_PANE=${pane_id} SOLAR_BUILDER_SLOT=${slot} SOLAR_CLAUDE_BYPASS=1 bash ${_esc_harness}/pane-launcher.sh ${persona} ${_esc_work}" Enter
  }
  sleep 1
  launch_persona_pane "$LAB_SESSION_NAME:Builder Lab.0" "lab-builder" "lab-builder-1"
  sleep 1
  launch_persona_pane "$LAB_SESSION_NAME:Builder Lab.1" "lab-builder" "lab-builder-2"
  sleep 1
  launch_persona_pane "$LAB_SESSION_NAME:Builder Lab.2" "lab-builder" "lab-builder-3"
  sleep 1
  launch_persona_pane "$LAB_SESSION_NAME:Builder Lab.3" "lab-builder" "lab-builder-4"

  tmux select-pane -t "$LAB_SESSION_NAME:Builder Lab.0"
  tmux set-option -t "$LAB_SESSION_NAME" mouse on
  tmux set-option -t "$LAB_SESSION_NAME" status-style "bg=#1a1a2e,fg=#cdd6f4"
  tmux set-option -t "$LAB_SESSION_NAME" pane-border-style "fg=#45475a"
  tmux set-option -t "$LAB_SESSION_NAME" pane-active-border-style "fg=#f9e2af"
  tmux set-option -t "$LAB_SESSION_NAME" status-right-length 60
  tmux set-option -t "$LAB_SESSION_NAME" status-right "#[fg=#f9e2af]Solar Builder Lab #[fg=#a6e3a1]3 GLM-5.1 + 1 Claude Sonnet #[default]%H:%M"
  configure_builder_lab_labels

  ok "Parallel Builder Lab 四分屏已启动"
  echo ""
  echo "  ┌──────────────┬──────────────┐"
  echo "  │  Builder 1   │  Builder 2   │"
  echo "  │ GLM-5.1      │ GLM-5.1      │"
  echo "  ├──────────────┼──────────────┤"
  echo "  │  Builder 3   │  Builder 4   │"
  echo "  │ GLM-5.1      │ Claude Sonnet│"
  echo "  └──────────────┴──────────────┘"
  echo ""
  echo "  重新接入:  tmux attach -t $LAB_SESSION_NAME"
  echo ""
  attach_or_print "$LAB_SESSION_NAME"
}

# ---- New Sprint ----

new_sprint() {
  local req="$1"
  local sid
  ensure_dirs
  sid=$(date +"sprint-%Y%m%d-%H%M%S")
  while [[ -e "$SPRINTS_DIR/$sid.status.json" || -e "$SPRINTS_DIR/$sid.contract.md" || -e "$SPRINTS_DIR/$sid.events.jsonl" ]]; do
    sleep 1
    sid=$(date +"sprint-%Y%m%d-%H%M%S")
  done

  local template="$HARNESS_DIR/templates/contract-template-v2.md"
  local title summary
  title=$(echo "$req" | head -1 | cut -c1-60)
  summary=$(echo "$req" | tr '\n' ' ' | sed 's/[[:space:]]\\{1,\\}/ /g' | cut -c1-180)
  [[ -z "$title" ]] && title="Untitled Sprint"
  [[ -z "$summary" ]] && summary="$title"
  local created_at
  created_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)

  # Prefer v2 template if it exists, otherwise fall back to inline
  if [[ -f "$template" ]]; then
    sed \
      -e "s|{{sprint_id}}|${sid}|g" \
      -e "s|{{created_at}}|${created_at}|g" \
      -e "s|{{project_dir}}|$(pwd)|g" \
      -e "s|{{name}}|${title}|g" \
      -e "s|{{description}}|${req}|g" \
      -e "s|{{summary}}|${summary}|g" \
      -e "s|{{triggers}}|auto|g" \
      -e "s|{{requirements}}|${req}|g" \
      "$template" > "${SPRINTS_DIR}/${sid}.contract.md"
  else
    # Fallback: inline template (backward compat)
    cat > "${SPRINTS_DIR}/${sid}.contract.md" << EOF
# Sprint Contract — ${title} (${sid})
Created: ${created_at}
Status: drafting
Project: $(pwd)

## Summary

${summary}

## Requirements

${req}

## Definition of Done

> Planner fills in

- [ ] (criterion 1)
- [ ] (criterion 2)
- [ ] (criterion 3)

## Scope

- In: (planner fills)
- Out: (planner fills)

## Constraints

> Planner fills in

## Implementation Files

> Builder fills in after completion

## Evaluation Dimensions

1. Functional completeness: Done criteria checked
2. Code quality: Error handling, edge cases, security
3. Contract compliance: Within scope
4. Maintainability: Naming, structure
EOF
  fi

  cat > "${SPRINTS_DIR}/${sid}.status.json" << EOF2
{
  "id": "${sid}",
  "title": "${title}",
  "summary": "${summary}",
  "status": "drafting",
  "phase": "spec",
  "handoff_to": "pm",
  "created_at": "${created_at}",
  "round": 0,
  "history": [{"ts": "${created_at}", "event": "pm_intake_created", "by": "user"}]
}
EOF2

  # Log phase_init event
  printf '{"ts":"%s","event":"phase_transition","by":"solar-harness","sid":"%s","data":{"from":"none","to":"spec"}}\n' \
    "$created_at" "$sid" >> "${SPRINTS_DIR}/${sid}.events.jsonl" 2>/dev/null || true

  ok "Sprint created: ${sid}"
  log "Contract: ${SPRINTS_DIR}/${sid}.contract.md"
  log "Phase: spec"
  log "Next: PM researches request and writes PRD, then Planner/architect designs plan"
}

# ---- Wake: 从崩溃恢复 Sprint ----

wake_sprint() {
  local sid="${2:-}"

  # wake --help / wake -h: 打印 usage
  if [[ "$sid" == "--help" || "$sid" == "-h" ]]; then
    echo "Solar Harness — wake: 从崩溃恢复 Sprint"
    echo ""
    echo "用法:"
    echo "  $0 wake              列出所有未完成 Sprint 供选择"
    echo "  $0 wake <sprint-id>  恢复指定 Sprint"
    echo "  $0 wake --help       显示帮助"
    echo ""
    echo "恢复流程:"
    echo "  1. 确保 tmux session 存在 (不存在则重建)"
    echo "  2. 从 events.jsonl 检查幂等性 (防止重复 wake)"
    echo "  3. 从 sprint 状态推导派发目标 (planner/builder/evaluator)"
    echo "  4. 生成 dispatch.md 并派发到对应 pane"
    echo "  5. 记录 wake 事件"
    echo "  6. 确保 coordinator 运行"
    echo ""
    echo "覆盖状态: drafting/active/planning/approved/reviewing/failed_review/interrupted"
    return 0
  fi

  if [[ -z "$sid" ]]; then
    # 无参数时列出所有未完成 sprint
    echo ""
    ok "未完成 Sprint 列表:"
    echo ""
    local found=0
    for f in "$SPRINTS_DIR"/*.status.json; do
      [[ -f "$f" ]] || continue
      local fst fstitle fstid
      fst=$(python3 -c "import json; print(json.load(open('$f')).get('status',''))" 2>/dev/null)
      case "$fst" in
        passed|done|failed|eval_pass) continue ;;
      esac
      fstid=$(python3 -c "import json; print(json.load(open('$f')).get('id',''))" 2>/dev/null)
      fstitle=$(python3 -c "import json; t=json.load(open('$f')).get('title',''); print(t[:50])" 2>/dev/null)
      echo -e "  ${G}${fstid}${N}  ${fst}  ${fstitle}"
      found=$((found + 1))
    done
    echo ""
    if [[ "$found" -eq 0 ]]; then
      warn "无活跃 Sprint"
    else
      log "用法: $0 wake <sprint-id>"
    fi
    return 0
  fi

  local sf="$SPRINTS_DIR/${sid}.status.json"
  [[ -f "$sf" ]] || { err "Sprint 不存在: $sid"; exit 1; }

  local st phase handoff_to auto_held contract_bypass contract_handoff contract_target
  st=$(python3 -c "import json; print(json.load(open('$sf')).get('status',''))" 2>/dev/null)
  phase=$(python3 -c "import json; print(json.load(open('$sf')).get('phase',''))" 2>/dev/null || true)
  handoff_to=$(python3 -c "import json; print(json.load(open('$sf')).get('handoff_to',''))" 2>/dev/null || true)
  auto_held=$(python3 -c "import json; print('true' if json.load(open('$sf')).get('auto_held') else 'false')" 2>/dev/null || echo false)
  contract_bypass=$(grep -Eq '^bypass_pm:[[:space:]]*true[[:space:]]*$' "$SPRINTS_DIR/${sid}.contract.md" 2>/dev/null && echo true || echo false)
  contract_handoff=$(grep -m1 '^handoff_to:' "$SPRINTS_DIR/${sid}.contract.md" 2>/dev/null | sed 's/^handoff_to:[[:space:]]*//' || true)
  contract_target=$(grep -m1 '^target_role:' "$SPRINTS_DIR/${sid}.contract.md" 2>/dev/null | sed 's/^target_role:[[:space:]]*//' || true)
  local original_st="$st"
  case "$st" in
    passed|done|failed|eval_pass)
      ok "Sprint ${sid} 已完成 (${st})，无需恢复"
      return 0
      ;;
  esac

  log "恢复 Sprint: ${sid} (当前状态: ${st})"

  # Step 1: 确保 tmux session 存在
  if ! tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
    warn "tmux session 不存在，重建..."
    # 用当前目录启动 (不 attach)
    local work_dir
    work_dir=$(grep '^Project:' "$SPRINTS_DIR/${sid}.contract.md" 2>/dev/null | sed 's/^Project:[[:space:]]*//' || echo "$HOME")
    [[ -z "$work_dir" ]] && work_dir="$HOME"

    # 重建 4-pane 布局 (后台)
    tmux new-session -d -s "$SESSION_NAME" -c "$work_dir"
    sanitize_tmux_claude_env "$SESSION_NAME"
    tmux set-environment -t "$SESSION_NAME" SOLAR_CLAUDE_BYPASS 1 2>/dev/null || true
    tmux split-window -v -t "$SESSION_NAME" -c "$work_dir"
    tmux split-window -h -t "$SESSION_NAME:0.0" -c "$work_dir"
    tmux split-window -h -t "$SESSION_NAME:0.2" -c "$work_dir"
    tmux set-option -t "$SESSION_NAME" mouse on
    sleep 1

    # 启动各 pane (D5 sprint-20260502-191700: 路径转义)
    local _esc_h _esc_w
    _esc_h=$(printf '%q' "$HARNESS_DIR")
    _esc_w=$(printf '%q' "$work_dir")
    tmux send-keys -t "$SESSION_NAME:0.0" "env -u CLAUDECODE -u CLAUDE_CODE_ENTRYPOINT -u CLAUDE_CODE_EXECPATH SOLAR_CLAUDE_BYPASS=1 bash ${_esc_h}/pane-launcher.sh pm ${_esc_w}" Enter
    sleep 1
    tmux send-keys -t "$SESSION_NAME:0.1" "env -u CLAUDECODE -u CLAUDE_CODE_ENTRYPOINT -u CLAUDE_CODE_EXECPATH SOLAR_CLAUDE_BYPASS=1 bash ${_esc_h}/pane-launcher.sh planner ${_esc_w}" Enter
    sleep 1
    tmux send-keys -t "$SESSION_NAME:0.2" "env -u CLAUDECODE -u CLAUDE_CODE_ENTRYPOINT -u CLAUDE_CODE_EXECPATH SOLAR_CLAUDE_BYPASS=1 bash ${_esc_h}/pane-launcher.sh builder ${_esc_w}" Enter
    sleep 1
    tmux send-keys -t "$SESSION_NAME:0.3" "env -u CLAUDECODE -u CLAUDE_CODE_ENTRYPOINT -u CLAUDE_CODE_EXECPATH SOLAR_CLAUDE_BYPASS=1 bash ${_esc_h}/pane-launcher.sh evaluator ${_esc_w}" Enter
    sleep 1
    configure_product_delivery_labels

    ok "tmux session 已重建"
  fi

  # Step 2: 幂等检查 — 从 events.jsonl 看是否已经 wake 过且无新活动
  local events_file="$SPRINTS_DIR/${sid}.events.jsonl"
  if [[ -f "$events_file" ]]; then
    local last_event
    last_event=$(tail -1 "$events_file" 2>/dev/null | python3 -c "
import json, sys
line = sys.stdin.read().strip()
if line:
    try:
        d = json.loads(line)
        if d.get('event') == 'waked':
            print('already_waked')
        else:
            print('ok')
    except:
        print('ok')
else:
    print('no_events')
" 2>/dev/null)
    if [[ "$last_event" == "already_waked" ]]; then
      # 检查 events.jsonl 最后修改时间 vs status.json
      local ev_mtime sf_mtime
      ev_mtime=$(stat -f %m "$events_file" 2>/dev/null || echo 0)
      sf_mtime=$(stat -f %m "$sf" 2>/dev/null || echo 0)
      if [[ "$sf_mtime" -le "$ev_mtime" ]]; then
        ok "Sprint ${sid} 已 wake 且无新活动，跳过 (幂等)"
        return 0
      fi
    fi
  fi

  # Step 3: 从最后状态推导派发目标
  local PANE_PM="$SESSION_NAME:0.0"
  local PANE_PLANNER="$SESSION_NAME:0.1"
  local PANE_BUILDER="$SESSION_NAME:0.2"
  local PANE_EVALUATOR="$SESSION_NAME:0.3"
  local LIVE_PM LIVE_PLANNER LIVE_BUILDER LIVE_EVALUATOR
  LIVE_PM=$(detect_pane_by_persona_simple "$SESSION_NAME" 0 "pm" "$PANE_PM")
  LIVE_PLANNER=$(detect_pane_by_persona_simple "$SESSION_NAME" 0 "planner" "$PANE_PLANNER")
  LIVE_BUILDER=$(detect_pane_by_persona_simple "$SESSION_NAME" 0 "builder" "$PANE_BUILDER")
  LIVE_EVALUATOR=$(detect_pane_by_persona_simple "$SESSION_NAME" 0 "evaluator" "$PANE_EVALUATOR")
  if [[ "$LIVE_PM" == "$PANE_PM" ]]; then
    local pm_actual
    pm_actual=$(pane_process_persona_simple "$LIVE_PM" 2>/dev/null || true)
    [[ "$pm_actual" == "pm" ]] || LIVE_PM="$LIVE_PLANNER"
  fi
  local target_pane="" target_task=""

  case "$st" in
    drafting|drafting_held)
      if [[ "$contract_bypass" == "true" || "$handoff_to" =~ ^builder(_main)?$ || "$contract_handoff" =~ ^builder(_main)?$ || "$contract_target" =~ ^builder(_main)?$ ]]; then
        python3 - "$sf" <<'PY' 2>/dev/null || true
import datetime, json, sys
sf = sys.argv[1]
d = json.load(open(sf))
now = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
d["status"] = "active"
d["phase"] = "planning_complete"
d["handoff_to"] = "builder"
d["auto_held"] = False
d["updated_at"] = now
d.setdefault("history", []).append({
    "ts": now,
    "event": "wake_promoted_bypass_pm_to_builder",
    "by": "wake",
    "note": "Strict wake routing: bypass_pm/handoff_to builder must not route to PM or planner."
})
json.dump(d, open(sf, "w"), indent=2, ensure_ascii=False)
PY
        st="active"
        target_pane="$LIVE_BUILDER"
        target_task="Sprint ${sid} 恢复：这是 bypass_pm/Builder 目标合同，禁止转 PM/Planner。请读取 contract/plan 并执行。cat ~/.solar/harness/sprints/${sid}.contract.md"
      elif [[ "$auto_held" == "true" || "$st" == "drafting_held" ]]; then
        ok "Sprint ${sid} 当前为 ${st}/auto_held，wake 不强推。请先人工解除 hold 或 activate。"
        return 0
      elif [[ "$phase" == "prd_ready" || "$handoff_to" == "planner" ]]; then
        target_pane="$LIVE_PLANNER"
        target_task="Sprint ${sid} 恢复：PRD 已完成，请读取 PRD 和 contract，写 design.md 与 plan.md，完成后将 status=active、phase=planning_complete、handoff_to=builder_main。"
      else
        target_pane="$LIVE_PM"
        target_task="Sprint ${sid} 恢复：请在产品经理窗口研究用户需求并产出 PRD。"
      fi
      ;;
    active)
      target_pane="$LIVE_BUILDER"
      target_task="Sprint ${sid} 恢复：请读取合约并继续实现。cat ~/.solar/harness/sprints/${sid}.contract.md"
      ;;
    planning)
      target_pane="$LIVE_EVALUATOR"
      target_task="Sprint ${sid} 恢复：建设者已提交计划，请审批。cat ~/.solar/harness/sprints/${sid}.plan.md"
      ;;
    approved)
      target_pane="$LIVE_BUILDER"
      target_task="Sprint ${sid} 恢复：计划已批准，请继续实现。cat ~/.solar/harness/sprints/${sid}.plan.md"
      ;;
    reviewing|ready_for_review)
      target_pane="$LIVE_EVALUATOR"
      target_task="Sprint ${sid} 恢复：建设者已提交，请评审。cat ~/.solar/harness/sprints/${sid}.handoff.md"
      ;;
    failed_review)
      target_pane="$LIVE_BUILDER"
      target_task="Sprint ${sid} 恢复：评审未通过，请修复。cat ~/.solar/harness/sprints/${sid}.eval.md"
      ;;
    interrupted)
      # 被 kill_harness 打断，改回 reviewing 让 coordinator 重新派发
      python3 -c "
import json, datetime
d = json.load(open('$sf'))
d['status'] = 'reviewing'
d['updated_at'] = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
json.dump(d, open('$sf', 'w'), indent = 2)
" 2>/dev/null
      target_pane="$LIVE_EVALUATOR"
      target_task="Sprint ${sid} 恢复 (从 interrupted)：请评审。cat ~/.solar/harness/sprints/${sid}.handoff.md"
      ;;
    *)
      warn "未知状态: ${st}，派发给建设者"
      target_pane="$LIVE_BUILDER"
      target_task="Sprint ${sid} 恢复：当前状态 ${st}，请检查并继续。"
      ;;
  esac

  # Step 4: 重新生成 dispatch.md 并派发
  cat > "$SPRINTS_DIR/${sid}.dispatch.md" << DISPATCH_EOF
# 协调器恢复指令 (Wake)

${target_task}
DISPATCH_EOF

  local short_cmd="读取并执行指令文件 $SPRINTS_DIR/${sid}.dispatch.md 中的所有步骤"
  # Claude TUI can leave stale input in the prompt after interrupts; clear the
  # current input line and send Enter twice so wake does not stop at a queued
  # prompt requiring a manual second Enter.
  tmux send-keys -t "$target_pane" C-u 2>/dev/null || true
  sleep 0.2
  tmux send-keys -t "$target_pane" "$short_cmd" 2>/dev/null || true
  sleep 0.5
  tmux send-keys -t "$target_pane" Enter 2>/dev/null || true
  sleep 0.3
  tmux send-keys -t "$target_pane" Enter 2>/dev/null || true

  # Step 5: 记录 wake 事件
  bash "$HARNESS_DIR/session.sh" append "$sid" "{\"event\":\"waked\",\"by\":\"wake\",\"data\":{\"from_status\":\"${original_st}\",\"target_pane\":\"${target_pane}\"}}" 2>/dev/null || true

  ok "Sprint ${sid} 已恢复 → ${target_pane} (从 ${original_st})"

  # Step 6: 确保 coordinator 在运行
  _ensure_bash4 2>/dev/null || true
  local coord_bash="${BASH4:-bash}"
  if [[ -f "$HARNESS_DIR/.coordinator.pid" ]]; then
    local pid
    pid=$(cat "$HARNESS_DIR/.coordinator.pid")
    if ! kill -0 "$pid" 2>/dev/null; then
      warn "Coordinator PID ${pid} 已死，重启..."
      rm -f "$HARNESS_DIR/.coordinator.pid"
      nohup "$coord_bash" "$HARNESS_DIR/coordinator.sh" >> "$HARNESS_DIR/.coordinator.log" 2>&1 &
      disown 2>/dev/null || true
      ok "Coordinator 重启中..."
    else
      ok "Coordinator 运行中 (PID: ${pid})"
    fi
  else
    warn "无 coordinator PID 文件，启动新的..."
    nohup "$coord_bash" "$HARNESS_DIR/coordinator.sh" >> "$HARNESS_DIR/.coordinator.log" 2>&1 &
    ok "Coordinator 启动中..."
  fi
}

# ---- Atomic Commands (Sprint 20260420-113026) ----

do_handoff_submit() {
  local sid="$1"
  local sf="$SPRINTS_DIR/${sid}.status.json"
  local hf="$SPRINTS_DIR/${sid}.handoff.md"
  rs_exists "$sid" || { err "Sprint not found: $sid"; exit 1; }
  [[ -f "$hf" ]] || { err "handoff.md not found for $sid — 先写 handoff 再提交"; exit 1; }

  local handoff_mtime
  handoff_mtime=$(stat -f %m "$hf" 2>/dev/null || echo 0)

  # Idempotent: same handoff mtime = already submitted
  python3 -c "
import json
d=json.load(open('$sf'))
if d.get('last_handoff_mtime') == float('${handoff_mtime}'):
    exit(0)
exit(1)
" 2>/dev/null && { ok "handoff-submit: $sid already submitted (handoff unchanged)"; return 0; } || true

  rs_transition_with_round_bump "$sid" "reviewing" "implementation_completed" "builder" \
    || { err "handoff-submit 写入失败"; exit 1; }

  # Write last_handoff_mtime as top-level field
  python3 -c "
import json, os, tempfile
sf=os.path.expanduser('$sf')
d=json.load(open(sf))
d['last_handoff_mtime']=float('${handoff_mtime}')
fd,tmp=tempfile.mkstemp(dir=os.path.dirname(sf))
with os.fdopen(fd,'w') as f: json.dump(d,f,indent=2)
os.rename(tmp,sf)
" || true

  bash "$HARNESS_DIR/session.sh" append "$sid" "{\"ts\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\",\"event\":\"handoff_submitted\",\"by\":\"builder\",\"sid\":\"$sid\"}" 2>/dev/null || true
  type ledger_emit &>/dev/null && ledger_emit "produced" "$sid.handoff.md" "{\"by\":\"builder\"}" 2>/dev/null || true

  # sprint-20260508-coordinator-control-plane-v2 S3: write ack file so ack-watcher can confirm
  local _did_file="$SPRINTS_DIR/${sid}.current-dispatch-id"
  if [[ -f "$_did_file" ]]; then
    local _did
    _did=$(cat "$_did_file" 2>/dev/null || true)
    if [[ -n "$_did" ]]; then
      local _ack_file="$SPRINTS_DIR/${sid}.ack-${_did}.json"
      python3 -c "
import json, datetime, os, sys
sid=sys.argv[1]; did=sys.argv[2]; path=sys.argv[3]
now=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
ack={'dispatch_id':did,'sid':sid,'role':'builder','status':'success',
     'exit_code':0,'message':'handoff submitted','artifacts':['handoff.md'],'wrote_at':now}
with open(path,'w') as f: json.dump(ack,f,indent=2)
" "$sid" "$_did" "$_ack_file" 2>/dev/null || true
    fi
  fi

  ok "handoff-submit: $sid → reviewing"
}

do_plan_verdict() {
  local sid="$1" verdict="$2" reason="${3:-}"
  rs_exists "$sid" || { err "Sprint not found: $sid"; exit 1; }

  local new_status verdict_upper
  case "$verdict" in
    approve|approved) new_status="approved"; verdict_upper="APPROVE" ;;
    reject|rejected)  new_status="active";   verdict_upper="REJECT" ;;
    *) err "verdict 必须是 approve 或 reject"; exit 1 ;;
  esac

  local extra_json
  if [[ -n "$reason" ]]; then
    extra_json=$(python3 -c "import json; print(json.dumps({'verdict':'$verdict_upper','reason':'$reason'}))")
  else
    extra_json="{\"verdict\":\"$verdict_upper\"}"
  fi

  rs_transition "$sid" "$new_status" "plan_reviewed" "evaluator" "$extra_json" \
    || { err "plan-verdict 写入失败"; exit 1; }

  bash "$HARNESS_DIR/session.sh" append "$sid" "{\"ts\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\",\"event\":\"plan_verdict\",\"by\":\"evaluator\",\"verdict\":\"${verdict}\",\"sid\":\"$sid\"}" 2>/dev/null || true
  ok "plan-verdict: $sid → $new_status"
}

do_eval_verdict() {
  local sid="$1" verdict="$2" reason="${3:-}"
  rs_exists "$sid" || { err "Sprint not found: $sid"; exit 1; }

  local new_status event_name verdict_upper
  case "$verdict" in
    pass|passed)
      new_status="passed"; event_name="eval_passed"; verdict_upper="PASS" ;;
    fail|failed)
      new_status="failed_review"; event_name="eval_failed"; verdict_upper="FAIL" ;;
    *) err "verdict 必须是 pass 或 fail"; exit 1 ;;
  esac

  local extra_json
  if [[ -n "$reason" ]]; then
    extra_json=$(python3 -c "import json; print(json.dumps({'verdict':'$verdict_upper','reason':'$reason'}))")
  else
    extra_json="{\"verdict\":\"$verdict_upper\"}"
  fi

  if [[ "$new_status" == "failed_review" ]]; then
    rs_transition_with_round_bump "$sid" "$new_status" "eval_completed" "evaluator" "$extra_json" \
      || { err "eval-verdict 写入失败"; exit 1; }
  else
    rs_transition "$sid" "$new_status" "eval_completed" "evaluator" "$extra_json" \
      || { err "eval-verdict 写入失败"; exit 1; }
  fi

  bash "$HARNESS_DIR/session.sh" append "$sid" "{\"ts\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\",\"event\":\"${event_name}\",\"by\":\"evaluator\",\"verdict\":\"${verdict}\",\"sid\":\"$sid\"}" 2>/dev/null || true
  local ledger_event
  if [[ "$new_status" == "passed" ]]; then
    ledger_event="accepted"
  else
    ledger_event="rejected"
  fi
  type ledger_emit &>/dev/null && ledger_emit "$ledger_event" "$sid.handoff.md" "{\"verdict\":\"$verdict_upper\",\"by\":\"evaluator\"}" 2>/dev/null || true
  ok "eval-verdict: $sid → $new_status"
}

do_verify_events() {
  local sid="$1"
  local sf="$SPRINTS_DIR/${sid}.status.json"
  local events_file="$SPRINTS_DIR/${sid}.events.jsonl"
  [[ ! -f "$sf" ]] && { err "Sprint not found: $sid"; exit 1; }

  local issues=0 fixed=0

  # 1. Check history events vs events.jsonl
  local history_events
  history_events=$(python3 -c "
import json
d = json.load(open('$sf'))
for h in d.get('history', []):
    print(h.get('event',''))
" 2>/dev/null)

  if [[ -f "$events_file" ]]; then
    local events_recorded
    events_recorded=$(grep -c '.' "$events_file" 2>/dev/null || echo 0)

    for evt in $history_events; do
      if ! grep -q "\"$evt\"" "$events_file" 2>/dev/null; then
        log "[verify] history has '$evt' but events.jsonl missing it"
        ((issues++))
        bash "$HARNESS_DIR/session.sh" append "$sid" "{\"ts\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\",\"event\":\"${evt}\",\"by\":\"verify-repair\",\"sid\":\"$sid\",\"source\":\"history_backfill\"}" 2>/dev/null || true
        ((fixed++))
      fi
    done
  else
    log "[verify] no events.jsonl for $sid"
    ((issues++))
  fi

  # 2. Check status consistency
  local st
  st=$(python3 -c "import json; print(json.load(open('$sf')).get('status',''))" 2>/dev/null)
  if [[ "$st" == "passed" ]] && [[ ! -f "$SPRINTS_DIR/${sid}.finalized" ]]; then
    log "[verify] status=passed but no .finalized"
    ((issues++))
  fi

  # 3. Per-round completeness check (Sprint 20260420-191039)
  python3 -c "
import json
d = json.load(open('$sf'))
history = d.get('history', [])
max_round = d.get('round', 0)
for r in range(1, max_round + 1):
    has_impl = any(h.get('event') == 'implementation_completed' and h.get('round') == r for h in history)
    # eval_completed may have round=N (FAIL) or no round key (final PASS)
    has_eval = any(h.get('event') == 'eval_completed' and (h.get('round') == r or (r == max_round and 'round' not in h)) for h in history)
    if not has_impl:
        print(f'WARN: round {r} missing implementation_completed — 补齐: python3 -c ... append history')
    if not has_eval:
        print(f'WARN: round {r} missing eval_completed — 补齐: bash solar-harness.sh eval-verdict $sid pass/fail')
" 2>/dev/null | while IFS= read -r line; do
    log "[verify] $line"
    ((issues++))
  done

  if (( issues == 0 )); then
    ok "verify-events: $sid — 一致 (0 issues)"
  else
    log "verify-events: $sid — ${issues} issues, ${fixed} fixed"
  fi
}

# ---- Main ----

# ---- Capsule / Ledger (sprint-20260503-163542 D5) ----

CAPSULE_FIELDS=("goal" "facts_established" "changes_made" "risks" "open_questions" "required_next_action" "recursion_round" "topology")

do_capsule_show() {
  local sid="$1"
  local sf="$SPRINTS_DIR/${sid}.status.json"
  rs_exists "$sid" || { err "Sprint not found: $sid"; exit 1; }

  local topology round mode
  topology=$(rs_read_field "$sid" "topology")
  [[ -z "$topology" ]] && topology="standard"
  round=$(rs_read_field "$sid" "round")
  [[ -z "$round" ]] && round="0"
  mode=$(rs_read_field "$sid" "mode")
  [[ -z "$mode" ]] && mode="balanced"

  echo "=== Capsule: $sid ==="
  echo "topology: $topology"
  echo "recursion_round: $round"
  echo "mode: $mode"

  # Extract 8 fields from plan/handoff/eval files
  for doc in plan handoff eval; do
    local f="$SPRINTS_DIR/${sid}.${doc}.md"
    [[ -f "$f" ]] || continue
    echo ""
    echo "--- from ${doc}.md ---"
    for field in "${CAPSULE_FIELDS[@]}"; do
      local field_title
      field_title=$(echo "$field" | sed 's/_/ /g')
      # Try ## Section header format (case-insensitive via awk)
      local val
      val=$(awk -v pat="$field_title" 'BEGIN{IGNORECASE=1} tolower($0) ~ "^##+ *"tolower(pat)" *$"{found=1; next} found && /^##+/{exit} found && NF{print}' "$f" | head -3)
      if [[ -z "$val" ]]; then
        # Try yaml frontmatter
        val=$(grep -i "^${field}:" "$f" 2>/dev/null | head -1 | sed "s/^[^:]*:[[:space:]]*//")
      fi
      [[ -n "$val" ]] && echo "  $field: $val"
    done
  done
  echo ""
}

do_ledger_show() {
  local sid="$1"
  type ledger_events_for_sid &>/dev/null || { err "bridge-ledger.sh not loaded"; exit 1; }
  echo "=== Ledger: $sid ==="
  local events
  events=$(ledger_events_for_sid "$sid")
  if [[ -z "$events" ]]; then
    echo "(no events)"
  else
    echo "$events" | python3 -c "
import sys, json
for line in sys.stdin:
    line = line.strip()
    if not line: continue
    try:
        d = json.loads(line)
        print(f\"  {d.get('ts','')} [{d.get('event','')}] {d.get('artifact','')}\" + (' → ' + d.get('verdict','') if 'verdict' in d else ''))
    except: pass
"
  fi
}

# ---- Update Contract (Sprint 20260420-082442, D4: 从 case 分支提取为函数) ----

do_update_contract() {
  local usid="${2:-}" section="${3:-}" content="${4:-}"
  if [[ -z "$usid" ]] || [[ -z "$section" ]] || [[ -z "$content" ]]; then
    usid=$(ls "$SPRINTS_DIR"/*.status.json 2>/dev/null | sort | tail -1 | xargs -I{} python3 -c "import json; print(json.load(open('{}'))['id'])" 2>/dev/null)
    [[ -z "$usid" ]] && { err "无活跃 Sprint"; exit 1; }
    err "用法: $0 update-contract <sprint-id> done \"- [ ] 条件1\n- [ ] 条件2\""
    log "当前 Sprint: $usid"
    exit 1
  fi
  local cfile="$SPRINTS_DIR/${usid}.contract.md"
  [[ -f "$cfile" ]] || { err "合约不存在: $cfile"; exit 1; }

  case "$section" in
    done)
      # D7: 用 base64 编码避免 HEREDOC 特殊字符吞参数 (Sprint 20260423-062851)
      local encoded
      encoded=$(printf '%s' "$content" | base64)
      python3 -c "
import re, base64, sys
content = open('$cfile').read()
new_done = base64.b64decode('$encoded').decode('utf-8')
pattern = r'(## (?:Done 定义|Definition of Done)\n\n(?:>.*?\n\n)?)(.*?)(\n## )'
def replacer(m):
    return m.group(1) + new_done + '\n\n' + m.group(3)
result = re.sub(pattern, replacer, content, flags=re.DOTALL)
if result == content:
    print('Warning: update-contract regex did not match, contract unchanged', file=sys.stderr)
    sys.exit(1)
open('$cfile', 'w').write(result)
print('Done 定义已更新')
" 2>/dev/null
      ok "合约更新: $cfile"
      ;;
    scope)
      local encoded
      encoded=$(printf '%s' "$content" | base64)
      python3 -c "
import re, base64
content = open('$cfile').read()
new_scope = base64.b64decode('$encoded').decode('utf-8')
pattern = r'(## 范围\n\n)(.*?)(\n## )'
def replacer(m):
    return m.group(1) + new_scope + '\n\n' + m.group(3)
result = re.sub(pattern, replacer, content, flags=re.DOTALL)
open('$cfile', 'w').write(result)
" 2>/dev/null
      ok "范围已更新"
      ;;
    constraints)
      local encoded
      encoded=$(printf '%s' "$content" | base64)
      python3 -c "
import re, base64
content = open('$cfile').read()
new_c = base64.b64decode('$encoded').decode('utf-8')
pattern = r'(## 约束\n\n>.*?\n\n)(.*?)(\n## )'
def replacer(m):
    return m.group(1) + new_c + '\n\n' + m.group(3)
result = re.sub(pattern, replacer, content, flags=re.DOTALL)
open('$cfile', 'w').write(result)
" 2>/dev/null
      ok "约束已更新"
      ;;
    *)
      err "未知 section: $section (支持: done, scope, constraints)"
      ;;
  esac
}

# Sprint 20260420-090726 D2: 僵尸 cancelled 文件清理
do_clean_corrupted() {
  local apply="${1:-}"
  local qdir="$SPRINTS_DIR/.quarantine/$(date +%Y-%m-%d)"
  local count=0

  echo "扫描僵尸文件..."
  for f in "$SPRINTS_DIR"/sprint-*.status.json; do
    [[ -f "$f" ]] || continue
    local fid
    fid=$(python3 -c "import json; print(json.load(open('$f')).get('id',''))" 2>/dev/null)
    if [[ -z "$fid" ]]; then
      ((count++))
      echo "  僵尸: $(basename "$f")"
      if [[ "$apply" == "--apply" ]]; then
        mkdir -p "$qdir"
        mv "$f" "$qdir/"
        mkdir -p "$SPRINTS_DIR/.quarantine"
        echo "- $(basename "$f") | id为空 | $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$SPRINTS_DIR/.quarantine/MANIFEST.md"
      fi
    fi
  done

  if [[ "$apply" != "--apply" ]]; then
    echo "共 ${count} 个僵尸文件 (dry-run, 用 --apply 执行)"
  else
    echo "已隔离 ${count} 个僵尸文件到 .quarantine/"
  fi
}

# sprint-20260503-195627 D3: telemetry stats
TELEMETRY_FILE="${HARNESS_DIR}/telemetry/runs.jsonl"

do_stats_overview() {
  [[ -f "$TELEMETRY_FILE" ]] || { echo "无 telemetry 数据"; return 0; }
  python3 - "$TELEMETRY_FILE" <<'PY'
import json, sys
from collections import Counter
tf = sys.argv[1]
runs = []
with open(tf) as f:
    for line in f:
        line = line.strip()
        if not line: continue
        try: runs.append(json.loads(line))
        except: pass
if not runs:
    print("无 telemetry 数据"); sys.exit(0)
total = len(runs)
passed = sum(1 for r in runs if r.get("verdict") == "passed")
failed = total - passed
avg_rounds = sum(r.get("rounds", 0) for r in runs) / total
durations = [r.get("duration_sec", 0) for r in runs if r.get("duration_sec", 0) > 0]
avg_dur = sum(durations) / len(durations) if durations else 0
print(f"总览 (最近 {total} 个 sprint 终态)")
print(f"  总数: {total}  |  通过: {passed}  |  失败: {failed}  |  通过率: {passed/total*100:.1f}%")
print(f"  平均轮次: {avg_rounds:.1f}  |  平均耗时: {avg_dur:.0f}s")
print()
topos = {}
for r in runs:
    t = r.get("topology", "standard")
    if t not in topos:
        topos[t] = {"total": 0, "passed": 0, "rounds": [], "dur": []}
    topos[t]["total"] += 1
    if r.get("verdict") == "passed":
        topos[t]["passed"] += 1
    topos[t]["rounds"].append(r.get("rounds", 0))
    d = r.get("duration_sec", 0)
    if d > 0: topos[t]["dur"].append(d)
print("各拓扑通过率:")
for t in sorted(topos.keys()):
    v = topos[t]
    rate = v["passed"] / v["total"] * 100 if v["total"] else 0
    ar = sum(v["rounds"]) / len(v["rounds"]) if v["rounds"] else 0
    ad = sum(v["dur"]) / len(v["dur"]) if v["dur"] else 0
    print(f"  {t:15s}  {v['passed']}/{v['total']}  ({rate:5.1f}%)  avg {ar:.1f}轮  {ad:.0f}s")
fail_counter = Counter()
for r in runs:
    for d in r.get("fail_dones", []):
        fail_counter[d] += 1
if fail_counter:
    print()
    print("Top 5 最常 FAIL 的 Done:")
    for done, cnt in fail_counter.most_common(5):
        print(f"  {done}: {cnt} 次")
PY
}

do_stats_topology() {
  local name="$1"
  [[ -z "$name" ]] && { err "用法: solar-harness stats topology <name>"; exit 1; }
  [[ -f "$TELEMETRY_FILE" ]] || { echo "无 telemetry 数据"; return 0; }
  python3 - "$TELEMETRY_FILE" "$name" <<'PY'
import json, sys
tf, name = sys.argv[1:]
runs = []
with open(tf) as f:
    for line in f:
        line = line.strip()
        if not line: continue
        try: runs.append(json.loads(line))
        except: pass
filtered = [r for r in runs if r.get("topology") == name]
if not filtered:
    print(f"无 topology={name} 的数据"); sys.exit(0)
total = len(filtered)
passed = sum(1 for r in filtered if r.get("verdict") == "passed")
avg_r = sum(r.get("rounds", 0) for r in filtered) / total
durs = [r.get("duration_sec", 0) for r in filtered if r.get("duration_sec", 0) > 0]
avg_d = sum(durs) / len(durs) if durs else 0
print(f"拓扑: {name}")
print(f"  总数: {total}  |  通过: {passed}  |  通过率: {passed/total*100:.1f}%")
print(f"  平均轮次: {avg_r:.1f}  |  平均耗时: {avg_d:.0f}s")
print()
print("最近 runs:")
for r in filtered[-10:]:
    v = r.get("verdict", "?")
    s = r.get("sid", "?")[:20]
    print(f"  {s}  round={r.get('rounds',0)}  {v}  {r.get('duration_sec',0):.0f}s")
PY
}

do_stats_sprint() {
  local sid="$1"
  [[ -z "$sid" ]] && { err "用法: solar-harness stats sprint <sid>"; exit 1; }
  [[ -f "$TELEMETRY_FILE" ]] || { echo "无 telemetry 数据"; return 0; }
  python3 - "$TELEMETRY_FILE" "$sid" <<'PY'
import json, sys
tf, sid = sys.argv[1:]
with open(tf) as f:
    for line in f:
        line = line.strip()
        if not line: continue
        try:
            r = json.loads(line)
            if r.get("sid") == sid:
                for k, v in r.items():
                    print(f"  {k}: {v}")
                sys.exit(0)
        except: pass
print(f"未找到 sid={sid} 的 telemetry 记录")
PY
}

do_main_status() {
  printf '%s\n' "Solar Harness Main Status"
  printf '%s\n' "runtime != assignment != artifact: pane output alone is not proof of progress."
  printf '%s\n' ""
  printf '┌────────────┬────────────┬──────────────┬────────────────────────────┬─────────────────────┬────────────────────────────┐\n'
  printf '│ Pane       │ Role       │ Runtime      │ Assignment                 │ Artifact            │ Title                      │\n'
  printf '├────────────┼────────────┼──────────────┼────────────────────────────┼─────────────────────┼────────────────────────────┤\n'

  local i pane role title tail runtime assignment sid artifact file
  for i in 0 1 2 3; do
    pane="$SESSION_NAME:0.$i"
    case "$i" in
      0) role="PM" ;;
      1) role="Planner" ;;
      2) role="Builder" ;;
      3) role="Evaluator" ;;
    esac
    title="N/A"; runtime="missing"; assignment="N/A"; artifact="N/A"

    if tmux display-message -p -t "$pane" '#{pane_id}' >/dev/null 2>&1; then
      title=$(tmux display-message -p -t "$pane" '#{pane_title}' 2>/dev/null || echo "N/A")
      tail=$(tmux capture-pane -t "$pane" -p -S -40 2>/dev/null | tail -40 || true)
      if printf '%s\n' "$tail" | grep -qiE 'Generating|thinking|Thinking|Hmm|Reading|Bash|Write|Edit|Update|Inferring|Hatching|Whirlpooling|Enchanting|Meandering|Philosophising|Brewing|Baking|Calculating|Percolating|Marinating|Befuddling|Compacting conversation|Press up to edit queued messages'; then
        runtime="active"
      else
        runtime="idle"
      fi
    fi

    if [[ -f "$HARNESS_DIR/.pane-assignments" ]]; then
      assignment=$(awk -F'[=:]' -v p="$pane" '$1":"$2 == p {print $3}' "$HARNESS_DIR/.pane-assignments" 2>/dev/null | tail -1)
      [[ -z "$assignment" ]] && assignment="N/A"
    fi

    sid="$assignment"
    if [[ "$sid" != "N/A" ]]; then
      case "$role" in
        PM)
          file="$SPRINTS_DIR/${sid}.prd.md"
          [[ -f "$file" ]] || file="$SPRINTS_DIR/${sid}.product-brief.md"
          ;;
        Planner) file="$SPRINTS_DIR/${sid}.plan.md" ;;
        Builder) file="$SPRINTS_DIR/${sid}.handoff.md" ;;
        Evaluator) file="$SPRINTS_DIR/${sid}.eval.md" ;;
      esac
      if [[ -f "$file" ]]; then
        artifact=$(stat -f '%Sm' -t '%Y-%m-%d %H:%M:%S' "$file" 2>/dev/null || echo "present")
      else
        artifact="missing"
      fi
    fi

    printf '│ %-10s │ %-10s │ %-12s │ %-26s │ %-19s │ %-26s │\n' \
      "pane$i" "$role" "$runtime" "$(printf '%.26s' "$assignment")" "$(printf '%.19s' "$artifact")" "$(printf '%.26s' "$title")"
  done

  printf '└────────────┴────────────┴──────────────┴────────────────────────────┴─────────────────────┴────────────────────────────┘\n'
}

do_lab_status() {
  local sid="${1:-}"
  local lab_dir="$SPRINTS_DIR"
  [[ -n "$sid" ]] && lab_dir="$SPRINTS_DIR/${sid#sprint-20260507-obsidian-wiki}"
  # Current Obsidian Wiki lab uses a fixed sidecar directory. Keep this generic
  # enough for operators while making artifact-vs-runtime status explicit.
  if [[ -d "$SPRINTS_DIR/obsidian-wiki-lab" ]]; then
    lab_dir="$SPRINTS_DIR/obsidian-wiki-lab"
  fi

  printf '%s\n' "Solar Harness Lab Status"
  printf '%s\n' "artifact != runtime: handoff files prove delivery; pane state proves current activity."
  printf '%s\n' ""
  printf '┌───────────────┬──────────────┬──────────────┬─────────────────────┬────────────────────────────┐\n'
  printf '│ Pane          │ Runtime      │ Artifact     │ Latest Handoff      │ Title                      │\n'
  printf '├───────────────┼──────────────┼──────────────┼─────────────────────┼────────────────────────────┤\n'

  local i pane title tail runtime artifact latest latest_ts
  for i in 0 1 2 3; do
    pane="$LAB_SESSION_NAME:0.$i"
    title="N/A"
    runtime="missing"
    artifact="missing"
    latest_ts="N/A"
    if tmux display-message -p -t "$pane" '#{pane_id}' >/dev/null 2>&1; then
      title=$(tmux display-message -p -t "$pane" '#{pane_title}' 2>/dev/null || echo "N/A")
      tail=$(tmux capture-pane -t "$pane" -p -S -40 2>/dev/null | tail -40 || true)
      if printf '%s\n' "$tail" | grep -qiE 'Generating|thinking|Thinking|Hmm|Reading|Bash|Write|Edit|Update|Inferring|Hatching|Whirlpooling|Enchanting|Meandering|Philosophising|Brewing|Baking|Calculating|Percolating|Marinating|Befuddling|Compacting conversation|Press up to edit queued messages'; then
        runtime="active"
      else
        runtime="idle"
      fi
    fi

    latest=$(ls -t "$lab_dir"/lab-builder-$((i+1))*handoff.md 2>/dev/null | head -1 || true)
    if [[ -n "$latest" && -f "$latest" ]]; then
      artifact="present"
      latest_ts=$(stat -f '%Sm' -t '%Y-%m-%d %H:%M:%S' "$latest" 2>/dev/null || echo "N/A")
    fi
    printf '│ %-13s │ %-12s │ %-12s │ %-19s │ %-26s │\n' \
      "lab-builder-$((i+1))" "$runtime" "$artifact" "$latest_ts" "$(printf '%.26s' "$title")"
  done

  printf '└───────────────┴──────────────┴──────────────┴─────────────────────┴────────────────────────────┘\n'
}

# ---- Main ----

case "${1:-start}" in
  start|"")  start_harness 3 "${2:-$(pwd)}" "${3:-}" ;;
  2)         start_harness 2 "${2:-$(pwd)}" "${3:-}" ;;
  3)         start_harness 3 "${2:-$(pwd)}" "${3:-}" ;;
  status)    show_status ;;
  main-status) do_main_status ;;
  lab-status) do_lab_status "${2:-}" ;;
  doctor)    bash "$HARNESS_DIR/doctor.sh" "${2:-}" ;;
  --skip-doctor) start_harness 3 "${2:-$(pwd)}" "--skip-doctor" ;;
  coord-status)
    # Sprint 20260420-082442 D2: 协调器状态诊断
    pidfile="$HARNESS_DIR/.coordinator.pid"
    running=false; stale_lock=false; pid=0; uptime_s=0
    if [[ -f "$pidfile" ]]; then
      pid=$(cat "$pidfile" 2>/dev/null)
      if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then
        running=true
        # 计算运行时间
        start_ts=$(ps -p "$pid" -o lstart= 2>/dev/null)
        if [[ -n "$start_ts" ]]; then
          uptime_s=$(( $(date +%s) - $(date -j -f "%a %b %d %H:%M:%S %Y" "$start_ts" +%s 2>/dev/null || echo $(date +%s)) ))
        fi
      else
        stale_lock=true
      fi
    fi
    python3 -c "
import json
print(json.dumps({
    'running': '$running' == 'true',
    'pid': $pid,
    'uptime_s': $uptime_s,
    'stale_lock': '$stale_lock' == 'true'
}, indent=2))
" 2>/dev/null
    ;;
  # Sprint 20260420-090726 D2: 僵尸文件清理
  clean-corrupted)
    do_clean_corrupted "${2:-}"
    ;;
  kill|stop) kill_harness ;;
  扩展|extend) start_extension "${2:-$(pwd)}" ;;
  sprint)
    [[ -z "${2:-}" ]] && { err "用法: $0 sprint \"需求描述\""; exit 1; }
    new_sprint "$2"
    ;;
  attach)
    if tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
      attach_or_print
    else
      err "未运行"
    fi
    ;;
  monitor)
    if ! tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
      err "Harness 未运行，先启动: $0"
      exit 1
    fi
    tmux new-window -t "$SESSION_NAME" -n "monitor" -c "$HOME"
    tmux send-keys -t "$SESSION_NAME:monitor" "bash $HARNESS_DIR/monitor.sh" Enter
    ok "monitor 已在独立窗口打开"
    log "Ctrl-b n 切到下一个窗口, Ctrl-b p 切回上一个"
    ;;
  wake)
    wake_sprint "$@"
    ;;
  webhook)
    case "${2:-start}" in
      start)
        if [[ -f "$HARNESS_DIR/.webhook.pid" ]] && kill -0 "$(cat "$HARNESS_DIR/.webhook.pid")" 2>/dev/null; then
          ok "Webhook server 已在运行 (PID: $(cat "$HARNESS_DIR/.webhook.pid"))"
        else
          bun "$HARNESS_DIR/webhook-server.ts" >> "$HARNESS_DIR/.webhook.log" 2>&1 &
          echo $! > "$HARNESS_DIR/.webhook.pid"
          ok "Webhook server 启动 (PID: $!, port: ${HARNESS_PORT:-9876})"
          log "日志: $HARNESS_DIR/.webhook.log"
          log "测试: curl -X POST localhost:${HARNESS_PORT:-9876}/sprint -H 'Content-Type: application/json' -d '{\"title\":\"测试\"}'"
        fi
        ;;
      stop)
        if [[ -f "$HARNESS_DIR/.webhook.pid" ]]; then
          kill "$(cat "$HARNESS_DIR/.webhook.pid")" 2>/dev/null
          rm -f "$HARNESS_DIR/.webhook.pid"
          ok "Webhook server 已停止"
        else
          warn "Webhook server 未运行"
        fi
        ;;
      status)
        if [[ -f "$HARNESS_DIR/.webhook.pid" ]] && kill -0 "$(cat "$HARNESS_DIR/.webhook.pid")" 2>/dev/null; then
          ok "运行中 (PID: $(cat "$HARNESS_DIR/.webhook.pid"))"
          curl -s "http://localhost:${HARNESS_PORT:-9876}/health" 2>/dev/null | python3 -m json.tool 2>/dev/null || true
        else
          warn "未运行"
        fi
        ;;
      *) err "用法: $0 webhook [start|stop|status]" ;;
    esac
    ;;
  status-server)
    _SS_PID="$HARNESS_DIR/run/status-server.pid"
    _SS_LOG="$HARNESS_DIR/run/status-server.log"
    _SS_PORT_FILE="$HARNESS_DIR/run/status-server.port"
    _SS_TMUX_SESSION="solar-harness-status-server"
    mkdir -p "$HARNESS_DIR/run"
    case "${2:-start}" in
      start)
        if tmux has-session -t "$_SS_TMUX_SESSION" 2>/dev/null; then
          ok "Status server 已在运行 (tmux: $_SS_TMUX_SESSION, port: $(cat "$_SS_PORT_FILE" 2>/dev/null || echo '?'))"
        elif [[ -f "$_SS_PID" ]] && kill -0 "$(cat "$_SS_PID")" 2>/dev/null; then
          ok "Status server 已在运行 (PID: $(cat "$_SS_PID"), port: $(cat "$_SS_PORT_FILE" 2>/dev/null || echo '?'))"
        elif curl -fsS "http://127.0.0.1:$(cat "$_SS_PORT_FILE" 2>/dev/null || echo 8765)/healthz" >/dev/null 2>&1; then
          ok "Status server 已在运行 (port: $(cat "$_SS_PORT_FILE" 2>/dev/null || echo 8765), pidfile stale)"
        else
          rm -f "$_SS_PID" "$_SS_PORT_FILE"
          if command -v tmux >/dev/null 2>&1; then
            tmux new-session -d -s "$_SS_TMUX_SESSION" \
              "cd '$HARNESS_DIR' && exec python3 '$HARNESS_DIR/lib/symphony/status-server.py' >> '$_SS_LOG' 2>&1"
            echo "tmux:${_SS_TMUX_SESSION}" > "$_SS_PID"
          else
            nohup python3 "$HARNESS_DIR/lib/symphony/status-server.py" >> "$_SS_LOG" 2>&1 &
            echo $! > "$_SS_PID"
          fi
          sleep 0.5
          _port=$(cat "$_SS_PORT_FILE" 2>/dev/null || echo "8765")
          ok "Status server 启动 (port: $_port)"
          log "Dashboard: http://127.0.0.1:$_port/"
          log "日志: $_SS_LOG"
        fi
        ;;
      stop)
        _stopped=0
        if tmux has-session -t "$_SS_TMUX_SESSION" 2>/dev/null; then
          tmux kill-session -t "$_SS_TMUX_SESSION" 2>/dev/null || true
          rm -f "$_SS_PID" "$_SS_PORT_FILE"
          ok "Status server 已停止"
          _stopped=1
        elif [[ -f "$_SS_PID" ]]; then
          _pid_val=$(cat "$_SS_PID" 2>/dev/null || true)
          if [[ "$_pid_val" =~ ^[0-9]+$ ]]; then
            kill "$_pid_val" 2>/dev/null || true
          fi
          rm -f "$_SS_PID" "$_SS_PORT_FILE"
          ok "Status server 已停止"
          _stopped=1
        fi
        _listen_pids=$(lsof -tiTCP:$(cat "$_SS_PORT_FILE" 2>/dev/null || echo 8765) -sTCP:LISTEN 2>/dev/null || true)
        if [[ -n "$_listen_pids" ]]; then
          kill $_listen_pids 2>/dev/null || true
          rm -f "$_SS_PID" "$_SS_PORT_FILE"
          ok "Status server 端口残留进程已停止 (PID: ${_listen_pids//$'\n'/,})"
          _stopped=1
        fi
        if [[ "$_stopped" == "0" ]]; then
          warn "Status server 未运行"
        fi
        ;;
      restart)
        "$0" status-server stop 2>/dev/null || true
        sleep 0.3
        "$0" status-server start
        ;;
      status)
        if tmux has-session -t "$_SS_TMUX_SESSION" 2>/dev/null; then
          _port=$(cat "$_SS_PORT_FILE" 2>/dev/null || echo "8765")
          ok "运行中 (tmux: $_SS_TMUX_SESSION, port: $_port)"
          curl -s "http://127.0.0.1:$_port/healthz" 2>/dev/null && echo || true
        elif [[ -f "$_SS_PID" ]] && [[ "$(cat "$_SS_PID" 2>/dev/null)" =~ ^[0-9]+$ ]] && kill -0 "$(cat "$_SS_PID")" 2>/dev/null; then
          _port=$(cat "$_SS_PORT_FILE" 2>/dev/null || echo "8765")
          ok "运行中 (PID: $(cat "$_SS_PID"), port: $_port)"
          curl -s "http://127.0.0.1:$_port/healthz" 2>/dev/null && echo || true
        elif curl -fsS "http://127.0.0.1:$(cat "$_SS_PORT_FILE" 2>/dev/null || echo 8765)/healthz" >/dev/null 2>&1; then
          _port=$(cat "$_SS_PORT_FILE" 2>/dev/null || echo "8765")
          ok "运行中 (port: $_port, pidfile stale)"
          curl -s "http://127.0.0.1:$_port/healthz" 2>/dev/null && echo || true
        else
          warn "Status server 未运行"
        fi
        ;;
      *) err "用法: $0 status-server [start|stop|restart|status]" ;;
    esac
    ;;
  mermaid)
    _MMD_OPEN=0
    _MMD_FILE="${2:-}"
    if [[ "${_MMD_FILE:-}" == "--open" ]]; then
      _MMD_OPEN=1
      _MMD_FILE="${3:-}"
    fi
    if [[ "${3:-}" == "--open" ]]; then
      _MMD_OPEN=1
    fi
    "$0" status-server start >/dev/null 2>&1 || true
    _MMD_PORT=$(cat "$HARNESS_DIR/run/status-server.port" 2>/dev/null || echo "8765")
    if [[ -n "${_MMD_FILE:-}" ]]; then
      _MMD_URL_PATH=$(python3 -c 'import sys, urllib.parse; print(urllib.parse.quote(sys.argv[1]))' "$_MMD_FILE")
      _MMD_URL="http://127.0.0.1:${_MMD_PORT}/mermaid/view?file=${_MMD_URL_PATH}"
    else
      _MMD_URL="http://127.0.0.1:${_MMD_PORT}/mermaid"
    fi
    ok "Mermaid Viewer: $_MMD_URL"
    if [[ "$_MMD_OPEN" == "1" ]]; then
      open "$_MMD_URL" >/dev/null 2>&1 || true
    fi
    ;;
  integrations)
    _integrations_probe="$HARNESS_DIR/lib/external-integrations-health.py"
    _plugin_loader="$HARNESS_DIR/lib/plugin_loader.py"
    _capability_reg="$HARNESS_DIR/lib/capability_registry.py"
    case "${2:-status}" in
      status|health)
        shift 2 || true
        [[ -f "$_integrations_probe" ]] || { err "external integrations probe not found: $_integrations_probe"; exit 1; }
        python3 "$_integrations_probe" "$@"
        ;;
      plugins|plugin-status)
        shift 2 || true
        [[ -f "$_plugin_loader" ]] || { err "plugin_loader not found: $_plugin_loader"; exit 1; }
        python3 "$_plugin_loader" status "$@"
        ;;
      install)
        shift 2 || true
        [[ -f "$_plugin_loader" ]] || { err "plugin_loader not found: $_plugin_loader"; exit 1; }
        python3 "$_plugin_loader" install "$@"
        ;;
      disable)
        shift 2 || true
        [[ -f "$_plugin_loader" ]] || { err "plugin_loader not found: $_plugin_loader"; exit 1; }
        python3 "$_plugin_loader" disable "$@"
        ;;
      list)
        shift 2 || true
        [[ -f "$_plugin_loader" ]] || { err "plugin_loader not found: $_plugin_loader"; exit 1; }
        python3 "$_plugin_loader" list "$@"
        ;;
      validate)
        shift 2 || true
        [[ -f "$_plugin_loader" ]] || { err "plugin_loader not found: $_plugin_loader"; exit 1; }
        python3 "$_plugin_loader" validate "$@"
        ;;
      capabilities|caps)
        shift 2 || true
        [[ -f "$_capability_reg" ]] || { err "capability_registry not found: $_capability_reg"; exit 1; }
        python3 "$_capability_reg" "${1:-list}" "${@:2}"
        ;;
      sync-caps)
        shift 2 || true
        [[ -f "$_capability_reg" ]] || { err "capability_registry not found: $_capability_reg"; exit 1; }
        python3 "$_capability_reg" sync "$@"
        ;;
      *)
        err "用法: $0 integrations [status|plugins|install|disable|list|validate|capabilities|sync-caps] [--json]"
        exit 1
        ;;
    esac
    ;;
  evolution)
    shift
    _evolution_py="$HARNESS_DIR/lib/evolution_engine.py"
    _failure_py="$HARNESS_DIR/lib/failure_miner.py"
    _eval_py="$HARNESS_DIR/lib/eval_runner.py"
    case "${1:-status}" in
      status|scorecard|run-loop|promote|demote-degraded)
        [[ -f "$_evolution_py" ]] || { err "evolution_engine not found: $_evolution_py"; exit 1; }
        python3 "$_evolution_py" "$@"
        ;;
      mine-failures)
        shift || true
        [[ -f "$_failure_py" ]] || { err "failure_miner not found: $_failure_py"; exit 1; }
        python3 "$_failure_py" mine "$@"
        ;;
      eval-run)
        shift || true
        [[ -f "$_eval_py" ]] || { err "eval_runner not found: $_eval_py"; exit 1; }
        python3 "$_eval_py" run "$@"
        ;;
      *)
        err "用法: $0 evolution [status|scorecard|run-loop|promote|demote-degraded|mine-failures|eval-run] [--json]"
        exit 1
        ;;
    esac
    ;;
  everything-claude-code|ecc)
    shift
    _ecc_adapter="$HARNESS_DIR/lib/everything_claude_code_adapter.py"
    [[ -f "$_ecc_adapter" ]] || { err "everything claude code adapter not found: $_ecc_adapter"; exit 1; }
    case "${1:-doctor}" in
      doctor|inventory|report)
        python3 "$_ecc_adapter" "$@"
        ;;
      install)
        shift
        case "${1:-}" in
          --dry-run|dry-run)
            shift || true
            python3 "$_ecc_adapter" install-dry-run "$@"
            ;;
          *)
            err "用法: $0 everything-claude-code install --dry-run [--json]"
            exit 1
            ;;
        esac
        ;;
      sync)
        shift
        _al=""
        _dr=""
        while [[ $# -gt 0 ]]; do
          case "$1" in
            --allowlist) _al="$2"; shift 2 ;;
            --allowlist=*) _al="${1#--allowlist=}"; shift ;;
            --dry-run) _dr="--dry-run"; shift ;;
            --json) set -- "--json" "$@"; break ;;
            *) shift ;;
          esac
        done
        [[ -n "$_al" ]] || { err "用法: $0 everything-claude-code sync --allowlist <path> [--dry-run] [--json]"; exit 1; }
        python3 "$_ecc_adapter" sync-allowlisted --allowlist "$_al" $_dr "$@"
        ;;
      rollback)
        shift
        python3 "$_ecc_adapter" rollback "$@"
        ;;
      help|--help|-h)
        echo "用法: $0 everything-claude-code [doctor|inventory|report|install --dry-run|sync --allowlist <path>|rollback] [--json]"
        ;;
      *)
        err "用法: $0 everything-claude-code [doctor|inventory|report|install --dry-run|sync --allowlist <path>|rollback] [--json]"
        exit 1
        ;;
    esac
    ;;
  notes)
    shift
    _notes_adapter="$HARNESS_DIR/lib/apple_notes_ingest.py"
    [[ -f "$_notes_adapter" ]] || { err "apple notes adapter not found: $_notes_adapter"; exit 1; }
    case "${1:-doctor}" in
      doctor)
        shift; python3 "$_notes_adapter" doctor --json "$@" ;;
      scan)
        shift; python3 "$_notes_adapter" scan --json "$@" ;;
      status)
        shift; python3 "$_notes_adapter" status --json "$@" ;;
      install-scheduler)
        shift; python3 "$_notes_adapter" install-scheduler --json "$@" ;;
      uninstall-scheduler)
        shift; python3 "$_notes_adapter" uninstall-scheduler --json "$@" ;;
      *)
        err "用法: $0 notes [doctor|scan|status|install-scheduler|uninstall-scheduler] [--dry-run] [--force-dispatch] [--interval N] [--json]"
        exit 1 ;;
    esac
    ;;
  data-plane)
    shift
    _dp_audit="$HARNESS_DIR/lib/data_plane_audit.py"
    [[ -f "$_dp_audit" ]] || { err "data plane audit script not found: $_dp_audit"; exit 1; }
    case "${1:-audit}" in
      audit)        shift; python3 "$_dp_audit" audit "$@" ;;
      repair-state) shift; python3 "$_dp_audit" repair-state "$@" ;;
      *) err "用法: solar-harness data-plane <audit|repair-state> [--json] [--dry-run] [--verbose]"; exit 1 ;;
    esac
    ;;
  skills)
    shift
    _skills_py="$HARNESS_DIR/lib/solar_skills.py"
    [[ -f "$_skills_py" ]] || { err "solar_skills.py not found: $_skills_py"; exit 1; }
    case "${1:-inventory}" in
      inventory)     shift; python3 "$_skills_py" inventory "$@" ;;
      doctor)        shift; python3 "$_skills_py" doctor "$@" ;;
      pane-status)   shift; python3 "$_skills_py" pane-status "$@" ;;
      inject)        shift; python3 "$_skills_py" inject "$@" ;;
      native-extract) shift; python3 "$_skills_py" native-extract "$@" ;;
      registry)      shift; python3 "$_skills_py" registry "$@" ;;
      eval)          shift; python3 "$_skills_py" eval "$@" ;;
      promote)       shift; python3 "$_skills_py" promote "$@" ;;
      rollback)      shift; python3 "$_skills_py" rollback "$@" ;;
      export)        shift; python3 "$_skills_py" export "$@" ;;
      *) err "用法: solar-harness skills <inventory|doctor|export|eval|promote|rollback|registry> [opts]"; exit 1 ;;
    esac
    ;;
  graph)
    shift
    _graph_py="$HARNESS_DIR/lib/harness_graph.py"
    [[ -f "$_graph_py" ]] || { err "harness_graph.py not found: $_graph_py"; exit 1; }
    python3 "$_graph_py" "$@"
    ;;
  mineru)
    # sprint-20260509-mineru-mirage-closeout S2: PDF extraction
    shift
    _mineru_subcmd="${1:-help}"; shift || true
    case "$_mineru_subcmd" in
      extract)
        _ex_py="$HARNESS_DIR/lib/mineru_extract.py"
        [[ -f "$_ex_py" ]] || { err "mineru_extract.py not found"; exit 1; }
        python3 "$_ex_py" "$@"
        ;;
      doctor)
        _md_py="$HARNESS_DIR/lib/mineru_doctor.py"
        [[ -f "$_md_py" ]] || { err "mineru_doctor.py not found"; exit 1; }
        python3 "$_md_py" "$@"
        ;;
      bootstrap)
        bash "$HARNESS_DIR/vendor/mineru/bootstrap.sh" "$@"
        ;;
      help|"")
        echo "Usage: $0 mineru <extract|doctor|bootstrap> [args]"
        echo "  extract <pdf>  Extract PDF to Obsidian references/ (--background --vault PATH)"
        echo "  doctor         Check venv and model status (--json)"
        echo "  bootstrap      Create/repair vendor venv (--force)"
        ;;
      *) err "unknown mineru subcommand: $_mineru_subcmd"; exit 1 ;;
    esac
    ;;
  autopilot)
    shift
    _autopilot="$HARNESS_DIR/tools/solar-autopilot-monitor.py"
    [[ -f "$_autopilot" ]] || { err "autopilot monitor not found: $_autopilot"; exit 1; }
    _autopilot_label="com.solar.autopilot"
    _autopilot_plist="$HOME/Library/LaunchAgents/${_autopilot_label}.plist"
    case "${1:-status}" in
      status|scan)
        python3 "$_autopilot" --json
        ;;
      apply)
        shift
        python3 "$_autopilot" --apply --json "$@"
        ;;
      dispatch)
        shift
        python3 "$_autopilot" --apply --dispatch --json "$@"
        ;;
      loop)
        shift
        python3 "$_autopilot" --apply --dispatch --loop --json "$@"
        ;;
      start)
        mkdir -p "$HOME/Library/LaunchAgents" "$HARNESS_DIR/state" "$HARNESS_DIR/run"
        cat > "$_autopilot_plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>${_autopilot_label}</string>
  <key>ProgramArguments</key>
  <array>
    <string>/usr/bin/python3</string>
    <string>${_autopilot}</string>
    <string>--apply</string>
    <string>--dispatch</string>
    <string>--loop</string>
    <string>--interval</string>
    <string>60</string>
    <string>--cooldown</string>
    <string>300</string>
    <string>--stall-seconds</string>
    <string>180</string>
    <string>--json</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>WorkingDirectory</key>
  <string>${HARNESS_DIR}</string>
  <key>StandardOutPath</key>
  <string>${HARNESS_DIR}/.autopilot-launchd.log</string>
  <key>StandardErrorPath</key>
  <string>${HARNESS_DIR}/.autopilot-launchd.log</string>
  <key>EnvironmentVariables</key>
  <dict>
    <key>PATH</key>
    <string>/opt/homebrew/bin:/usr/local/bin:${HOME}/.solar/bin:${HOME}/.local/bin:/usr/bin:/bin:/usr/sbin:/sbin</string>
  </dict>
</dict>
</plist>
EOF
        launchctl bootout "gui/$(id -u)" "$_autopilot_plist" >/dev/null 2>&1 || true
        launchctl bootstrap "gui/$(id -u)" "$_autopilot_plist"
        launchctl kickstart -k "gui/$(id -u)/${_autopilot_label}" >/dev/null 2>&1 || true
        ok "autopilot started: ${_autopilot_label}"
        ;;
      stop)
        launchctl bootout "gui/$(id -u)" "$_autopilot_plist" >/dev/null 2>&1 || true
        rm -f "$HARNESS_DIR/run/autopilot.lock"
        ok "autopilot stopped"
        ;;
      service-status)
        launchctl print "gui/$(id -u)/${_autopilot_label}" 2>/dev/null | sed -n '1,80p' || true
        [[ -f "$HARNESS_DIR/state/autopilot-state.json" ]] && python3 -m json.tool "$HARNESS_DIR/state/autopilot-state.json" | sed -n '1,120p'
        ;;
      queue)
        _q="$HARNESS_DIR/run/autopilot-queue.jsonl"
        if [[ -f "$_q" ]]; then
          python3 - <<PY
import json, pathlib, time
q = pathlib.Path("$_q")
items = []
for raw in q.read_text(errors="ignore").splitlines():
    try:
        d = json.loads(raw)
    except Exception:
        continue
    if not d.get("done") and not d.get("expired"):
        items.append(d)
print(f"autopilot queue depth: {len(items)}")
print("┌──────────────────────────────────────────────┬──────────────────────┬────────────────────┬──────────┐")
print("│ Sprint                                       │ Target               │ Reason             │ Attempts │")
print("├──────────────────────────────────────────────┼──────────────────────┼────────────────────┼──────────┤")
for d in items[-20:]:
    print(f"│ {d.get('sid','')[:44]:<44} │ {d.get('target','')[:20]:<20} │ {d.get('reason','')[:18]:<18} │ {int(d.get('attempts',0)):>8} │")
if not items:
    print("│ N/A                                          │ N/A                  │ N/A                │        0 │")
print("└──────────────────────────────────────────────┴──────────────────────┴────────────────────┴──────────┘")
PY
        else
          echo "autopilot queue empty"
        fi
        ;;
      help|--help|-h)
        echo "用法: $0 autopilot [status|apply|dispatch|loop|start|stop|service-status|queue]"
        echo "  status   扫描断头 sprint/pane，不修改"
        echo "  apply    写入本地状态/events，安全默认推进"
        echo "  dispatch apply 后向对应 tmux pane 发送接手指令"
        echo "  loop     常驻巡逻：自动发现阻塞并 wake/dispatch"
        echo "  start    用 launchd 启动常驻巡逻器"
        echo "  stop     停止 launchd 巡逻器"
        echo "  queue    查看因 pane lease/assignment/busy 被排队的动作"
        ;;
      *) err "用法: $0 autopilot [status|apply|dispatch|loop|start|stop|service-status|queue]" ; exit 1 ;;
    esac
    ;;
  plan-verdict)
    [[ -z "${2:-}" ]] && { err "用法: solar-harness plan-verdict <sid> approve|reject [reason]"; exit 1; }
    do_plan_verdict "$2" "${3:-}" "${4:-}"
    ;;
  handoff-submit)
    [[ -z "${2:-}" ]] && { err "用法: solar-harness handoff-submit <sid>"; exit 1; }
    do_handoff_submit "$2"
    ;;
  parallel-integrate)
    [[ -z "${2:-}" ]] && { err "用法: solar-harness parallel-integrate <sid> [repo-root]"; exit 1; }
    bash "$HARNESS_DIR/lib/parallel-integrate.sh" "$2" "${3:-}"
    ;;
  eval-verdict)
    [[ -z "${2:-}" ]] && { err "用法: solar-harness eval-verdict <sid> pass|fail [reason]"; exit 1; }
    do_eval_verdict "$2" "${3:-}" "${4:-}"
    ;;
  capsule)
    shift
    case "${1:-}" in
      show)
        [[ -z "${2:-}" ]] && { err "用法: solar-harness capsule show <sid>"; exit 1; }
        do_capsule_show "$2"
        ;;
      *)
        echo "Solar Harness Capsule — State Capsule 查看"
        echo "用法: solar-harness capsule show <sid>"
        ;;
    esac
    ;;
  ledger)
    shift
    case "${1:-}" in
      show)
        [[ -z "${2:-}" ]] && { err "用法: solar-harness ledger show <sid>"; exit 1; }
        do_ledger_show "$2"
        ;;
      *)
        echo "Solar Harness Ledger — Bridge Ledger 查看"
        echo "用法: solar-harness ledger show <sid>"
        ;;
    esac
    ;;
  verify-events)
    [[ -z "${2:-}" ]] && { err "用法: solar-harness verify-events <sid>"; exit 1; }
    do_verify_events "$2"
    ;;
  stats)
    shift
    case "${1:-}" in
      "")        do_stats_overview ;;
      topology)  do_stats_topology "${2:-}" ;;
      sprint)    do_stats_sprint "${2:-}" ;;
      *)         echo "用法: solar-harness stats [topology <name>|sprint <sid>]" ;;
    esac
    ;;
  migrate)
    # Sprint 20260422-162434: 一键跨机迁移 + Sprint 20260423-151839 D8
    migrate_subcmd="${2:-help}"
    migrate_script="$HARNESS_DIR/migrate/${migrate_subcmd}.sh"
    if [[ -f "$migrate_script" ]]; then
      bash "$migrate_script" "${@:3}"
    else
      echo "Solar Migrate — 跨机迁移工具"
      echo ""
      echo "用法:"
      echo "  $0 migrate export [--out <path>] [--include-secrets] [--password <pw>] [--push <host:path>] [--cleanup-local]"
      echo "  $0 migrate import <bundle|ssh://host/path> [--password <pw>] [--dry-run] [--install-deps]"
      echo "                   [--skip-diff-backup] [--skip-full-backup] [--keep-local]"
      echo "  $0 migrate verify <bundle> [--password <pw>]"
      echo "  $0 migrate rollback [--diff|--full] [--confirm] [--backup-dir <path>] [--remote <user@host>]"
      echo "  $0 migrate deploy <user@host> [--force]"
      echo "  $0 migrate bootstrap <user@host>"
      echo ""
      echo "子命令: export, import, verify, rollback, deploy, bootstrap"
      exit 1
    fi
    ;;
  deploy)
    # Sprint 20260423-151839 D8: 一键部署
    DEPLOY_TARGET="${2:-}"
    DEPLOY_FORCE="${3:-}"
    [[ -z "$DEPLOY_TARGET" ]] && { err "用法: $0 deploy <user@host> [--force]"; exit 1; }

    SSH_OPTS="-o BatchMode=yes -o StrictHostKeyChecking=accept-new"
    BUNDLE_OUT="/tmp/solar-deploy-$$"
    LATEST_REMOTE="\$HOME/solar-bundles/latest.tar"

    echo ""
    echo "══════════════════════════════════════════════════"
    echo "  Solar Deploy — 一键部署"
    echo "══════════════════════════════════════════════════"
    echo ""

    # Step 1: Check remote doesn't already have ~/.solar (unless --force)
    HAS_SOLAR=$(ssh $SSH_OPTS "$DEPLOY_TARGET" "test -d ~/.solar && echo yes || echo no" 2>/dev/null || echo "error")
    if [[ "$HAS_SOLAR" == "yes" && "$DEPLOY_FORCE" != "--force" ]]; then
      err "目标机已有 ~/.solar, 使用 --force 覆盖"
      exit 1
    fi

    # Step 2: Export + push
    ok "Step 1/4: Export + Push..."
    mkdir -p "$BUNDLE_OUT"
    bash "$HARNESS_DIR/migrate/export.sh" --out "$BUNDLE_OUT" "${@:4}" 2>&1
    DEPLOY_TAR=$(ls -t "$BUNDLE_OUT"/solar-bundle-*.tar 2>/dev/null | head -1)
    if [[ -z "$DEPLOY_TAR" ]]; then
      err "Export 失败: 未找到 bundle"
      rm -rf "$BUNDLE_OUT"
      exit 1
    fi

    # Push to remote
    ok "Step 2/4: Push bundle..."
    ssh $SSH_OPTS "$DEPLOY_TARGET" "mkdir -p ~/solar-bundles" 2>/dev/null
    if command -v rsync &>/dev/null; then
      rsync --partial --append --progress "$DEPLOY_TAR" "${DEPLOY_TARGET}:${LATEST_REMOTE}" 2>&1
      rsync --partial --append --progress "${DEPLOY_TAR}.sha256" "${DEPLOY_TARGET}:${LATEST_REMOTE}.sha256" 2>&1
    else
      scp $SSH_OPTS "$DEPLOY_TAR" "${DEPLOY_TARGET}:${LATEST_REMOTE}" 2>/dev/null
      scp $SSH_OPTS "${DEPLOY_TAR}.sha256" "${DEPLOY_TARGET}:${LATEST_REMOTE}.sha256" 2>/dev/null
    fi
    rm -rf "$BUNDLE_OUT"

    # Step 3: Remote import
    ok "Step 3/4: Remote import..."
    IMPORT_EXIT=0
    set +e
    ssh $SSH_OPTS "$DEPLOY_TARGET" "bash -lc 'solar-harness migrate import ~/solar-bundles/latest.tar'" 2>&1
    IMPORT_EXIT=$?
    set -e

    if [[ $IMPORT_EXIT -ne 0 ]]; then
      err "远程 import 失败 (exit=$IMPORT_EXIT)"
      exit 1
    fi

    # Step 4: Remote doctor
    ok "Step 4/4: Remote doctor..."
    DOCTOR_EXIT=0
    set +e
    ssh $SSH_OPTS "$DEPLOY_TARGET" "bash -lc 'solar-harness doctor'" 2>&1
    DOCTOR_EXIT=$?
    set -e

    if [[ $DOCTOR_EXIT -ne 0 ]]; then
      warn "远程 doctor 检查失败, 自动 rollback --diff..."
      ssh $SSH_OPTS "$DEPLOY_TARGET" "bash -lc 'solar-harness migrate rollback --diff --confirm'" 2>&1 || true
      err "部署失败: doctor 检查未通过, 已自动回滚"
      exit 1
    fi

    echo ""
    echo "──────────────────────────────────────────────────"
    ok "一键部署完成: $DEPLOY_TARGET"
    echo "──────────────────────────────────────────────────"
    echo ""
    ;;
  reload)
    # Sprint 20260423-062851 D3: 热加载 coordinator (kill + watchdog 拉新)
    if ! tmux has-session -t solar-harness 2>/dev/null; then
      err "tmux session solar-harness 不存在, 无法 reload"
      exit 1
    fi
    coord_pidfile="$HARNESS_DIR/.coordinator.pid"
    old_pid=""
    [[ -f "$coord_pidfile" ]] && old_pid=$(cat "$coord_pidfile" 2>/dev/null)
    if [[ -z "$old_pid" ]] || ! kill -0 "$old_pid" 2>/dev/null; then
      err "Coordinator 未运行 (PID=${old_pid:-empty})"
      exit 1
    fi
    old_md5=""
    old_md5=$(md5 -q "$HARNESS_DIR/coordinator.sh" 2>/dev/null || echo 'unknown')
    ok "旧 Coordinator: PID=${old_pid}, md5=${old_md5}"
    kill -TERM "$old_pid" 2>/dev/null || true
    ok "已发送 SIGTERM, 等待 watchdog 拉起新实例..."
    waited=0
    new_pid=""
    while (( waited < 40 )); do
      sleep 1
      waited=$((waited + 1))
      [[ -f "$coord_pidfile" ]] && new_pid=$(cat "$coord_pidfile" 2>/dev/null)
      if [[ -n "$new_pid" ]] && kill -0 "$new_pid" 2>/dev/null && [[ "$new_pid" != "$old_pid" ]]; then
        break
      fi
      # exec 热加载 PID 不变, 但进程是新的 — 检查 md5 log
      if [[ "$new_pid" == "$old_pid" ]] && [[ -f "$HARNESS_DIR/.coordinator.log" ]]; then
        if tail -20 "$HARNESS_DIR/.coordinator.log" 2>/dev/null | grep -q "hot-reload\|coordinator.sh md5="; then
          break
        fi
      fi
    done
    if [[ -z "$new_pid" ]] || ! kill -0 "$new_pid" 2>/dev/null; then
      err "Watchdog 未能拉起新 coordinator (${waited}s), 请手动: bash $HARNESS_DIR/coordinator-watchdog.sh start"
      exit 1
    fi
    new_md5=""
    new_md5=$(md5 -q "$HARNESS_DIR/coordinator.sh" 2>/dev/null || echo 'unknown')
    ok "新 Coordinator: PID=${new_pid}, md5=${new_md5}"
    ;;
  update-contract)
    do_update_contract "$@"
    ;;
  context)
    shift
    _context_subcmd="${1:-inject}"; shift || true
    _context_py="$HARNESS_DIR/lib/solar-unified-context.py"
    if [[ ! -f "$_context_py" ]]; then
      err "solar-unified-context.py not found: $_context_py"
      exit 1
    fi
    case "$_context_subcmd" in
      inject)
        _query=""
        _format="hook"
        _args=()
        while [[ $# -gt 0 ]]; do
          case "$1" in
            --query|-q)
              [[ -z "${2:-}" ]] && { err "--query requires text"; exit 1; }
              _query="$2"; shift 2 ;;
            --format)
              [[ -z "${2:-}" ]] && { err "--format requires hook|markdown"; exit 1; }
              _format="$2"; shift 2 ;;
            --json|--max-hits|--max-chars|--timeout-ms|--fail-open)
              _args+=("$1")
              if [[ "$1" != "--json" && "$1" != "--fail-open" ]]; then
                [[ -z "${2:-}" ]] && { err "$1 requires value"; exit 1; }
                _args+=("$2"); shift 2
              else
                shift
              fi ;;
            *)
              if [[ -z "$_query" ]]; then _query="$1"; else _args+=("$1"); fi
              shift ;;
          esac
        done
        [[ -n "$_query" ]] || { err "Usage: $0 context inject --query \"<text>\" [--format hook|markdown|--json]"; exit 1; }
        python3 "$_context_py" --query "$_query" --format "$_format" --fail-open ${_args[@]+"${_args[@]}"}
        ;;
      status)
        python3 "$_context_py" --query "Solar Harness Obsidian QMD Mirage" --json --max-hits 3 --fail-open
        ;;
      *)
        err "Usage: $0 context [inject|status] --query \"<text>\""
        exit 1
        ;;
    esac
    ;;
  help|--help|-h)
    echo "Solar Harness — 多化身协同环境"
    echo ""
    echo "用法:"
    echo "  $0 [start] [工作目录] [--skip-doctor]  启动3化身"
    echo "  $0 2 [工作目录]        启动2化身"
    echo "  $0 status              查看状态"
    echo "  $0 main-status         查看主屏 runtime + assignment + artifact 状态"
    echo "  $0 lab-status          查看 lab pane runtime + handoff artifact 状态"
    echo "  $0 doctor              环境自检"
    echo "  $0 kill                关闭"
    echo "  $0 扩展 | extend       启动独立第二四分屏 (solar-harness-lab)"
    echo "  $0 sprint \"需求\"       创建 Sprint"
    echo "  $0 wake [sprint-id]  列出未完成 Sprint 或恢复指定 Sprint"
    echo "  $0 wake --help       显示 wake 帮助"
    echo "  $0 reload              热加载 coordinator (kill + watchdog 拉新)"
    echo "  $0 update-contract <id> <section> <content>  更新合约"
    echo "  $0 migrate <export|import|verify|rollback|deploy|bootstrap>  跨机迁移"
    echo "  $0 deploy <user@host> [--force]  一键部署"
    echo "  $0 plan-verdict <sid> approve|reject [reason]  原子审批计划"
    echo "  $0 parallel-integrate <sid> [repo-root]  集成并行 builder worktree"
    echo "  $0 eval-verdict <sid> pass|fail [reason]  原子评审判定"
    echo "  $0 verify-events <sid>  事件一致性校验"
    echo "  $0 capsule show <sid>   查看 State Capsule 摘要"
    echo "  $0 ledger show <sid>    查看 Bridge Ledger 事件流"
    echo "  $0 attach              重新接入 tmux"
    echo "  $0 monitor             在独立窗口打开 monitor (回退)"
    echo "  $0 webhook [start|stop|status]  管理 Webhook server"
    echo "  $0 status-server [start|stop|restart|status]  管理 HTTP 状态面板 (port 8765)"
    echo "  $0 mermaid [--open] [file.mmd]  打开 Mermaid .mmd 架构图浏览器"
    echo "  $0 integrations status [--json]  外部开源集成六态健康检查"
    echo "  $0 everything-claude-code [doctor|inventory|report|install --dry-run]  Everything Claude Code 候选集成审计"
    echo "  $0 context inject --query \"问题\" [--format hook|markdown|--json]  默认知识上下文注入"
    echo "  $0 autopilot [status|apply|dispatch|loop|start|stop|service-status|queue]  自动监控断头 sprint/pane 并安全推进"
    echo "  $0 symphony [status|dry-run|workspace <sid>]  Symphony 调度"
    echo "  $0 graph-scheduler [validate|ready|batches|assign|enqueue-ready|mark|parent-check]  DAG 并行调度"
    echo "  $0 graph-dispatch [dispatch-ready|drain-queue]  DAG 节点级 pane 派发"
    echo "  $0 mirage [search|doctor|workspace|mounts|exec|provision]  Mirage 统一虚拟文件系统"
    echo "  $0 wiki [install|status|export-sprint|update|query|ingest|chatgpt-import|vault-status|lint|rebuild|export-graph|colorize|history|run-dispatch|dispatch-watch|dispatch-maintenance|import-solar-db|capture-server|audit-uploads|backfill-uploads|quality-gate|reingest-quarantine|reingest-scheduler|qmd-status|qmd-repair|qmd-search|qmd-update|qmd-mcp|qmd-embed|help]  Obsidian Wiki 集成"
    ;;
  mirage)
    # Mirage unified virtual filesystem — sprint-20260508-mirage-unified-vfs
    shift
    _mirage_wrapper="$HARNESS_DIR/lib/solar_mirage.py"
    if [[ ! -f "$_mirage_wrapper" ]]; then
      err "Mirage wrapper not found: $_mirage_wrapper"
      exit 1
    fi
    python3 "$_mirage_wrapper" "$@"
    ;;
  wiki)
    # Obsidian Wiki integration — sprint-20260507-obsidian-wiki
    shift
    _wiki_subcmd="${1:-help}"; shift || true
    _wiki_installer="$HARNESS_DIR/integrations/obsidian-wiki.sh"
    _wiki_exporter="$HARNESS_DIR/integrations/obsidian-wiki-export.sh"
    _wiki_bridge="$HARNESS_DIR/integrations/obsidian-wiki-bridge.sh"
    case "$_wiki_subcmd" in
      install)
        if [[ -f "$_wiki_installer" ]]; then
          # shellcheck disable=SC1090
          source "$_wiki_installer"
          cmd_wiki_install "$@"
        else
          err "Wiki installer not found: $_wiki_installer"
          err "Integration may not be fully deployed yet."
          exit 1
        fi
        ;;
      status)
        if [[ -f "$_wiki_installer" ]]; then
          # shellcheck disable=SC1090
          source "$_wiki_installer"
          cmd_wiki_status "$@"
        else
          err "Wiki installer not found: $_wiki_installer"
          exit 1
        fi
        ;;
      export-sprint)
        if [[ -f "$_wiki_exporter" ]]; then
          # shellcheck disable=SC1090
          source "$_wiki_exporter"
          cmd_wiki_export_sprint "$@"
        elif [[ -f "$_wiki_installer" ]]; then
          # fallback: export may be embedded in installer
          source "$_wiki_installer"
          cmd_wiki_export_sprint "$@"
        else
          err "Wiki export module not found: $_wiki_exporter"
          exit 1
        fi
        ;;
      update)
        if [[ -f "$_wiki_bridge" ]]; then
          # shellcheck disable=SC1090
          source "$_wiki_bridge"
          cmd_wiki_update "$@"
        else
          err "Wiki bridge not found: $_wiki_bridge"
          exit 1
        fi
        ;;
      query)
        if [[ -f "$_wiki_bridge" ]]; then
          # shellcheck disable=SC1090
          source "$_wiki_bridge"
          cmd_wiki_query "$@"
        else
          err "Wiki bridge not found: $_wiki_bridge"
          exit 1
        fi
        ;;
      ingest)
        if [[ -f "$_wiki_bridge" ]]; then
          # shellcheck disable=SC1090
          source "$_wiki_bridge"
          cmd_wiki_ingest "$@"
        else
          err "Wiki bridge not found: $_wiki_bridge"
          exit 1
        fi
        ;;
      chatgpt-import|import-chatgpt)
        _chatgpt_importer="${HARNESS_DIR}/lib/chatgpt-conversation-ingest.py"
        if [[ ! -f "$_chatgpt_importer" ]]; then
          err "ChatGPT importer not found: $_chatgpt_importer"
          exit 1
        fi
        python3 "$_chatgpt_importer" "$@"
        ;;
      vault-status)
        if [[ -f "$_wiki_bridge" ]]; then
          # shellcheck disable=SC1090
          source "$_wiki_bridge"
          cmd_wiki_vault_status "$@"
        else
          err "Wiki bridge not found: $_wiki_bridge"
          exit 1
        fi
        ;;
      lint)
        if [[ -f "$_wiki_bridge" ]]; then
          # shellcheck disable=SC1090
          source "$_wiki_bridge"
          cmd_wiki_lint "$@"
        else
          err "Wiki bridge not found: $_wiki_bridge"
          exit 1
        fi
        ;;
      rebuild)
        if [[ -f "$_wiki_bridge" ]]; then
          # shellcheck disable=SC1090
          source "$_wiki_bridge"
          cmd_wiki_rebuild "$@"
        else
          err "Wiki bridge not found: $_wiki_bridge"
          exit 1
        fi
        ;;
      export-graph)
        if [[ -f "$_wiki_bridge" ]]; then
          # shellcheck disable=SC1090
          source "$_wiki_bridge"
          cmd_wiki_export_graph "$@"
        else
          err "Wiki bridge not found: $_wiki_bridge"
          exit 1
        fi
        ;;
      colorize)
        if [[ -f "$_wiki_bridge" ]]; then
          # shellcheck disable=SC1090
          source "$_wiki_bridge"
          cmd_wiki_colorize "$@"
        else
          err "Wiki bridge not found: $_wiki_bridge"
          exit 1
        fi
        ;;
      history)
        if [[ -f "$_wiki_bridge" ]]; then
          # shellcheck disable=SC1090
          source "$_wiki_bridge"
          cmd_wiki_history "$@"
        else
          err "Wiki bridge not found: $_wiki_bridge"
          exit 1
        fi
        ;;
      run-dispatch)
        if [[ -f "$_wiki_bridge" ]]; then
          # shellcheck disable=SC1090
          source "$_wiki_bridge"
          cmd_wiki_run_dispatch "$@"
        else
          err "Wiki bridge not found: $_wiki_bridge"
          exit 1
        fi
        ;;
      dispatch-watch)
        if [[ -f "$_wiki_bridge" ]]; then
          # shellcheck disable=SC1090
          source "$_wiki_bridge"
          cmd_wiki_dispatch_watch "$@"
        else
          err "Wiki bridge not found: $_wiki_bridge"
          exit 1
        fi
        ;;
      dispatch-maintenance|dispatch-doctor)
        _dispatch_maint="${HARNESS_DIR}/lib/wiki-dispatch-maintenance.py"
        if [[ ! -f "$_dispatch_maint" ]]; then
          err "wiki dispatch maintenance not found: $_dispatch_maint"
          exit 1
        fi
        python3 "$_dispatch_maint" "$@"
        ;;
      import-solar-db)
        if [[ -f "$_wiki_bridge" ]]; then
          # shellcheck disable=SC1090
          source "$_wiki_bridge"
          cmd_wiki_import_solar_db "$@"
        else
          err "Wiki bridge not found: $_wiki_bridge"
          exit 1
        fi
        ;;
      capture-server)
        if [[ -f "$_wiki_bridge" ]]; then
          # shellcheck disable=SC1090
          source "$_wiki_bridge"
          cmd_wiki_capture_server "$@"
        else
          err "Wiki bridge not found: $_wiki_bridge"
          exit 1
        fi
        ;;
      sync-vault)
        # S2.5: Index /Users/sihaoli/Knowledge (or --vault PATH) into Solar DB
        local _indexer="${HARNESS_DIR}/lib/obsidian-vault-indexer.py"
        local _sv_vault="${OBSIDIAN_VAULT_PATH:-$HOME/Knowledge}"
        local _sv_args=()
        while [[ $# -gt 0 ]]; do
          case "$1" in
            --vault) [[ -z "${2:-}" ]] && { err "--vault requires a path"; exit 1; }
                     _sv_vault="$2"; shift 2 ;;
            --once|--dry-run|--json) _sv_args+=("$1"); shift ;;
            --max-files) _sv_args+=("$1" "${2:?}"); shift 2 ;;
            *) err "unknown sync-vault arg: $1"; exit 1 ;;
          esac
        done
        if [[ ! -f "$_indexer" ]]; then
          err "obsidian-vault-indexer not found: $_indexer"
          exit 1
        fi
        python3 "$_indexer" --vault "$_sv_vault" --once "${_sv_args[@]}"
        ;;
      audit-uploads)
        # B3: Audit a file-upload batch for vault/qmd/DB coverage
        _auditor="${HARNESS_DIR}/lib/wiki-upload-audit.py"
        if [[ ! -f "$_auditor" ]]; then
          err "wiki-upload-audit not found: $_auditor"
          exit 1
        fi
        python3 "$_auditor" "$@"
        ;;
      backfill-uploads)
        # B3: Backfill qmd/vault/DB for a file-upload batch
        _backfill="${HARNESS_DIR}/lib/wiki-upload-backfill.py"
        if [[ ! -f "$_backfill" ]]; then
          err "wiki-upload-backfill not found: $_backfill"
          exit 1
        fi
        if python3 "$_backfill" "$@"; then
          if printf ' %s ' "$*" | grep -q ' --repair '; then
            _quality_gate="${HARNESS_DIR}/lib/wiki-quality-gate.py"
            if [[ -f "$_quality_gate" ]]; then
              warn "running post-backfill quality gate; low-quality stubs will be quarantined"
              python3 "$_quality_gate" --apply --json
            fi
          fi
        else
          exit $?
        fi
        ;;
      quality-gate)
        # Quarantine low-quality PDF/stub pages before they pollute default KB retrieval.
        _quality_gate="${HARNESS_DIR}/lib/wiki-quality-gate.py"
        if [[ ! -f "$_quality_gate" ]]; then
          err "wiki-quality-gate not found: $_quality_gate"
          exit 1
        fi
        python3 "$_quality_gate" "$@"
        ;;
      reingest-quarantine)
        # Create deep paper reingest dispatches for quarantined PDF/stub pages.
        _reingest_quarantine="${HARNESS_DIR}/lib/wiki-reingest-quarantine.py"
        if [[ ! -f "$_reingest_quarantine" ]]; then
          err "wiki-reingest-quarantine not found: $_reingest_quarantine"
          exit 1
        fi
        python3 "$_reingest_quarantine" "$@"
        ;;
      reingest-scheduler)
        _reingest_scheduler="${HARNESS_DIR}/lib/wiki-reingest-scheduler.sh"
        _reingest_session="${SOLAR_REINGEST_SESSION_NAME:-solar-wiki-reingest-scheduler}"
        if [[ ! -x "$_reingest_scheduler" ]]; then
          err "wiki-reingest-scheduler not executable: $_reingest_scheduler"
          exit 1
        fi
        case "${1:-status}" in
          start)
            _interval="${2:-60}"
            if tmux has-session -t "$_reingest_session" 2>/dev/null; then
              ok "wiki reingest scheduler already running ($_reingest_session)"
            else
              tmux new-session -d -s "$_reingest_session" "$_reingest_scheduler loop '$_interval'"
              ok "wiki reingest scheduler started ($_reingest_session, interval=${_interval}s)"
            fi
            ;;
          stop)
            tmux kill-session -t "$_reingest_session" 2>/dev/null || true
            ok "wiki reingest scheduler stopped ($_reingest_session)"
            ;;
          run-once)
            "$_reingest_scheduler" run-once
            ;;
          status)
            if tmux has-session -t "$_reingest_session" 2>/dev/null; then
              ok "wiki reingest scheduler running ($_reingest_session)"
            else
              warn "wiki reingest scheduler not running ($_reingest_session)"
            fi
            "$_reingest_scheduler" status
            ;;
          *)
            err "Usage: $0 wiki reingest-scheduler [start [interval]|stop|status|run-once]"
            exit 1
            ;;
        esac
        ;;
      qmd-repair|mineru-repair)
        _qmd_repair="${HARNESS_DIR}/lib/qmd-launcher-repair.sh"
        [[ -x "$_qmd_repair" ]] || { err "qmd launcher repair not found: $_qmd_repair"; exit 1; }
        "$_qmd_repair" "$@"
        ;;
      qmd-status|mineru-status)
        _QMD_BIN="$(command -v qmd 2>/dev/null || true)"
        [[ -z "$_QMD_BIN" && -x "$HOME/.npm-global/bin/qmd" ]] && _QMD_BIN="$HOME/.npm-global/bin/qmd"
        [[ -n "$_QMD_BIN" ]] || { err "qmd not found; install mineru-document-explorer"; exit 1; }
        _qmd_status_out=""
        _qmd_status_rc=0
        _qmd_repair="${HARNESS_DIR}/lib/qmd-launcher-repair.sh"
        set +e
        _qmd_status_out="$("$_QMD_BIN" status "$@" 2>&1)"
        _qmd_status_rc=$?
        set -e
        if [[ "$_qmd_status_rc" != "0" ]] && printf '%s\n' "$_qmd_status_out" | grep -Eiq 'NODE_MODULE_VERSION|ERR_DLOPEN_FAILED|better-sqlite3' && [[ -x "$_qmd_repair" ]]; then
          warn "qmd native-module ABI error detected; attempting launcher repair"
          "$_qmd_repair" --apply >&2 || true
          set +e
          _qmd_status_out="$("$_QMD_BIN" status "$@" 2>&1)"
          _qmd_status_rc=$?
          set -e
        fi
        printf '%s\n' "$_qmd_status_out"
        exit "$_qmd_status_rc"
        ;;
      qmd-search|mineru-search)
        _QMD_BIN="$(command -v qmd 2>/dev/null || true)"
        [[ -z "$_QMD_BIN" && -x "$HOME/.npm-global/bin/qmd" ]] && _QMD_BIN="$HOME/.npm-global/bin/qmd"
        [[ -n "$_QMD_BIN" ]] || { err "qmd not found; install mineru-document-explorer"; exit 1; }
        if [[ $# -lt 1 ]]; then
          err "Usage: $0 wiki qmd-search \"<query>\" [qmd search args]"
          exit 1
        fi
        "$_QMD_BIN" search "$1" -c "${QMD_WIKI_COLLECTION:-solar-wiki}" "${@:2}"
        ;;
      qmd-update|mineru-update)
        _QMD_BIN="$(command -v qmd 2>/dev/null || true)"
        [[ -z "$_QMD_BIN" && -x "$HOME/.npm-global/bin/qmd" ]] && _QMD_BIN="$HOME/.npm-global/bin/qmd"
        [[ -n "$_QMD_BIN" ]] || { err "qmd not found; install mineru-document-explorer"; exit 1; }
        "$_QMD_BIN" update "$@"
        ;;
      qmd-mcp|mineru-mcp)
        _QMD_BIN="$(command -v qmd 2>/dev/null || true)"
        [[ -z "$_QMD_BIN" && -x "$HOME/.npm-global/bin/qmd" ]] && _QMD_BIN="$HOME/.npm-global/bin/qmd"
        [[ -n "$_QMD_BIN" ]] || { err "qmd not found; install mineru-document-explorer"; exit 1; }
        _QMD_PROXY="${HARNESS_DIR}/lib/qmd-ipv4-proxy.py"
        _QMD_PROXY_PID="${HARNESS_DIR}/run/qmd-mcp-ipv4-proxy.pid"
        _QMD_PROXY_SESSION="solar-qmd-mcp-proxy"
        _qmd_mcp_hosts() {
          python3 - <<'PY'
import socket
hosts=["127.0.0.1","::1","localhost"]
open_hosts=[]
for h in hosts:
    try:
        s=socket.create_connection((h,8181),timeout=0.4)
        s.close()
        open_hosts.append(h)
    except OSError:
        pass
print(",".join(open_hosts))
PY
        }
        _qmd_proxy_start() {
          [[ -f "$_QMD_PROXY" ]] || { err "qmd IPv4 proxy missing: $_QMD_PROXY"; return 1; }
          mkdir -p "$HARNESS_DIR/run"
          if tmux has-session -t "$_QMD_PROXY_SESSION" 2>/dev/null; then
            return 0
          fi
          if [[ -f "$_QMD_PROXY_PID" ]]; then
            _proxy_pid="$(cat "$_QMD_PROXY_PID" 2>/dev/null || true)"
            if [[ -n "$_proxy_pid" ]] && kill -0 "$_proxy_pid" 2>/dev/null; then
              return 0
            fi
            rm -f "$_QMD_PROXY_PID"
          fi
          tmux new-session -d -s "$_QMD_PROXY_SESSION" "python3 '$_QMD_PROXY' \
            --listen-host 127.0.0.1 --listen-port 8181 \
            --target-host ::1 --target-port 8181 \
            --pid-file "$_QMD_PROXY_PID" \
            >> '$HARNESS_DIR/run/qmd-mcp-ipv4-proxy.log' 2>&1"
          sleep 0.4
        }
        _qmd_proxy_stop() {
          tmux kill-session -t "$_QMD_PROXY_SESSION" 2>/dev/null || true
          if [[ -f "$_QMD_PROXY_PID" ]]; then
            _proxy_pid="$(cat "$_QMD_PROXY_PID" 2>/dev/null || true)"
            [[ -n "$_proxy_pid" ]] && kill "$_proxy_pid" 2>/dev/null || true
            rm -f "$_QMD_PROXY_PID"
          fi
        }
        case "${1:-status}" in
          status)
            _qmd_mcp_probe="$(_qmd_mcp_hosts)"
            if [[ -n "$_qmd_mcp_probe" ]]; then
              if [[ "$_qmd_mcp_probe" == *"127.0.0.1"* ]]; then
                ok "qmd MCP running → http://127.0.0.1:8181/mcp (hosts: $_qmd_mcp_probe)"
              else
                warn "qmd MCP running, but not on 127.0.0.1 (hosts: $_qmd_mcp_probe). Use localhost/[::1] or restart if a strict IPv4 client requires it."
              fi
              lsof -nP -iTCP:8181 -sTCP:LISTEN | tail -1 || true
            else
              err "qmd MCP not listening on 8181"
              exit 1
            fi
            ;;
          start)
            _qmd_mcp_probe="$(_qmd_mcp_hosts)"
            if [[ -z "$_qmd_mcp_probe" ]]; then
              "$_QMD_BIN" mcp --http --daemon
              sleep 1
              _qmd_mcp_probe="$(_qmd_mcp_hosts)"
            fi
            if [[ "$_qmd_mcp_probe" == *"127.0.0.1"* ]]; then
              ok "qmd MCP already reachable on 127.0.0.1:8181"
              exit 0
            fi
            if [[ "$_qmd_mcp_probe" == *"::1"* || "$_qmd_mcp_probe" == *"localhost"* ]]; then
              _qmd_proxy_start
              _qmd_mcp_probe="$(_qmd_mcp_hosts)"
              if [[ "$_qmd_mcp_probe" == *"127.0.0.1"* ]]; then
                ok "qmd MCP IPv4 proxy running → 127.0.0.1:8181 -> ::1:8181"
                exit 0
              fi
            fi
            err "qmd MCP failed to become reachable on 127.0.0.1:8181"
            exit 1
            ;;
          stop-proxy)
            _qmd_proxy_stop
            ok "qmd MCP IPv4 proxy stopped"
            ;;
          *)
            err "Usage: $0 wiki qmd-mcp [status|start|stop-proxy]"
            exit 1
            ;;
        esac
        ;;
      qmd-embed|mineru-embed)
        _embed_runner="${HARNESS_DIR}/lib/qmd-embed-runner.sh"
        _embed_plist="$HOME/Library/LaunchAgents/com.solar.qmd-mineru-embed.plist"
        _embed_status="${HARNESS_DIR}/state/qmd-embed-status.json"
        _embed_label="com.solar.qmd-mineru-embed"
        case "${1:-status}" in
          start)
            [[ -x "$_embed_runner" ]] || { err "qmd embed runner not executable: $_embed_runner"; exit 1; }
            launchctl bootout "gui/$(id -u)" "$_embed_plist" >/dev/null 2>&1 || true
            launchctl bootstrap "gui/$(id -u)" "$_embed_plist"
            mkdir -p "$(dirname "$_embed_status")"
            cat > "$_embed_status" <<EOF
{
  "state": "scheduled",
  "collection": "solar-wiki",
  "mode": "gentle",
  "updated_at": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')",
  "detail": "launchd loaded; gentle background mode uses low priority, load guard, and time slices",
  "log": "${HARNESS_DIR}/run/qmd-embed.log"
}
EOF
            ok "qmd embedding gentle scheduler loaded ($_embed_label); low priority, load guarded"
            ;;
          run-once)
            [[ -x "$_embed_runner" ]] || { err "qmd embed runner not executable: $_embed_runner"; exit 1; }
            "$_embed_runner"
            ;;
          run-idle)
            [[ -x "$_embed_runner" ]] || { err "qmd embed runner not executable: $_embed_runner"; exit 1; }
            SOLAR_QMD_EMBED_MODE=idle "$_embed_runner"
            ;;
          run-gentle)
            [[ -x "$_embed_runner" ]] || { err "qmd embed runner not executable: $_embed_runner"; exit 1; }
            SOLAR_QMD_EMBED_MODE=gentle "$_embed_runner"
            ;;
          run-now)
            [[ -x "$_embed_runner" ]] || { err "qmd embed runner not executable: $_embed_runner"; exit 1; }
            SOLAR_QMD_EMBED_MODE=force SOLAR_QMD_EMBED_FORCE=1 "$_embed_runner"
            ;;
          stop)
            launchctl bootout "gui/$(id -u)" "$_embed_plist" >/dev/null 2>&1 || true
            pkill -f 'qmd embed -c solar-wiki' >/dev/null 2>&1 || true
            mkdir -p "$(dirname "$_embed_status")"
            cat > "$_embed_status" <<EOF
{
  "state": "stopped",
  "collection": "solar-wiki",
  "mode": "stopped",
  "updated_at": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')",
  "detail": "launchd unloaded and active qmd embed process stopped",
  "log": "${HARNESS_DIR}/run/qmd-embed.log"
}
EOF
            ok "qmd embedding background job stopped ($_embed_label)"
            ;;
          status)
            if launchctl print "gui/$(id -u)/$_embed_label" >/dev/null 2>&1; then
              ok "qmd embedding launchd loaded ($_embed_label)"
            else
              warn "qmd embedding launchd not loaded"
            fi
            if [[ -f "$_embed_status" ]]; then
              cat "$_embed_status"
            else
              warn "no qmd embed status yet: $_embed_status"
            fi
            ;;
          *)
            err "Usage: $0 wiki qmd-embed [start|status|stop|run-once|run-idle|run-gentle|run-now]"
            exit 1
            ;;
        esac
        ;;
      mineru-doctor)
        # sprint-20260509-mineru-mirage-closeout S1: doctor per design §2.1
        _md_py="$HARNESS_DIR/lib/mineru_doctor.py"
        if [[ ! -f "$_md_py" ]]; then err "mineru_doctor.py not found: $_md_py"; exit 1; fi
        python3 "$_md_py" "$@"
        ;;
      export-accepted)
        # sprint-20260508-accepted-artifact-knowledge: export PASS-only sprint artifact
        _aae="$HARNESS_DIR/lib/accepted-artifact-export.py"
        if [[ ! -f "$_aae" ]]; then
          err "accepted-artifact-export.py not found: $_aae"
          exit 1
        fi
        python3 "$_aae" export "$@"
        ;;
      backfill-accepted)
        # sprint-20260508-accepted-artifact-knowledge: backfill passed sprints (default dry-run)
        _aae="$HARNESS_DIR/lib/accepted-artifact-export.py"
        if [[ ! -f "$_aae" ]]; then
          err "accepted-artifact-export.py not found: $_aae"
          exit 1
        fi
        python3 "$_aae" backfill "$@"
        ;;
      help|--help|-h|"")
        echo "Solar Harness Wiki — Obsidian LLM Wiki integration"
        echo ""
        echo "Usage:"
        echo "  $0 wiki install --vault <path> [--repo <path>] [--refresh]"
        echo "  $0 wiki status [--json]"
        echo "  $0 wiki export-sprint <sid> [--redact|--full]"
        echo "  $0 wiki update [--project <path>] [--mode append|full]"
        echo "  $0 wiki query \"<question>\" [--quick]"
        echo "  $0 wiki ingest [--source <path>] [--mode append|full|raw] [--project <name>]"
        echo "  $0 wiki chatgpt-import [--browser-all [auto|chrome|arc|edge|brave|safari]|--browser [auto|chrome|arc|edge|brave|safari]|--source <conversations.json|transcript.md|dir|->|--clipboard] [--no-dispatch] [--limit N]"
        echo "  $0 wiki vault-status [--insights]"
        echo "  $0 wiki lint [--fix]"
        echo "  $0 wiki rebuild [--mode archive-only|archive-rebuild|restore] [--archive <name>]"
        echo "  $0 wiki export-graph [--all|--public]"
        echo "  $0 wiki colorize [--mode by-tag|by-category|by-visibility|combined|custom]"
        echo "  $0 wiki history [--target claude|codex|copilot|hermes|openclaw|auto] [--query <topic>]"
        echo "  $0 wiki run-dispatch <dispatch.md> [--lab-builder 1|2|3|4|--main-builder|--pane <target>] [--dry-run]"
        echo "  $0 wiki dispatch-watch [--once|--loop] [--limit N] [--interval seconds] [--dry-run]"
        echo "  $0 wiki dispatch-maintenance [status|repair --apply] [--json]"
        echo "  $0 wiki import-solar-db [--scope solar|all] [--per-table-limit N] [--no-dispatch]"
        echo "  $0 wiki capture-server [start|stop|restart|status] [--port N] [--open]"
        echo "  $0 wiki sync-vault [--vault PATH] [--once] [--dry-run] [--json]"
        echo "  $0 wiki audit-uploads --batch <batch_id> [--json]"
        echo "  $0 wiki backfill-uploads --batch <batch_id> [--repair] [--json]"
        echo "  $0 wiki quality-gate [--apply] [--json] [--vault PATH]"
        echo "  $0 wiki reingest-quarantine [--manifest PATH] [--limit N] [--json] [--dry-run]"
        echo "  $0 wiki reingest-scheduler [start [interval]|stop|status|run-once]"
        echo "  $0 wiki qmd-status"
        echo "  $0 wiki qmd-repair [--check|--apply] [--json]"
        echo "  $0 wiki qmd-search \"<query>\" [-n N|--json|--files]"
        echo "  $0 wiki qmd-update"
        echo "  $0 wiki qmd-mcp [status|start|stop-proxy]"
        echo "  $0 wiki qmd-embed [start|status|stop|run-once|run-idle|run-gentle|run-now]"
        echo ""
        echo "Examples:"
        echo "  $0 wiki install --vault ~/Documents/SolarWiki"
        echo "  $0 wiki status --json"
        echo "  $0 wiki export-sprint sprint-20260507-symphony3 --redact"
        echo "  $0 wiki update --mode append"
        echo "  $0 wiki query \"What did sprint symphony1 achieve?\""
        echo "  $0 wiki ingest --source ~/Downloads/paper.pdf --mode append"
        echo "  $0 wiki chatgpt-import --browser-all      # preferred: capture all open ChatGPT conversation tabs"
        echo "  $0 wiki chatgpt-import --browser          # preferred: capture active ChatGPT tab"
        echo "  $0 wiki chatgpt-import --source ~/Downloads/conversations.json --limit 50"
        echo "  pbpaste | $0 wiki chatgpt-import --source -"
        echo "  $0 wiki history --target codex --query \"rust ownership\""
        echo "  $0 wiki colorize --mode by-category"
        echo "  $0 wiki run-dispatch \"\$OBSIDIAN_VAULT_PATH/_raw/solar-harness/.dispatch/wiki-ingest-<ts>.md\" --lab-builder 1"
        echo "  $0 wiki dispatch-watch --once --limit 4"
        echo "  $0 wiki import-solar-db --scope solar --per-table-limit 25"
        echo "  $0 wiki capture-server start --open"
        echo "  $0 wiki qmd-search \"Solar Harness Obsidian\" -n 5 --json"
        echo "  $0 wiki audit-uploads --batch 20260508T122047Z --json"
        echo "  $0 wiki backfill-uploads --batch 20260508T122047Z --repair --json"
        echo "  $0 wiki quality-gate --apply --json"
        echo "  $0 wiki reingest-quarantine --limit 8 --json"
        echo "  $0 wiki reingest-scheduler start 60"
        ;;
      *)
        err "Unknown wiki subcommand: $_wiki_subcmd"
        echo "Run '$0 wiki help' for usage." >&2
        exit 1
        ;;
    esac
    ;;
  symphony)
    shift
    case "${1:-status}" in
      status)
        python3 "$HARNESS_DIR/lib/symphony/scheduler.py" --status
        ;;
      dry-run)
        python3 "$HARNESS_DIR/lib/symphony/scheduler.py" --dry-run
        ;;
      workspace)
        shift
        [[ -z "${1:-}" ]] && { err "Usage: $0 symphony workspace <sprint-id>"; exit 1; }
        bash "$HARNESS_DIR/lib/symphony/workspace-manager.sh" show "$1"
        ;;
      *)
        echo "Usage: $0 symphony [status|dry-run|workspace <sid>]" >&2
        exit 1
        ;;
    esac
    ;;
  product)
    # S0 snapshot/restore/verify — sprint-20260509-solar-product-platform
    shift
    _prod_py="$HARNESS_DIR/lib/product_snapshot.py"
    if [[ ! -f "$_prod_py" ]]; then
      err "product_snapshot.py not found: $_prod_py"; exit 1
    fi
    _prod_subcmd="${1:-help}"; shift || true
    case "$_prod_subcmd" in
      snapshot)
        python3 "$_prod_py" snapshot "$@"
        ;;
      verify)
        python3 "$_prod_py" verify "$@"
        ;;
      restore)
        python3 "$_prod_py" restore "$@"
        ;;
      list)
        python3 "$_prod_py" list "$@"
        ;;
      help|--help|-h|"")
        echo "Solar Product Snapshot — S0 foundation"
        echo ""
        echo "Usage:"
        echo "  $0 product snapshot [--dry-run] [--scope minimal|full] [--out-dir DIR]"
        echo "  $0 product verify   (--latest | --id SNAP_ID) [--out-dir DIR]"
        echo "  $0 product restore  (--latest | --id SNAP_ID) [--dry-run] [--target-dir DIR]"
        echo "  $0 product list     [--out-dir DIR]"
        ;;
      *)
        err "Unknown product subcommand: $_prod_subcmd"; exit 1
        ;;
    esac
    ;;
  s6-autopilot)
    # S6 Control Plane — autopilot.py (three-state deadlock detection)
    shift
    _ap_py="$HARNESS_DIR/lib/autopilot.py"
    if [[ ! -f "$_ap_py" ]]; then
      err "autopilot.py not found: $_ap_py"; exit 1
    fi
    _ap_subcmd="${1:-status}"; shift || true
    case "$_ap_subcmd" in
      scan|status|fault-report|resolve-deadlock|drain-queue)
        python3 "$_ap_py" "$_ap_subcmd" "$@"
        ;;
      help|--help|-h|"")
        echo "Solar S6 Autopilot — three-state deadlock detection"
        echo ""
        echo "Usage:"
        echo "  $0 s6-autopilot scan            [--sprint SID]"
        echo "  $0 s6-autopilot status          [--sprint SID]"
        echo "  $0 s6-autopilot fault-report    [--sprint SID]"
        echo "  $0 s6-autopilot drain-queue     --sprint SID"
        echo "  $0 s6-autopilot resolve-deadlock --pane P --sprint SID --dispatch-id DID"
        ;;
      *)
        err "Unknown s6-autopilot subcommand: $_ap_subcmd"; exit 1
        ;;
    esac
    ;;

  graph-scheduler)
    # Machine-executable sprint DAG scheduler
    shift
    _graph_py="$HARNESS_DIR/lib/graph_scheduler.py"
    if [[ ! -f "$_graph_py" ]]; then
      err "graph_scheduler.py not found: $_graph_py"; exit 1
    fi
    _graph_subcmd="${1:-help}"; shift || true
    case "$_graph_subcmd" in
      validate|topo|layers|critical-path|ready|batches|assign|mark|parent-check|enqueue-ready)
        python3 "$_graph_py" "$_graph_subcmd" "$@"
        ;;
      help|--help|-h|"")
        echo "Solar Graph Scheduler — DAG planning and parallel dispatch"
        echo ""
        echo "Usage:"
        echo "  $0 graph-scheduler validate       --graph sprint.task_graph.json"
        echo "  $0 graph-scheduler topo           --graph sprint.task_graph.json"
        echo "  $0 graph-scheduler layers         --graph sprint.task_graph.json"
        echo "  $0 graph-scheduler critical-path  --graph sprint.task_graph.json"
        echo "  $0 graph-scheduler ready          --graph sprint.task_graph.json"
        echo "  $0 graph-scheduler batches        --graph sprint.task_graph.json [--max-parallel N] [--out dispatch_batches.json]"
        echo "  $0 graph-scheduler assign         --graph sprint.task_graph.json --workers workers.json [--max-parallel N]"
        echo "  $0 graph-scheduler enqueue-ready  --graph sprint.task_graph.json --workers workers.json [--lease] [--in-place]"
        echo "  $0 graph-scheduler mark           --graph sprint.task_graph.json --node S1 --status passed [--in-place]"
        echo "  $0 graph-scheduler parent-check   --graph sprint.task_graph.json"
        ;;
      *)
        err "Unknown graph-scheduler subcommand: $_graph_subcmd"; exit 1
        ;;
    esac
    ;;

  graph-dispatch)
    # DAG graph_node payload dispatcher
    shift
    _graph_dispatch_py="$HARNESS_DIR/lib/graph_node_dispatcher.py"
    if [[ ! -f "$_graph_dispatch_py" ]]; then
      err "graph_node_dispatcher.py not found: $_graph_dispatch_py"; exit 1
    fi
    _graph_dispatch_subcmd="${1:-help}"; shift || true
    case "$_graph_dispatch_subcmd" in
      dispatch-ready|drain-queue|dispatch-evals|node-verdict)
        python3 "$_graph_dispatch_py" "$_graph_dispatch_subcmd" "$@"
        ;;
      help|--help|-h|"")
        echo "Solar Graph Dispatch — DAG node payload to pane dispatch"
        echo ""
        echo "Usage:"
        echo "  $0 graph-dispatch dispatch-ready --graph sprint.task_graph.json [--dry-run]"
        echo "  $0 graph-dispatch dispatch-evals --graph sprint.task_graph.json [--dry-run]"
        echo "  $0 graph-dispatch node-verdict --graph sprint.task_graph.json --node S1 --verdict pass|fail"
        echo "  $0 graph-dispatch drain-queue    --sprint SID [--dry-run] [--max-items N]"
        ;;
      *)
        err "Unknown graph-dispatch subcommand: $_graph_dispatch_subcmd"; exit 1
        ;;
    esac
    ;;

  leases)
    # S6 Control Plane — pane_lease.py
    shift
    _lease_py="$HARNESS_DIR/lib/pane_lease.py"
    if [[ ! -f "$_lease_py" ]]; then
      err "pane_lease.py not found: $_lease_py"; exit 1
    fi
    _lease_subcmd="${1:-list}"; shift || true
    case "$_lease_subcmd" in
      check|state|acquire|release|reap|list)
        python3 "$_lease_py" "$_lease_subcmd" "$@"
        ;;
      help|--help|-h|"")
        echo "Solar Pane Leases — S6 Control Plane"
        echo ""
        echo "Usage:"
        echo "  $0 leases list"
        echo "  $0 leases state  --pane PANE"
        echo "  $0 leases check  --pane PANE"
        echo "  $0 leases acquire --pane P --sprint SID --dispatch-id DID [--ttl N]"
        echo "  $0 leases release --pane P --dispatch-id DID [--reason R]"
        echo "  $0 leases reap"
        ;;
      *)
        err "Unknown leases subcommand: $_lease_subcmd"; exit 1
        ;;
    esac
    ;;

  *)
    # If arg looks like a directory, use it as work dir
    if [[ -d "$1" ]]; then
      start_harness 3 "$1"
    else
      err "未知命令: $1"; log "运行 '$0 help'"; exit 1
    fi
    ;;
esac
