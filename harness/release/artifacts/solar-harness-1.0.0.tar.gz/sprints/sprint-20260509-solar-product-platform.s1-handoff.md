# S1 Handoff — sprint-20260509-solar-product-platform
Builder: 建设者化身 (S1 — Installer + Container Validation)
Role: builder
Round: 1

## Summary

S1 builds the product distribution foundation: portable installer scripts, upgrade/restore tooling, secret scanning infrastructure, Docker container validation, and git hooks. All artifacts are self-contained with fake/test keys, no live user paths, and no plaintext secrets.

## Changed Files

- `installer/install.sh` (NEW): OS-aware install script — macOS (brew) + Linux (apt/yum), --non-interactive mode, fake key support, --skip-llm-cli, state DB init, snapshot baseline, config/doctor/git-hook setup
- `installer/upgrade.sh` (NEW): Safe upgrade — pre-snapshot, protected path preservation (.env, user config), --dry-run mode, post-upgrade doctor
- `installer/doctor.sh` (NEW): Design §2.2 JSON schema — ts, os (kind+version), bins (11 checks), paths (11 checks), services (harness/qmd-mcp/status-server/mineru/state_db), secrets (configured/missing, NEVER real values), skills (builtins_count, registry_drift), verdict=ok|degraded|fail
- `installer/restore.sh` (NEW): Snapshot restore wrapper — --list, --latest, --dry-run (default), --apply (with confirm), manifest inspection
- `config/defaults.yaml` (NEW): Product defaults — providers (anthropic/openai/google/zai), vault, storage, mirage, skills, mineru, qmd, control_plane, secret_scan. No real secrets.
- `.env.example` (NEW): Environment template with placeholders only. Covers ANTHROPIC_API_KEY, OPENAI_API_KEY, GOOGLE_AI_API_KEY, ZAI_API_KEY, GOOGLE_DRIVE_TOKEN_PATH, GITHUB_TOKEN.
- `.gitignore` (NEW): Covers secrets (.env, *.key, *.pem, *token*), runtime state (.pid, state.db, .pane-assignments), logs, vendor, venv, OS noise, large user data (Knowledge, _raw, _sources).
- `gitleaks.toml` (NEW): 9 detection rules — anthropic-api-key, openai-api-key, google-ai-key, github-token, generic-api-key, private-key, zai-deepseek-key, dotenv-file, keychain-or-pem-file. Allowlist: .env.example, defaults.yaml, smoke-test.sh, tests/.
- `docker/Dockerfile` (NEW): ubuntu:24.04, non-root user "solar", ENTRYPOINT smoke-test.sh. No secrets, no live paths.
- `docker/smoke-test.sh` (NEW): 15-test container suite — install, doctor, secret scan, .env perms, config audit, state.db, gitignore/gitleaks, hooks, upgrade dry-run, restore list, existing commands, gitleaks detect. PASS/FAIL counters.
- `hooks/pre-commit-secret-scan` (NEW): gitleaks --staged, blocks commit on leak. Warns (non-blocking) if gitleaks not installed.
- `hooks/pre-push-secret-scan` (NEW): gitleaks full diff against remote, blocks push on leak. Fails hard if gitleaks missing.
- `tests/installer/test-s1-installer.sh` (NEW): 15-test suite, 38 probes — inventory, executables, syntax, doctor schema, secret checks, gitignore coverage, gitleaks rules, upgrade help, restore list, hook structure, cross-slice isolation, Dockerfile audit.

## Architecture

```
installer/
├── install.sh      ── OS detect → deps → dirs → config → state DB → snapshot → doctor
├── upgrade.sh      ── pre-snapshot → protect → apply → doctor → restore-on-fail
├── doctor.sh       ── JSON: os/bins/paths/services/secrets/skills → verdict
└── restore.sh      ── list/latest/dry-run/apply (wraps product_snapshot)
config/defaults.yaml ── providers, vault, storage, mirage, skills, mineru, qmd, control_plane, secret_scan
.env.example        ── placeholders only; real .env is gitignored
.gitignore          ── secrets, state, logs, vendor, OS noise, user data
gitleaks.toml       ── 9 rules + allowlist
docker/
├── Dockerfile      ── ubuntu:24.04, non-root, ENTRYPOINT smoke-test
└── smoke-test.sh   ── 15 checks: install→doctor→secrets→hooks→upgrade→restore→gitleaks
hooks/
├── pre-commit-secret-scan ── gitleaks --staged
└── pre-push-secret-scan   ── gitleaks full diff (hard fail)
tests/installer/
└── test-s1-installer.sh   ── 15 cases, 38 probes
```

## Verification Evidence

All checks pass on macOS host (Darwin 15.7.3):

```
Bash syntax:        8/8 PASS
S1 test suite:      38/38 PASS (PASS=38 FAIL=0)
Doctor JSON:        valid, verdict=ok, no secret leaks
Cross-slice:        S6 files untouched, solar-harness.sh bash -n PASS
Existing harness:   doctor.sh --summary PASS, wiki qmd-status PASS
```

Doctor JSON output (truncated):
```json
{
  "ts": "2026-05-09T13:07:30Z",
  "os": {"kind": "darwin", "version": "15.7.3"},
  "bins": {"bash": "ok", "python3": "ok", "git": "ok", "tmux": "ok", ...},
  "paths": {"~/.solar": "ok", "~/.solar/harness": "ok", "~/Knowledge": "ok", ...},
  "services": {"harness": "running", "qmd-mcp": {"status": "running"}, "state_db": {"status": "ok", "tables": ["tasks","assignments","leases","events","artifacts","capabilities"]}},
  "secrets": {"anthropic": "missing", "openai": "missing", "zai": "configured"},
  "skills": {"builtins_count": 10, "registry_drift": 0},
  "verdict": "ok",
  "warnings": []
}
```

## Gates Covered

| Gate | Requirement | Status |
|------|-------------|--------|
| G2 | Container clean install | Dockerfile + smoke-test.sh ready for docker build |
| G3 | Secret scan | gitleaks.toml + pre-commit + pre-push hooks; 0 plaintext secrets in all S1 files |

## Known Risks

- **Container test not run**: Docker validation requires `docker build`, which was not executed on this host. The Dockerfile and smoke-test.sh are syntactically valid and self-contained, but the actual container round-trip needs docker runtime.
- **gitleaks not installed on host**: T5 reveals gitleaks is "missing" on this macOS host. Pre-commit hook degrades gracefully (warn, non-blocking). Pre-push hook fails hard — user must install gitleaks before pushing.
- **`.env` file not created**: The install.sh wizard was not run interactively. .env is only created during actual install (install.sh or manual copy from .env.example).
- **macOS-specific paths in container smoke-test.sh**: smoke-test.sh uses Linux paths (/opt/solar, /home/solar) — these are correct for the container environment but won't resolve on macOS host. This is intentional; container mounts handle the mapping.

## Not Done

Per S1 scope constraint:
- S2 (skill platform), S3 (storage), S4 (plugins), S5 (evolution), S6 (control plane), S7 (release) — not S1 scope
- Actual Docker build and container smoke test — requires docker daemon
- Integration with existing solar-harness.sh command dispatch — installer scripts are standalone; integration into the `solar` CLI entrypoint is not in S1 scope
- First-run config wizard (interactive) — only --non-interactive mode is fully implemented; interactive wizard is scaffolded but requires UI polish beyond S1 scope

## Handoff Checklist

- [x] All 12 S1 files created and executable where appropriate
- [x] Bash syntax check: 8/8 PASS
- [x] S1 test suite: 38/38 PASS
- [x] Doctor --json: valid Design §2.2 schema, verdict=ok
- [x] No plaintext secrets in any S1 file (verified by T6, T7, T14)
- [x] Cross-slice isolation: S6 files untouched, solar-harness.sh unchanged
- [x] Existing harness commands not broken
- [x] Status history: s1_ready_for_eval
- [x] Parent sprint NOT marked passed
