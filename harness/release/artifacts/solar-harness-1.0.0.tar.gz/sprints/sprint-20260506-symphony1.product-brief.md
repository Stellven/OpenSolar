---
sprint_id: sprint-20260506-symphony1
title: Symphony 集成 Sprint 1 — workflow-loader.ts 单文件契约 (收缩版)
source: 监护人昊哥 2026-05-06 (收缩版终稿)
revision: v2-shrunk
intent: |
  引入 OpenAI Symphony 风格的 WORKFLOW.md 单文件契约模式:
    - YAML front matter 承载 config
    - Liquid 模板承载 prompt
    - 以新增 workflow-loader.ts 为主, 不替换 Solar Harness
    - 旧 contract.md 通过兼容层做"主路径迁移", 不承诺历史格式 100% 吞并
problem: |
  现状:
    - sprint 合约散落 .solar/harness/sprints/<id>.contract.md, 配置混在 markdown
    - 提示模板硬编码在 dispatch.md, 无法版本化 + 无法 watch 热更新
    - 新增 sprint 类型需要手改多处
    - Symphony 设计领先 1-2 代, 不学习就持续落后
  解决:
    workflow-loader.ts (TS) 实现 Symphony SPEC §5 核心接口,
    YAML front matter (config) + Markdown body (Liquid 模板),
    旧合约通过适配层主路径迁移, 不破坏现有 sprint 流程.
priority: P1
priority_reason: |
  P1 而非 P0:
    - SkillRL Mission 已收尾, 不冲突
    - Solar Harness 当前能用, 不存在阻塞性 bug
    - 但延迟集成会让 Solar 持续落后 1-2 代
    - 7 天工作量, 风险可控, ROI 中等偏高
lane_hint: delivery
acceptance:
  - title: Front matter 解析
    detail: |
      支持 Symphony SPEC §5.3 的 6 个顶级 key:
      tracker / polling / workspace / hooks / agent / codex.
      缺失必填字段时抛显式 validation error.
  - title: 环境变量替换
    detail: |
      支持 $VAR 解析; 未定义变量默认 fail; 可在测试中注入 mock env.
  - title: Liquid 模板渲染
    detail: |
      支持 issue / attempt 两个标准变量; unknown variable 必须 fail;
      渲染错误必须落到统一 error class.
  - title: 错误系统 (5 个 error class)
    detail: |
      WorkflowMissingError / WorkflowParseError / WorkflowFrontMatterError /
      WorkflowRenderError / WorkflowValidationError
  - title: 兼容层
    detail: |
      支持当前最常见的 3 类旧 contract.md 主路径迁移;
      unsupported 字段必须输出清单, 不静默吞掉;
      不要求 Sprint 1 达到"历史 contract 100% 自动迁移".
  - title: 测试
    detail: |
      核心模块单测覆盖率 >= 80%; adapter 覆盖率 >= 70%;
      端到端: 1 个黄金路径 + 2 个 smoke sprint.
  - title: 文档
    detail: |
      README + 至少 2 个高质量使用示例 (新建 WORKFLOW.md / 旧 contract 迁移).
  - title: 可选增强 (chokidar 热更新)
    detail: |
      chokidar + 500ms debounce 仅在 Day 6 后启用;
      若主线吃紧, 可后移, 不阻塞 Sprint 1 放行.
non_goals:
  - 不承诺历史 contract.md 100% 自动迁移 (3 类主路径即可)
  - 不集成 Linear tracker (Sprint 1 只做 loader)
  - 不替换 coordinator.sh 主循环
  - 不强制现有 sprint 立即迁移 (新 sprint 用新格式)
  - 不引入 Elixir/OTP 依赖
  - 不重写 sprint 状态机 (沿用 events.jsonl + status.json)
gates:
  gate_a:
    when: Day 2
    pass_criteria:
      - types/workflow.ts 完成
      - front matter 可解析
      - env var 替换通过
      - validation error 可测
    judge: planner (主持) — builder 不自判
  gate_b:
    when: Day 5
    pass_criteria:
      - liquid render 完成
      - unknown var fail 完成
      - 兼容层 3 类主路径迁移完成
      - 核心单测覆盖率达标 (>= 80%)
    judge: planner (主持) — builder 不自判
    gate_failure_consequence: |
      Gate B 未过 → 不进入 watch / 文档增强 (Day 6-7 收缩)
stop_rules:
  - 核心 acceptance 完成度 < 50% → 暂停并重评
  - workflow-loader.ts + adapter + types 总实现复杂度明显失控 → 触发简化审查
  - 核心测试覆盖率 < 60% → 不放行
  - 工期 > 10 天 → 重新估算并拆 Sprint
  - Day 5 前 Gate B 未过 → 不进入 watch / 文档增强
deliverables:
  - ~/.claude/core/solar-farm/workflow-loader.ts
  - ~/.claude/core/solar-farm/workflow-loader.test.ts
  - ~/.claude/core/solar-farm/workflow-adapter.ts
  - ~/.claude/core/solar-farm/types/workflow.ts
  - ~/.claude/core/solar-farm/README-workflow-loader.md
  - ~/.solar/harness/sprints/sprint-20260506-symphony1.eval.md
schedule:
  day_1:
    - types/workflow.ts
    - front matter schema
    - parser 单测
  day_2:
    - env var substitution
    - validation
    - Gate A
  day_3:
    - Liquid 渲染
    - issue / attempt 变量注入
    - unknown var fail
  day_4:
    - 5 个 error class
    - loader 单测补齐
  day_5:
    - workflow-adapter.ts
    - 3 类旧 contract 主路径迁移
    - Gate B
  day_6:
    - e2e: 1 gold + 2 smoke
    - 若主线稳定, 再加 watch
  day_7:
    - README + 2 个示例
    - 审判官评估
crew:
  builder_main: glm-5.1
  builder_fallback: deepseek-v4-pro
  evaluator: deepseek-r1
  gate_judge: planner
references:
  - 完整分析: ~/.solar/reports/2026-05-06-symphony-vs-solar-harness.md
  - Symphony SPEC: https://github.com/openai/symphony/blob/main/SPEC.md (§5)
  - Symphony 实现: https://github.com/openai/symphony/blob/main/elixir/WORKFLOW.md
  - 审判官 SROE: b4f5494f9c564c05 (deepseek-r1)
handoff_to: planner
planner_hint: |
  本 brief 是昊哥亲自收缩的终稿, 不要再扩范围.
  关键约束:
    - 7 天硬上限, 工期 > 10 天必须暂停重估
    - 覆盖率分层: 核心 80% / adapter 70% (不一刀切)
    - 兼容层只覆盖 3 类主路径, 历史 100% 不强求
    - Gate A (Day 2) / Gate B (Day 5) 由 planner 主持判定, builder 不能自判
    - chokidar watch 是可选增强, Day 6 后才能启用
  生成 sprint contract 时:
    - 派工: builder=glm-5.1 主, deepseek-v4-pro 处理模板渲染疑难
    - 评估: deepseek-r1
    - Gate 判定: planner (你自己)
created_at: 2026-05-06T00:00:00Z
updated_at: 2026-05-06T20:55:00Z
created_by: pm (Solar 战略家面)
revised_by: 监护人昊哥 (收缩版终稿)
---

# Symphony 集成 Sprint 1 — workflow-loader.ts (收缩版)

> 对应主报告: `~/.solar/reports/2026-05-06-symphony-vs-solar-harness.md`
> 对应 Mission: 选择性吸收 Symphony 3 核心模式 (90 天 3 Sprint)
> **本版来源**: 昊哥 2026-05-06 收缩版终稿 (替换 v1)

## V1 → V2 主要差异

| 项 | v1 (旧) | v2 (收缩版) |
|----|---------|-------------|
| 兼容层 | 现有 sprint 100% 可迁移 | 3 类主路径主迁移, unsupported 输出清单 |
| 覆盖率 | 一刀切 ≥ 80% | 核心 80% / adapter 70% 分层 |
| e2e | 3 个真实 sprint | 1 gold + 2 smoke |
| 文档示例 | 5 个 | 2 个高质量 |
| watch 热更新 | 必须项 | 可选增强 (Day 6 后) |
| Gate | Day 5 中段 (单点) | Gate A (Day 2) + Gate B (Day 5) 双闸 |
| Gate 判定者 | 未明确 | planner 主持, builder 不自判 |
| 派工 | glm-5 OR deepseek-v4-pro | glm-5.1 主 + v4-pro 疑难 + r1 评估 + planner Gate |

## 战略家说

不妨试试 — Symphony 的 WORKFLOW.md 设计真的优雅, Gate 机制 + 范围收缩 + 不强求 100%, 7 天落地概率显著提升.

## 治理官说

证据显示该方案 Go: 4 风险点已审计 (R1 高/R2 中/R3 中/R4 低), 全部有缓解.
收缩版改进点已逐项审计, 治理强度 +1 级 (双 Gate + builder 不自判).
建议: 严格执行 Gate B (Day 5), 任何一项未过即收缩 Day 6-7.

## Next Action

→ planner 读取本 brief 生成 `sprint-20260506-symphony1.contract.md`
→ coordinator 派发到 builder pane (glm-5.1)
→ Day 2 Gate A / Day 5 Gate B / Day 7 审判官评估 (r1)
