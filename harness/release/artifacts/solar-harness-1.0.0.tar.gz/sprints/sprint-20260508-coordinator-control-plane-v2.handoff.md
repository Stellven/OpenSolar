# Handoff — sprint-20260508-coordinator-control-plane-v2
Builder: 建设者化身 (Claude Sonnet 4.6)
Round: 3
Stage: S1+S2+S3 (Canonical Mapper + Dispatch Ledger + Queue + Ack Contract + Pane Lease)

---

## Summary

Delivered S1+S2+S3 of Coordinator Control Plane v2. S4-S8 are **Not Done**.

**S1**: Pure-read canonical state mapper translating legacy `status`/`phase`/`handoff_to` combinations into typed `lifecycle_state`/`lifecycle_role`, plus transition validation from frozen JSON config. Key legacy bug (drafting+prd_ready+handoff_to=planner mis-routed to PM) explicitly corrected.

**S2**: Dispatch ledger (append-only JSONL with Python fcntl flock, unique `dispatch_id` per dispatch) + per-sprint FIFO queue with 24h dedup. `dispatch_to_pane` now emits `attempted`/`acked`/`nacked` ledger events. `SOLAR_COORD_DRY_RUN=1` mode: skips send-keys but still writes ledger.

**S3**: Pane Ownership Lease (flock+atomic rename; TTL-based; dispatch_id-bound release) + Ack Contract (`sprints/<sid>.ack-<dispatch_id>.json`; schema with role/status/exit_code/artifacts) + `ack_watcher_bg` (background watcher polling every 2s; on ack found → ledger `acked_by_ack_file`; on timeout → ledger `ack_timeout`). `solar-harness.sh do_handoff_submit` now writes the ack file automatically when builder submits handoff.

---

## Changed Files

| File | Change |
|------|--------|
| `lib/state-mapper.sh` | CREATED (S1) — exports `map_canonical_state` and `validate_transition`; stderr-silent; fail-open |
| `config/coordinator-state-machine.json` | CREATED (S1) — frozen; 7 transitions; KEY BUG FIX legacy combo |
| `lib/dispatch-ledger.sh` | CREATED (S2) — `new_dispatch_id`, `dispatch_ledger_append` (flock), `dispatch_ledger_query` |
| `lib/queue.sh` | CREATED (S2) — `queue_enqueue`/`queue_pop`/`queue_peek`/`queue_depth`; 24h dedup; crash-safe via atomic rename |
| `lib/pane-lease.sh` | CREATED (S3) — `acquire_pane_lease`/`release_pane_lease`/`check_pane_lease`/`reap_expired_leases`; flock+atomic rename; dispatch_id-bound |
| `lib/ack-watcher.sh` | CREATED (S3) — `write_ack_file`/`read_ack_file`/`ack_watcher_bg`; background watcher; ledger integration |
| `run/dispatch-ledger.jsonl` | CREATED (S2) — empty initial file |
| `coordinator.sh` | EDITED (S1+S2+S3) — source lines for all libs; mapper log; dispatch_id; pane lease acquire/release; ack_watcher_bg launch |
| `solar-harness.sh` | EDITED (S3) — `do_handoff_submit` writes ack file on builder handoff |
| `tests/test-state-mapper.sh` | CREATED (S1) — 11 checks, PASS=11 FAIL=0 |
| `tests/test-dispatch-ledger.sh` | CREATED (S2) — 20 checks, PASS=20 FAIL=0 |
| `tests/test-pane-lease.sh` | CREATED (S3) — 9 checks, PASS=9 FAIL=0 |
| `tests/test-ack-contract.sh` | CREATED (S3) — 15 checks, PASS=15 FAIL=0 |

---

## Architecture (S3 additions)

```
dispatch_to_pane(sid, pane)
  1. new_dispatch_id()  →  _dispatch_id
  2. acquire_pane_lease(pane, sid, _dispatch_id)
       exit 2 if busy → ledger.nacked, return early
  3. send-keys to pane (or SOLAR_COORD_DRY_RUN skip)
  4. capture-pane verify → ledger.attempted_verified
  5. echo _dispatch_id > sprints/<sid>.current-dispatch-id
  6. ack_watcher_bg(sid, _dispatch_id, 300)
       background: polls every 2s for sprints/<sid>.ack-<did>.json
       found → ledger.acked_by_ack_file
       timeout → ledger.ack_timeout

solar-harness.sh do_handoff_submit(sid)
  reads sprints/<sid>.current-dispatch-id → _did
  writes sprints/<sid>.ack-<_did>.json
    {dispatch_id, sid, role=builder, status=success,
     exit_code=0, message, artifacts=[handoff.md], wrote_at}
```

---

## Verification Evidence

### S3 Tests

```
bash tests/test-pane-lease.sh
=== test-pane-lease.sh ===
  ✅ acquire on empty → acquired=True
  ✅ acquire while leased → acquired=False
  ✅ check_pane_lease contains dispatch_id
  ✅ release wrong did → released=False
  ✅ release correct did → released=True
  ✅ acquire after release → acquired=True
  ✅ reap_expired_leases returns >=1 after TTL expiry
  ✅ acquire after reap → acquired=True
  ✅ concurrent 10 acquires: exactly 1 succeeds
=== RESULT: PASS=9 FAIL=0 ===

bash tests/test-ack-contract.sh
=== test-ack-contract.sh ===
  ✅ ack file created
  ✅ ack contains dispatch_id
  ✅ ack contains sid
  ✅ ack contains role=builder
  ✅ ack contains status=success
  ✅ ack contains exit_code
  ✅ ack contains artifacts
  ✅ read_ack_file returns content
  ✅ read_ack_file missing → empty
  ✅ ack-watcher writes acked_by_ack_file to ledger
  ✅ ack-watcher ledger entry has correct did
  ✅ ack-watcher timeout writes ack_timeout to ledger
  ✅ ack_timeout entry has correct sid
  ✅ failed ack has status=failed
  ✅ failed ack has exit_code=1
=== RESULT: PASS=15 FAIL=0 ===
```

### Full Regression (S1+S2+S3)

```
bash tests/test-state-mapper.sh   → PASS=11 FAIL=0
bash tests/test-dispatch-ledger.sh → PASS=20 FAIL=0
bash tests/test-pane-lease.sh     → PASS=9 FAIL=0
bash tests/test-ack-contract.sh   → PASS=15 FAIL=0

bash -n lib/state-mapper.sh
bash -n lib/dispatch-ledger.sh
bash -n lib/queue.sh
bash -n lib/pane-lease.sh
bash -n lib/ack-watcher.sh
bash -n coordinator.sh
bash -n solar-harness.sh
All syntax OK
```

### Done Conditions (S3)

1. ✅ `acquire_pane_lease` returns `{acquired:true}` on empty pane; `{acquired:false}` when held (T1, T2)
2. ✅ Lease is dispatch_id-bound: wrong DID cannot release (T4)
3. ✅ Expired leases reaped by `reap_expired_leases`, pane freed (T7, T8)
4. ✅ Concurrent 10 acquires → exactly 1 succeeds (T9 flock integrity)
5. ✅ `write_ack_file` schema: dispatch_id / sid / role / status / exit_code / artifacts[] / wrote_at (T1-T7)
6. ✅ `ack_watcher_bg` → `acked_by_ack_file` in ledger on fast path (T10)
7. ✅ `ack_watcher_bg` → `ack_timeout` in ledger on timeout (T11)
8. ✅ `solar-harness.sh do_handoff_submit` writes ack file automatically (wired in solar-harness.sh)

---

## S1+S2 Done Conditions (carried forward)

S1:
1. ✅ `map_canonical_state <sid>` outputs JSON with all required fields, stderr silent
2. ✅ `validate_transition <from> <to> <event>` exits 0/1/2; reason on stdout for denied/unknown
3. ✅ `coordinator-state-machine.json` has 7 transitions (≥6 required)
4. ✅ drafting+prd_ready+handoff_to=planner → prd_ready/planner (KEY BUG FIX confirmed)
5. ✅ corrupt/missing status.json → lifecycle_state=corrupt, no exception
6. ✅ PASS=11 FAIL=0

S2:
1. ✅ `new_dispatch_id` format `d-<YYYYMMDDTHHMMSSz>-<6hex>` — 1000 IDs, 0 duplicates
2. ✅ `dispatch_ledger_append` atomic via fcntl flock (concurrent 10 appends, all recorded)
3. ✅ `queue_enqueue` FIFO, 24h SHA256 dedup, crash-safe atomic rename
4. ✅ `dispatch_to_pane` emits ledger events: `attempted` / `attempted_verified` / `nacked`
5. ✅ `SOLAR_COORD_DRY_RUN=1` skips send-keys but still writes ledger
6. ✅ PASS=20 FAIL=0

---

## Not Done

S4-S8:

| Stage | Title |
|-------|-------|
| S4 | Prompt Quarantine Lifecycle (`lib/prompt-quarantine.sh` + coordinator integration) |
| S5 | Artifact Gate + Cooldown + Corrupt Recovery |
| S6 | Workflow Registry + Dummy Role |
| S7 | Doctor CLI |
| S8 | Regression Tests + Migration Wrap-up |
