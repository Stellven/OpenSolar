---
sprint_id: sprint-20260508-solar-config-ui
title: Solar Unified Config Web UI
priority: P1
lane: product
owner: planner
created_at: 2026-05-08T17:25:00Z
status: implementation_seeded
handoff_to: evaluator
blocked_by: sprint-20260508-workstream-verification-closeout
---

# Sprint Contract — Solar Unified Config Web UI

## Intent

Provide a local-first setup page for Solar Harness so a new user can configure model keys, vault path, QMD, Mirage, Apple Notes, and automation without editing shell files by hand.

## Seed Implementation

- `/Users/sihaoli/.solar/harness/integrations/solar-config-server.py`
- `/Users/sihaoli/.solar/harness/solar-config-ui.sh`
- `/Users/sihaoli/.solar/harness/docs/mirage-data-substrate-codex-solar.md`

## Acceptance

- `bash ~/.solar/harness/solar-config-ui.sh start --open` opens `http://127.0.0.1:8789/setup`.
- Config saves to `~/.solar/harness/config/solar-user-config.json`.
- Secrets save to `~/.solar/secrets/solar-user-secrets.env` with mode 0600.
- `/api/status` checks wiki/qmd/mirage/status-server.
- Page never returns secret values unmasked.
- Future installer calls `bash ~/.solar/harness/solar-config-ui.sh first-run --open`.

