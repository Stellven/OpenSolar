# Handoff — sprint-20260509-solar-product-platform (S4)
Builder: 建设者化身
Round: 1

## 变更文件

- `schemas/plugin.schema.json`: JSON Schema for plugin manifest validation
- `schemas/capability.schema.json`: JSON Schema for capability registry entries
- `plugins/obsidian/manifest.yaml`: Obsidian Wiki plugin (closed_loop, 4 capabilities)
- `plugins/qmd/manifest.yaml`: QMD Index plugin (default_usable, 3 capabilities)
- `plugins/mineru/manifest.yaml`: MinerU PDF extractor (basic_usable, 3 capabilities)
- `plugins/mirage/manifest.yaml`: Mirage VFS plugin (closed_loop, 4 capabilities)
- `plugins/mermaid/manifest.yaml`: Mermaid renderer (basic_usable, 3 capabilities)
- `lib/plugin_loader.py`: Plugin loader — manifest validation, scope enforcement, install/disable/list/status CLI
- `lib/capability_registry.py`: Capability registry — syncs from manifests to state DB, query/scorecard CLI
- `solar-harness.sh`: Extended `integrations` subcommand with plugins/install/disable/list/validate/capabilities/sync-caps
- `ADR/ADR-003-plugin-sandbox-scope-checked.md`: ADR for scope-checked sandbox strategy
- `tests/plugins/test-s4-extension-framework.sh`: S4 acceptance regression suite
- `config/mirage.solar.yaml`: corrected S3/S4 mount contract to `/knowledge /raw /sources /papers /qmd /solar-db /cortex /sprints /drive`
- `tests/test-mirage-unified-vfs.sh`: updated Mirage regression expectations to the canonical mount contract
- `tests/test-mirage-substrate.sh`: updated read-only mount checks to the canonical mount contract
- `lib/external-integrations-health.py`: added `summary.integration_levels` four-tier counts to `integrations status --json`
- `lib/solar-unified-context.py`: changed fallback mount label from `/solar_db` to `/solar-db`

## Done 定义达成

1. **D4.1 ≥5 plugin manifests schema-valid**: ✅ 5 manifests (obsidian/qmd/mineru/mirage/mermaid), all pass validation and now declare `commands`, `background_safety`, `eval_packs`, and `rollback`.

2. **D4.2 integrations status --json four-level output**: ✅ `solar-harness integrations plugins --json` returns `by_level`; `solar-harness integrations status --json --refresh` returns `summary.integration_levels` with `dead_end/basic_usable/default_usable/closed_loop`.

3. **D4.3 capability registry persisted to state DB**: ✅ `capability_registry.py sync` writes 17 capabilities to `plugin_capabilities` table in `run/state.db`. T11 (17 caps synced) + T12 + T13 PASS.

4. **D4.4 plugin scope violation → rejected + events alert**: ✅ `plugin_loader.py check-scope --plugin mermaid --path /etc/passwd` returns `{"allowed": false, "alert": "scope_violation_rejected"}` and emits `plugin.scope_violation` to events.jsonl. T8 + T10 PASS.

5. **D4.5 plugin install/disable/list CLI**: ✅ `solar-harness integrations install|disable|list` all routed and working. Install/disable round-trip verified (mermaid disabled→re-enabled). T14 + T15 PASS.

6. **D4.6 ADR-003 written**: ✅ `ADR/ADR-003-plugin-sandbox-scope-checked.md` documents scope-checked start strategy, four-level integration classification, capability registry design, alternatives considered, and future work.

## 验证方法

```bash
cd ~/.solar/harness
bash tests/plugins/test-s4-extension-framework.sh
# Expected: === S4 Extension Framework: PASS=23 FAIL=0 ===

bash tests/test-mirage-unified-vfs.sh
# Expected: Results: 36 passed, 0 failed

# Individual checks:
python3 lib/plugin_loader.py list --json
python3 lib/plugin_loader.py validate --json
python3 lib/plugin_loader.py status --json
python3 lib/plugin_loader.py check-scope --plugin mermaid --path /etc/passwd --json
python3 lib/capability_registry.py sync --json
python3 lib/capability_registry.py scorecard --json
solar-harness integrations plugins --json
```

## 备注

- scope enforcement uses path-prefix check after HARNESS_DIR-relative expansion; /tmp/solar-* always allowed
- capability registry creates `plugin_capabilities` table (separate from existing `capabilities` pane-table in S6 schema)
- S3 Mirage mount deviation is repaired: `/solar` and `/projects` are no longer exposed; `/sources`, `/papers`, and `/solar-db` are present.
- 17 capabilities total: obsidian(4) + qmd(3) + mineru(3) + mirage(4) + mermaid(3)

## Closeout Addendum — 2026-05-09T15:09:03Z

Additional regression run:

```text
tests/plugins/test-s4-extension-framework.sh  PASS=23 FAIL=0
tests/test-mirage-unified-vfs.sh              36 passed, 0 failed
bash -n solar-harness.sh coordinator.sh pane-launcher.sh
python3 -m py_compile plugin_loader.py capability_registry.py solar_mirage.py external-integrations-health.py solar-unified-context.py
```

S4 gate A10 is ready to pass.
