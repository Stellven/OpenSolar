# Builder Dispatch — Slice 1 Only

Sprint: `sprint-20260508-solar-kb-obsidian-autouse`
Role: Builder #1 / main-screen builder
Scope: Slice 1 only from `sprint-20260508-solar-kb-obsidian-autouse.plan.md`

## Override

If you previously received a broad "按 planner plan 实现代码" instruction for this sprint, narrow it now:

- Do only Slice 1: Retrieval Hook + `memory-influence.sh` fix.
- Do not touch Slice 2 or Slice 3 files.
- Do not update the whole sprint to `reviewing`.
- Write your completion report to `/Users/sihaoli/.solar/harness/sprints/sprint-20260508-solar-kb-obsidian-autouse.handoff-builder1.md`.

## Files You Own

- `/Users/sihaoli/.solar/harness/lib/solar-knowledge-context.py`
- `/Users/sihaoli/.claude/hooks/solar-knowledge-context.sh`
- `/Users/sihaoli/.claude/hooks/memory-influence.sh`
- `/Users/sihaoli/.claude/settings.json` (incremental hook registration only)

## Files You Must Not Touch

- `/Users/sihaoli/.solar/harness/lib/obsidian-vault-indexer.py`
- `/Users/sihaoli/.claude/core/cortex/knowledge-sync.ts`
- `/Users/sihaoli/.solar/harness/integrations/obsidian-wiki-bridge.sh`
- `/Users/sihaoli/.solar/harness/integrations/wiki-capture-server.py`
- `/Users/sihaoli/.solar/harness/solar-harness.sh`

## Required Reads

```bash
cat /Users/sihaoli/.solar/harness/sprints/sprint-20260508-solar-kb-obsidian-autouse.contract.md
cat /Users/sihaoli/.solar/harness/sprints/sprint-20260508-solar-kb-obsidian-autouse.plan.md
```

## Verify Before Handoff

```bash
python3 /Users/sihaoli/.solar/harness/lib/solar-knowledge-context.py --query "Solar 记忆系统" --json
bash -n /Users/sihaoli/.claude/hooks/solar-knowledge-context.sh
bash -n /Users/sihaoli/.claude/hooks/memory-influence.sh
SOLAR_DB=/tmp/missing-solar.db python3 /Users/sihaoli/.solar/harness/lib/solar-knowledge-context.py --query test --fail-open --json
```

## Handoff

Write `/Users/sihaoli/.solar/harness/sprints/sprint-20260508-solar-kb-obsidian-autouse.handoff-builder1.md` with:

- `## Summary`
- `## Changed Files`
- `## Done 达成`
- `## Verification Evidence`
- `## Known Risks`
- `## Not Done`

