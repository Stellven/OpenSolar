# Fix Dispatch — Mirage VFS Test Defects

Sprint: `sprint-20260508-mirage-unified-vfs`
Source: `~/.solar/harness/reports/mirage-cortex-access-test-20260508.{md,json}`
Created: 2026-05-08
Owner: builder_main + evaluator

---

## F-D2-A — Enforce deny_subpaths in exec path resolution (P0 SECURITY)

Owner: builder_main

Write Scope:
- `/Users/sihaoli/.solar/harness/lib/solar_mirage.py` — function `_resolve_mount` and `cmd_exec`

Behavior:
- For each mount `M` with `deny_subpaths: [s1, s2, ...]`, when resolving an argv token to a physical path, **after** prefix-matching to mount, **reject** if the path resolves under any `deny_subpaths` entry.
- Rejection format: `{"error": "path blocked by deny_subpaths: <subpath>", "cmd": "<orig>", "exit_code": 126}`. Do not include the resolved physical path in the error.
- Apply to read verbs (ls/cat/find/grep/head/wc/jq), not just write verbs.

Verify (must all PASS):
```bash
# 1. cat denied secrets file refused
solar-harness mirage exec "cat /solar/secrets/solar-user-secrets.env" --json \
  | python3 -c 'import json,sys; d=json.load(sys.stdin); assert d.get("error","").startswith("path blocked"), d'

# 2. ls denied dir refused
solar-harness mirage exec "ls /solar/secrets" --json \
  | python3 -c 'import json,sys; d=json.load(sys.stdin); assert d.get("error","").startswith("path blocked"), d'

# 3. allowed paths still work
solar-harness mirage exec "ls /cortex" --json \
  | python3 -c 'import json,sys; d=json.load(sys.stdin); assert "CLOSED-LOOP-README.md" in d.get("stdout",""), d'

# 4. .env subpath catch (any path containing .env should be blocked under /solar)
solar-harness mirage exec "find /solar -name '*.env'" --json \
  | python3 -c 'import json,sys; d=json.load(sys.stdin); out=d.get("stdout",""); assert "secrets/solar-user-secrets.env" not in out, out'
```

Rollback: `git revert` the patch; deny_subpaths reverts to no-op (current state).

---

## F-D2-B — Post-exec stdout redaction (P0 SECURITY)

Owner: builder_main

Write Scope:
- `/Users/sihaoli/.solar/harness/lib/solar_mirage.py` — `cmd_exec` post-processing

Behavior:
- After subprocess returns and before envelope `stdout` is set, run `redact_patterns` (from yaml `policy.redact_patterns`) over stdout text. Replace each match with `***REDACTED***`.
- Same redaction applies to stderr.
- The 4 patterns in current yaml: `sk-[A-Za-z0-9]{20,}`, `Bearer [A-Za-z0-9._-]+`, `api_key=[^\s"']+`, `client_secret=[^\s"']+`. Add `refresh_token=[^\s"']+` if not present.

Verify:
```bash
# Synthesize a test file under /raw containing a fake sk- token, read via mirage, confirm redacted
echo 'TOKEN=sk-aaaaaaaaaaaaaaaaaaaaaaaa' > /Users/sihaoli/Knowledge/_raw/__redact_test.tmp
solar-harness mirage exec "cat /raw/__redact_test.tmp" --json \
  | python3 -c 'import json,sys; d=json.load(sys.stdin); out=d.get("stdout",""); assert "sk-aaaa" not in out and "REDACTED" in out, out'
rm -f /Users/sihaoli/Knowledge/_raw/__redact_test.tmp
```

Rollback: `git revert`; redaction reverts to no-op (current state).

---

## F-D3 — Isolate --json flag from inner command (P1)

Owner: builder_main

Write Scope:
- `/Users/sihaoli/.solar/harness/lib/solar_mirage.py` — argparse for `exec` subparser

Behavior:
- Either:
  (a) Use `--` separator pattern: `solar-harness mirage exec --json -- ls /cortex`, OR
  (b) In current `nargs=REMAINDER` design, post-process the captured `cmd` list by stripping any leading top-level flags (`--json`, `--id`, `--timeout`, `--allow-write-drive`, `--allow-write-projects`) that argparse failed to consume.
- Document the chosen approach in `~/.solar/harness/docs/mirage-unified-vfs.md`.

Verify:
```bash
# 1. ls /cortex no longer pollutes stderr
solar-harness mirage exec "ls /cortex" --json \
  | python3 -c 'import json,sys; d=json.load(sys.stdin); assert "--json" not in d.get("stderr",""), d.get("stderr","")'

# 2. exit_code accurate
solar-harness mirage exec "ls /cortex" --json \
  | python3 -c 'import json,sys; d=json.load(sys.stdin); assert d.get("exit_code")==0, d.get("exit_code")'
```

Rollback: revert argparse change.

---

## F-D4 — Regression coverage for redaction (P2)

Owner: evaluator

Write Scope:
- `/Users/sihaoli/.solar/harness/tests/test-mirage-unified-vfs.sh` — add cases

Behavior:
- Add test cases covering:
  - deny_subpaths block on `cat /solar/secrets/...` (expect refused)
  - deny_subpaths block on `ls /solar/secrets`
  - redact_on_read on synthetic `/raw/__test_secrets.tmp` with each of 4-5 patterns
  - --json flag isolation (no stderr pollution)
- Each case must be self-cleaning (rm tmp files at end).

Verify:
```bash
bash /Users/sihaoli/.solar/harness/tests/test-mirage-unified-vfs.sh
test $? -eq 0
```

Rollback: remove appended cases.

---

## Acceptance Order

1. F-D2-A and F-D2-B must land **before** any sprint defaults its agent retrieval to `mirage exec`.
2. F-D3 lands next; reduces noise for evaluators.
3. F-D4 lands as part of evaluator pass before sprint can be marked PASS.

## Constraints

- No write outside listed scopes.
- No new dependencies.
- No changes to `mirage.solar.yaml` schema (deny_subpaths and redact_patterns already defined; only enforcement code changes).
- Do not log or echo any real secret values during testing or in error messages.
