# Preflight Report — Coordinator Control Plane v2

**Sprint**: sprint-20260508-coordinator-control-plane-v2
**Reviewer**: lab-builder-2 (read-only preflight)
**Date**: 2026-05-08
**Sources**: design.md + plan.md read-only analysis

---

## 1. File Change Priority — 最先该改的文件

按 Stage 阻塞关系排序（S1 blocks everything）：

| Priority | File | Stage | Why First |
|----------|------|-------|-----------|
| **P0** | `lib/state-mapper.sh` (NEW) | S1 | 所有后续 Stage 的 canonical state 来源。没有 mapper → transition table 无法驱动 → S2-S8 全卡。 |
| **P0** | `config/coordinator-state-machine.json` (NEW) | S1 | Transition table 是 mapper 的配置输入。必须和 mapper 同步设计。 |
| **P0** | `coordinator.sh` — 仅加 `source lib/state-mapper.sh` | S1 | 最小注入点。一行 source + main loop 入口调用。 |
| **P1** | `lib/dispatch-ledger.sh` (NEW) | S2 | S3/S5/S7 全部依赖 dispatch_id + ledger 追踪。 |
| **P1** | `lib/queue.sh` (NEW) | S2 | 去重队列是 dispatch fabric 的另一半。 |
| **P1** | `lib/pane-lease.sh` (NEW) | S3 | Ack Contract 的前提。lease = atomic mkdir (已有先例 L950-968)。 |
| **P2** | `lib/prompt-quarantine.sh` (NEW) | S4 | 可与 S3 并行，但依赖 lease (release on quarantine)。 |
| **P2** | `lib/artifact-gate.sh` + `lib/cooldown.sh` + `lib/corrupt-isolator.sh` | S5 | 依赖 S2 ledger + S3 lease。 |
| **P3** | `lib/workflow-registry.sh` (NEW) | S6 | 依赖 S1 mapper + S2 dispatch + S5 artifact gate。 |
| **P3** | `lib/doctor.sh` (NEW) | S7 | 纯只读汇总，依赖所有前序模块存在。 |

## 2. 最大风险 (Top 5)

### RISK-1: macOS 无 `flock` — 并发原语缺失 [P0 / blocks S2,S3]

**现状**:
- macOS 没有 `flock` (util-linux)。coordinator.sh L953-968 使用 `mkdir` 做原子锁。
- S2 ledger 要求 `flock + atomic rename` 追加 jsonl。S3 lease 要求 `flock` 做 acquire/release。

**影响**: 如果直接写 `flock ...` 调用，在 macOS 上直接报错。plan §S2 stop rule 提到 "flock 10进程并发测试"。

**缓解建议**:
- 复用已有 `mkdir` 原子锁模式 (L953-968 已验证可行)
- jsonl 追加用 `mktemp + atomic mv`（先写 .tmp 再 rename）
- 测试前先检测 `command -v flock`，不可用时 fallback 到 mkdir lock
- **必须先写的测试**: 10 进程并发 append 同一 jsonl，验证无行丢失、无截断

### RISK-2: `coordinator.sh` 已 3390 行 — 主循环 ≤ 200 行约束极难达成 [P1 / design §2]

**现状**:
- 当前 3390 行，215 个 if/elif/case 分支
- 10 个 `handle_*` 函数 (L1732-L2992) 约 1260 行
- `dispatch_to_pane()` (L917 起) 约 120+ 行

**design §2 约束**: 主循环 ≤ 200 行，靠配置驱动
**design §6 约束**: S6 后主循环 if/case 分支数 = 0
**S6 stop rule**: 主循环行数 > 旧版 110% 就停

**缓解建议**:
- S6 stop rule 改为 "净新增行数 ≤ 0"（不是 ≤ 110%），因为设计目标就是缩减
- S8 删 wrapper 前先量 `wc -l`，记录到 MIGRATION.md
- 风险：如果 handle_* 抽取不干净，3390 行即使全移到 lib/ 也还是 3390 行的代码量
- **必须先写的测试**: S8 结束时 `wc -l coordinator.sh` ≤ 当前值（3390）

### RISK-3: Legacy Status 兼容 — 历史组合覆盖 [P1 / blocks S1]

**现状**:
- 当前 status.json 格式无统一 schema。字段组合 (status, phase, handoff_to) 有数十种。
- design §3.2 映射表只列了 11 种 legacy combo，但历史 sprint 可能有更多变体。
- mapper 对不可解析 status 返回 `corrupt` — 如果阈值过高，大量 sprint 被隔离。

**S1 stop rule**: 历史准确率 < 95% 就停。

**缓解建议**:
- S1 开始前先跑 `jq` 统计：对全部 `sprints/*.status.json` 提取 (status, phase, handoff_to) 三元组，列出频次。
- 用频次表扩展映射表（而非 11 种硬编码）
- **必须先写的测试**: 对所有真实 status.json 运行 mapper，统计准确率。低于 95% 时 mapper 报告每个失败的 combo。

### RISK-4: Agent 不写 Ack 文件 [P1 / blocks S3]

**现状**:
- S5 design §5.4 依赖 agent 在结束时写 `{sid}.ack-{dispatch_id}.json`。
- 当前 solar-harness.sh 的 builder/planner/judge 子命令**不产出 ack 文件**。
- 需要修改 solar-harness.sh 在主流程末尾自动产出 ack。

**影响**: 如果 agent 不写 ack → coordinator 等 300s 超时 → 所有 dispatch 都超时 → 系统假死。

**缓解建议**:
- S3 首先加 ack 写入点：在 `solar-harness.sh` 的 builder/planner/judge 子命令末尾（即使 error exit 也要产 status=failed 的 ack）
- fallback: 读 status.json `history` 中含 `dispatch_id` 的事件（design §5.4 已提到）
- **必须先写的测试**: 模拟 ack 写入 + 超时场景

### RISK-5: Phase A Dual-Read 期间决策分歧 [P2 / design §13 R-D1]

**现状**:
- Phase A 要求 mapper 和老 if/elif 同时运行，mapper 输出仅写 ledger debug，不改变决策。
- 如果两者不一致，需要 7 天 diff log 比对才能进入 Phase B。

**缓解建议**:
- S1 产出的 mapper 同时输出 `--dry-run` 模式，输出 JSON 但不影响主循环。
- 写一个 `diff_mapper_vs_legacy.sh` 脚本，对每个真实 sprint 运行两条路径，diff 结果。
- 自动化：crontab 或 coordinator `--once` 模式末尾跑 diff。

## 3. 可并行项

| Parallel Group | Stages | 前提 | 说明 |
|----------------|--------|------|------|
| **Group A** | S1 | 无 | Must go first, blocks all |
| **Group B** | S2 + S4 | S1 done | S2 (ledger+queue) 和 S4 (quarantine) 无文件冲突。S4 的 quarantine 依赖 S3 的 lease release，但 S4 的 `prompt_quarantine_check` 函数本身可独立开发。建议：先写 S4 函数，S3 接入 lease 时再接通。 |
| **Group C** | S3 | S2 done | 依赖 ledger 的 dispatch_id，不可与 S2 并行 |
| **Group D** | S5 | S2+S3 done | 依赖 ledger + lease |
| **Group E** | S6 | S1+S2+S3+S5 done | 最重依赖链 |
| **Group F** | S7 | S1-S6 done | 纯汇总，最后做 |
| **Group G** | S8 | S1-S7 done | 回归测试 + 清理 |

**实际并行度**: 如果 builder 足够，Group B (S2+S4) 可并行，节省 ~0.5d。其余为串行依赖链。

## 4. 必须先写的测试 (Test-First Priority)

### T1: `tests/test-state-mapper.sh` — S1 的门卫

**Why**: mapper 是一切决策的基础。如果 mapper 对历史 sprint 映射不准，S2-S8 全部建立在错误状态上。

**Minimum coverage**:
- 8 个 fixture (drafting, prd_ready, active/planning_complete, reviewing, passed, failed, legacy combo, corrupt)
- 每个 fixture: 输入 status.json → 断言 lifecycle_state + requested_role
- 对全部真实 `sprints/*.status.json` 运行，统计覆盖率

**Write before**: `lib/state-mapper.sh` 实现之前（先写 fixture + 期望输出）

### T2: `tests/test-dispatch-ledger.sh` — S2 的原子性守卫

**Why**: ledger 是唯一事实源。并发写入丢数据 = 整个控制系统失效。

**Minimum coverage**:
- 10 进程并发 append 100 条 → 验证 1000 行无丢失
- dispatch_id 1000 次生成无重复
- atomic rename 写入：写一半断电（模拟 kill）→ 重启后文件完整或不存在

**Write before**: `lib/dispatch-ledger.sh` 实现

### T3: `tests/test-pane-lease.sh` — S3 的互斥守卫

**Why**: 两个 dispatch_id 同时持有同一 pane = design R-D2 违规 = P0 停止。

**Minimum coverage**:
- acquire + verify exclusive
- 并发 5 进程抢同一 pane → 只 1 个成功
- release 只有 dispatch_id 匹配才成功
- TTL 过期后 lease 自动失效

**Write before**: `lib/pane-lease.sh` 实现

### T4: `tests/test-corrupt-isolator.sh` — S5 的隔离安全

**Why**: 误移正常 sprint = P0 停止。隔离必须只影响真正坏掉的文件。

**Minimum coverage**:
- 正常 status.json → 不被隔离
- 坏 JSON → 被隔离到 quarantine/ → 主循环继续
- 隔离后 doctor 能列出被隔离 sprint

**Write before**: `lib/corrupt-isolator.sh` 实现

### T5: `tests/test-dummy-workflow-e2e.sh` — S6 + S11 验收

**Why**: dummy workflow 是 "新角色不引起回归" 的唯一证据。PRD D11 要求这个。

**Minimum coverage**:
- dummy sprint → mapper 识别 → registry 返回 watchdog role → 派单 → ack → ledger 完整
- 主循环 if/case 分支数不变（diff 计数）

**Write before**: `lib/workflow-registry.sh` 实现

## 5. 基线测量 (Pre-Sprint Baseline)

记录当前状态，供 S6/S8 stop rule 对比：

| Metric | Current Value |
|--------|--------------|
| `coordinator.sh` lines | **3390** |
| `coordinator.sh` if/elif/case count | **215** |
| `handle_*` functions | **10** (L1732-L2992) |
| `dispatch_to_pane()` start line | **L917** |
| Lock mechanism | `mkdir` atomic (L953-968), no `flock` |
| `flock` available | **NO** (macOS) |
| Bash version | 5.3.9 |
| Live tmux panes | 0=PM, 1=Planner, 2=Builder, 3=Evaluator |
| Existing run/ dir contents | `prompt-quarantine/`, qmd logs, status-server files |
| Existing config/ dir | `deepseek-empty-mcp.json`, `empty-mcp.json`, `mirage.solar.yaml`, `solar-user-config.json` |
| Solar DB tables relevant | `fts_unified_search` (FTS5, contentless), 200+ other tables |

## 6. 建议 (Action Items)

1. **先跑 baseline fixture 收集**: `for f in sprints/*.status.json; do jq '{status,status,phase,handoff_to}' "$f"; done | sort | uniq -c | sort -rn` → 给 S1 mapper 扩展映射表。
2. **S1 mapper 加 `--dry-run` 模式**: Phase A dual-read 需要。在 coordinator 主循环里加一行 `map_canonical_state "$sid" >> /tmp/mapper-diff.log` 但不影响决策。
3. **S2 并发测试先于实现**: macOS 无 flock → 先验证 mkdir + atomic rename 的并发安全性，再写 ledger。
4. **S3 ack 写入点尽早加**: solar-harness.sh 的 builder/planner/judge 末尾加 trap 写 ack。这是 S3 的前提条件。
5. **S6 行数守卫**: 每次提交 coordinator.sh 改动后跑 `wc -l` + `grep -c if`，记录到 MIGRATION.md。建议用 pre-commit hook 自动检查。
6. **禁用 GLM-5.1**: plan §7 明确要求。builder model 强制 Sonnet 4.6 或 deepseek-v3。

