# Eval — sprint-20260508-coordinator-control-plane-v2

**Round**: 3
**Evaluator**: Solar 审判官 (Claude Opus 4.7)
**Mode**: Manual bash verification (@FALLBACK_MANUAL — verify-all skill not invoked, runtime not available in this evaluator session)
**Verdict**: **FAIL — partial delivery, contract scope incomplete**

---

## 总判定: FAIL

**理由**: S1+S2+S3 机制工作良好 (55/55 测试 PASS, KEY BUG FIX 已落地, 否证全部失败), 但建设者明确声明 S4-S8 未做, 14 项 DoD 中 7 项未交付。Round 3/3 最后一轮仍未达成合约范围。

**核心数据**:
- 测试套件: 4 套, 55/55 PASS (state-mapper 11 / dispatch-ledger 20 / pane-lease 9 / ack-contract 15)
- 否证尝试: 6 次, 全部按预期处理 (graceful)
- DoD 14 项: 7 PASS / 7 FAIL
- PRD D1-D12 验收点: 6 PASS / 6 FAIL

---

## DoD 14 项逐条 (合约 Definition of Done)

| # | DoD 条件 | 阶段 | 判定 | 证据 |
|---|---------|------|------|------|
| 1 | PRD 已被 Planner 消化, design.md + plan.md | Pre-S1 | PASS | status.json history 含 planner_plan_completed @ 15:58:38 |
| 2 | Canonical state mapper 覆盖 legacy combos | S1 | PASS | test-state-mapper.sh 11/11 PASS, KEY BUG FIX 通过 smoke test |
| 3 | Transition table 驱动 routing | S1 | PASS | config/coordinator-state-machine.json 含 7 transitions (≥6 required) |
| 4 | Dispatch ledger 记录每次派单 | S2 | PASS | test-dispatch-ledger.sh 20/20 PASS, dispatch_id 格式 `d-YYYYMMDDTHHMMSSZ-6hex` 验证 50/50 唯一 |
| 5 | Queue dedupe/block/retry/priority | S2 | **FAIL** | FIFO + 24h SHA256 dedup 已实现; **priority 语义未实现** (queue_enqueue 无 priority 参数) |
| 6 | Ack contract 不再依赖 capture-pane 唯一判断 | S3 | PASS | test-ack-contract.sh 15/15 PASS, ack-watcher_bg + write_ack_file 双路径 |
| 7 | Pane ownership acquire/release dispatch_id-bound | S3 | PASS | test-pane-lease.sh 9/9, T4 测试 wrong did 拒释放 |
| 8 | **Prompt quarantine inbox/ledger/marker/resolved 生命周期** | S4 | **FAIL** | 只有 1 处 marker_dir 残留, 无 inbox/resolved 流转; 建设者 handoff Not Done 章节自认 |
| 9 | **Artifact gate 推进 prd_ready/planning_complete/build_complete/done** | S5 | **FAIL** | 无 artifact_gate 实现; 建设者 handoff Not Done 自认 |
| 10 | **Cooldown 在 phase/artifact/hash 变化时失效** | S5 | **FAIL** | 无 cooldown_invalidate 实现; 建设者 handoff Not Done 自认 |
| 11 | **Corrupt status.json 隔离, 其他 sprint 继续调度** | S5 | **FAIL** | mapper 单条返回 corrupt 是 OK, 但全局隔离机制 (移走/标记/quarantine) 未做 |
| 12 | **Workflow registry 新增 dummy role 无需改 coordinator 主循环** | S6 | **FAIL** | 无 workflow_registry; 建设者 handoff Not Done 自认 |
| 13 | **coordinator doctor 输出 blocked/pane/queue/ledger/corrupt** | S7 | **FAIL** | `solar-harness coordinator doctor --json` → "未知命令: coordinator" |
| 14 | bash syntax + regression tests PASS | S1-S3+S8 | PASS (部分) | bash -n 7 文件全过, 4 套测试 55/55 PASS; 但 S4-S8 回归测试缺失 |

**PASS 7 / FAIL 7**

---

## PRD D1-D12 验收点

| # | 描述 | 判定 | 证据 |
|---|------|------|------|
| D1 | bash -n syntax | PASS | 7 文件 bash -n 全过 |
| D2 | dispatch modal + state machine tests | PASS | 11+20 = 31 PASS |
| D3 | drafting+prd_ready+handoff_to=planner → Planner (KEY BUG FIX) | PASS | smoke test 通过 (见下) |
| D4 | unrelated prompt residue quarantined | **FAIL** | quarantine 生命周期未做 |
| D5 | matched residue resumed once with ledger | **FAIL** | 同上 |
| D6 | dispatch ledger structured row per attempt | PASS | 20/20 PASS, attempted/attempted_verified/acked/nacked/ack_timeout 五种 kind |
| D7 | pane assignment dispatch_id matched | PASS | 9/9 PASS, T4 wrong-did 拒释放 |
| D8 | corrupt status isolated, doctor reports | **FAIL** | doctor 子命令未实现 |
| D9 | dummy workflow via registry, no main-loop edit | **FAIL** | registry 未做 |
| D10 | cooldown invalidates on phase/artifact/hash change | **FAIL** | 未做 |
| D11 | `solar-harness coordinator doctor --json` valid | **FAIL** | 命令不存在 |
| D12 | legacy backward compat | PASS | 否证 3 验证 drafting+intake+pm → intake/pm 仍正常 |

**PASS 6 / FAIL 6**

---

## Smoke Tests

### Smoke 1: D3 KEY BUG FIX (drafting+prd_ready+handoff_to=planner)

**cmd**:
```bash
source lib/state-mapper.sh
tmp=$(mktemp -d)
echo '{"id":"sprint-test","status":"drafting","phase":"prd_ready","handoff_to":"planner"}' > "$tmp/sprint-test.status.json"
SPRINTS_DIR="$tmp" map_canonical_state "sprint-test"
```

**stdout**:
```
{"lifecycle_state": "prd_ready", "lifecycle_role": "planner", "source_status": "drafting", "source_phase": "prd_ready", "source_handoff_to": "planner", "mapped_at": "2026-05-08T17:24:56Z", "error_hint": "legacy fix: drafting+prd_ready+planner was mis-routed to PM"}
```

**conclusion**: lifecycle_role=planner (不再是 PM), error_hint 显式声明 fix → KEY BUG FIX 落地确认。PASS

### Smoke 2: D11 doctor CLI

**cmd**:
```bash
solar-harness coordinator doctor --json
```

**stdout**:
```
[Harness] 未知命令: coordinator
```

**conclusion**: 子命令完全未实现 → D11 FAIL

### Smoke 3: 4 套测试套件运行 (handoff 声称的 55 PASS)

**cmd**:
```bash
bash tests/test-state-mapper.sh   # 11
bash tests/test-dispatch-ledger.sh # 20
bash tests/test-pane-lease.sh      # 9
bash tests/test-ack-contract.sh    # 15
```

**stdout 摘要**:
```
=== RESULT: PASS=11 FAIL=0 ===
=== RESULT: PASS=20 FAIL=0 ===
=== RESULT: PASS=9 FAIL=0 ===
=== RESULT: PASS=15 FAIL=0 ===
```

**conclusion**: 55/55 PASS 真实可信。S1-S3 机制本身测试到位。

---

## 否证 (Falsification) Attempts

按 Solar 审判官 sprint-20260423-062851 D5 协议, 每个核心 Done 至少 3 角度 否证:

### 对 D3 (mapper KEY BUG FIX)

| # | 角度 | 操作 | 结果 |
|---|------|------|------|
| 1 | empty status.json | 写空文件 → mapper | corrupt/none + parse error hint ✅ graceful |
| 2 | corrupt JSON | 写 `not json {{` | corrupt/none + parse error hint ✅ graceful |
| 3 | reverse case (NOT 该 trigger) | drafting+intake+pm | intake/pm (正确路由 PM, 未误射 planner) ✅ |
| 4 | missing file | 不存在的 sid | corrupt/none + not found hint ✅ graceful |

**结论**: 4 次 否证 全部按设计处理, mapper 鲁棒性确认。

### 对 dispatch_id 唯一性 (D6)

| # | 角度 | 结果 |
|---|------|------|
| 1 | 50 次连续生成 | 50/50 unique ✅ |
| 2 | 1000 次 (handoff 声称) | test-dispatch-ledger.sh 内验证 ✅ |

**结论**: dispatch_id 唯一性可信。

### 对 pane lease 并发 (D7)

handoff 中 T9 测试: 10 进程并发 acquire → 仅 1 成功。测试 PASS ✅。审判官未独立复测但接受 (测试源码可读, 逻辑用 flock + atomic rename, 实现机制正确)。

---

## 自动检测 (verify-all FALLBACK_MANUAL)

verify-all skill 未在本 evaluator 会话调用 (技能未挂载或不可用)。手动检测 12 项 (C1-C7 + Q1-Q5):

| # | 检查项 | 结果 |
|---|--------|------|
| C1 功能完备 | 4 套测试 55/55, 但 S4-S8 缺 | PARTIAL |
| C2 无断头 | 已交付部分有完整流转 | OK (S1-S3) |
| C3 自动触发 | coordinator.sh L63-69 source 库 | OK |
| C4 默认使用 | dispatch_to_pane 默认走新路径 | OK |
| C5 激活口令 | dispatch_id 自动生成无需口令 | OK |
| C6 错误处理 | mapper 4 角度 否证 全 graceful | OK |
| C7 持久化 | run/dispatch-ledger.jsonl 已就位 | OK |
| Q1 能跑吗 | 4 套测试通过 | YES |
| Q2 有效吗 | KEY BUG FIX 已落地 | YES |
| Q3 会退化吗 | reverse case 否证 通过 | NO regression |
| Q4 能恢复吗 | corrupt status 返回 corrupt 不 crash | YES |
| Q5 用了吗 | coordinator.sh 已 source + 调用 | YES |

**FALLBACK 原因**: verify-all 技能未在 evaluator pane 会话中调用 (审判官 dispatch 文件无具体步骤指令, 仅 wake notice)。已用手动 12 检查点 + 6 次 smoke + 6 次 否证 替代。

---

## 合约偏离 (Contract Deviation)

**严重偏离**: 合约 14 项 DoD, 实际只交付 7 项。建设者 handoff 第 153-163 行明确列出 S4-S8 为 "Not Done":

> S4: Prompt Quarantine Lifecycle
> S5: Artifact Gate + Cooldown + Corrupt Recovery
> S6: Workflow Registry + Dummy Role
> S7: Doctor CLI
> S8: Regression Tests + Migration Wrap-up

**偏离类型**: 范围缩减 (scope reduction), 非语义偏离。

**审判官立场**: 即使 S1-S3 实现质量优秀, 合约范围未达成 = FAIL。Round 3/3 是合约规定的最后一轮, 应升级到 Planner 重新规划 round 4 或拆分成 v2.1 后续 sprint。

---

## 错误清单 (eval.json errors)

| 编号 | DoD | severity | 修复指令 |
|-----|-----|----------|---------|
| E1 | DoD #5 | med | queue.sh 增加 priority 参数, queue_pop 按 priority desc + enqueue_ts asc 排序 |
| E2 | DoD #8 | high | lib/prompt-quarantine.sh: quarantine_inbox / quarantine_mark / quarantine_resolve, run/prompt-quarantine/<sid>/ 目录, ledger 集成 |
| E3 | DoD #9 | high | lib/artifact-gate.sh: 监听 prd.md/design.md/plan.md/handoff.md mtime + checksum, 触发 status 推进 |
| E4 | DoD #10 | high | lib/cooldown.sh: 记录 (sid, phase, artifact_hash) tuple, 任一变化清 cooldown |
| E5 | DoD #11 | high | sprints 目录扫描器: status.json json 检查失败 → 移到 sprints/.quarantine/ + ledger.corrupt_isolated |
| E6 | DoD #12 | high | config/workflows/<role>.json + lib/workflow-registry.sh: dispatch 时按 role 查找 workflow 而非 hardcoded if-else |
| E7 | DoD #13 | high | solar-harness.sh: 新增 `coordinator doctor --json` 子命令, 输出 blocked/pane/queue/ledger/corrupt 五个章节 |
| E8 | DoD #14 | med | tests/test-quarantine.sh, test-artifact-gate.sh, test-cooldown.sh, test-corrupt-isolation.sh, test-workflow-registry.sh, test-doctor.sh 共 6 套回归 |

---

## 下一轮路由建议 (next_round_capsule_diff)

```
当前 round=3, 已是合约 max round. 推荐路由:
1. 协调器自动: status reviewing → failed_review (round 3 → 4 可能受 max round 限制)
2. 升级 Planner: 让规划者拆分 v2.1 sprint, 把 S4-S8 + 6 套新回归测试单独成 sprint
3. 不建议在 round 4 强行让建设者补 S4-S8: 5 个独立 stage 工作量过大, 容易再次部分交付
```

如果 max round 已用完, 推荐:

- 把当前 sprint 标记为 partial PASS (mark passed-partial)
- 立即创建 follow-up sprint sprint-20260509-control-plane-v2-stage4to8
- 把 E2-E8 7 项作为新 sprint 的 DoD

---

## 关键文件清单

**已交付 (本次 PASS 部分)**:
- `lib/state-mapper.sh` (7537B)
- `lib/dispatch-ledger.sh` (3849B)
- `lib/queue.sh` (5791B)
- `lib/pane-lease.sh` (5847B)
- `lib/ack-watcher.sh` (5113B)
- `config/coordinator-state-machine.json` (5691B, 7 transitions)
- `tests/test-{state-mapper,dispatch-ledger,pane-lease,ack-contract}.sh` (4 套)
- `coordinator.sh` (lines 63-69 source, 986-1182 dispatch flow, 3411-3412 mapper log)
- `solar-harness.sh` (lines 1100-1106 ack file write)

**未交付 (本次 FAIL 部分)**:
- `lib/prompt-quarantine.sh` ❌
- `lib/artifact-gate.sh` ❌
- `lib/cooldown.sh` ❌
- `lib/corrupt-isolation.sh` ❌
- `lib/workflow-registry.sh` ❌
- `solar-harness.sh coordinator doctor` ❌
- `tests/test-{quarantine,artifact-gate,cooldown,corrupt-isolation,workflow-registry,doctor}.sh` ❌

---

*Eval written: 2026-05-08T17:25Z*
*Total smoke tests: 6 / falsification attempts: 6 / verify-all: SKIPPED → FALLBACK_MANUAL*
