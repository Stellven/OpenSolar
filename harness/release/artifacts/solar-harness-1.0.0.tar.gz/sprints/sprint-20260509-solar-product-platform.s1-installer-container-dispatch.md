# S1 Dispatch — Installer + Container Validation

Sprint: `sprint-20260509-solar-product-platform`
Role: builder

## Scope
Implement S1 only: product installer and clean container validation.

## Read First
1. `~/.solar/harness/sprints/sprint-20260509-solar-product-platform.plan.md`
2. `~/.solar/harness/sprints/sprint-20260509-solar-product-platform.contract.md`
3. `~/.solar/harness/sprints/sprint-20260509-solar-product-platform.s0-handoff.md`

## Required Work
- Build installer entrypoint and repeatable clean install path for Solar + harness.
- Add container smoke validation that proves install, command discovery, and existing harness commands still work.
- Keep secret scan constraints intact; do not touch live user data.

## Completion
Write `~/.solar/harness/sprints/sprint-20260509-solar-product-platform.s1-handoff.md`, update status history with `s1_ready_for_eval`, and do not mark the parent sprint passed.
