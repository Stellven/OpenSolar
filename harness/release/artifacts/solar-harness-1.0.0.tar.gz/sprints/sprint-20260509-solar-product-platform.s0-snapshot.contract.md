---
sid: sprint-20260509-solar-product-platform
subtask: S0-snapshot-restore-foundation
title: S0 Snapshot & Restore Foundation
priority: P0
gate: G0
owner: builder_main
status: active
created_at: 2026-05-09T03:25:00Z
---

# S0 合约: Snapshot & Restore Foundation

## Intent

实现 Solar 产品化重构前的第一道强制安全门：开发任何破坏性变更前，必须能对当前 Solar / solar-harness / skill/config 进行快照、校验和 dry-run restore。

## Scope

只做 D0，不做安装器、不做 skill 平台、不做存储迁移、不动 PDF、不改 launchd 主服务。

## Exclusive Write Scope

- `/Users/sihaoli/.solar/harness/lib/product_snapshot.py`
- `/Users/sihaoli/.solar/harness/solar-harness.sh` 只新增 `product snapshot|restore|verify` 子命令分支
- `/Users/sihaoli/.solar/harness/tests/snapshot/`
- `/Users/sihaoli/.solar/harness/backups/product-snapshots/` 目录骨架
- `/Users/sihaoli/.solar/harness/sprints/sprint-20260509-solar-product-platform.s0-handoff.md`

## Read Scope

- `/Users/sihaoli/.solar`
- `/Users/sihaoli/.solar/harness`
- `/Users/sihaoli/.claude/core/solar-farm`
- `/Users/sihaoli/.codex/skills`
- `/Users/sihaoli/.agents/skills`
- `/Users/sihaoli/.claude/skills`
- relevant config paths

## Acceptance

```text
┌──────┬────────────────────────────────────────────────────────────┐
│ ID   │ Requirement                                                │
├──────┼────────────────────────────────────────────────────────────┤
│ S0.1 │ product snapshot creates manifest.json + archive + sha256   │
│ S0.2 │ product restore --dry-run lists exact restore plan          │
│ S0.3 │ product verify validates manifest/archive hashes            │
│ S0.4 │ secrets excluded by default: .env*, *.key, *.pem, token     │
│ S0.5 │ excluded paths listed without values                        │
│ S0.6 │ sandbox round-trip test passes                              │
│ S0.7 │ existing commands still pass: doctor/status/wiki qmd status │
│ S0.8 │ no PDF/source migration, no launchd mutation                │
└──────┴────────────────────────────────────────────────────────────┘
```

## Required Verification Commands

```bash
python3 -m py_compile /Users/sihaoli/.solar/harness/lib/product_snapshot.py
bash -n /Users/sihaoli/.solar/harness/solar-harness.sh
/Users/sihaoli/.solar/harness/solar-harness.sh product snapshot --dry-run
/Users/sihaoli/.solar/harness/solar-harness.sh product snapshot --scope minimal
/Users/sihaoli/.solar/harness/solar-harness.sh product verify --latest
/Users/sihaoli/.solar/harness/solar-harness.sh product restore --latest --dry-run
/Users/sihaoli/.solar/harness/solar-harness.sh doctor
/Users/sihaoli/.solar/harness/solar-harness.sh wiki qmd-status
```

## Stop Rules

- If any plaintext secret appears in archive, manifest, logs, or stdout: stop and write incident note.
- If `solar-harness.sh` existing commands break: stop and revert only your S0 change.
- If snapshot would archive huge/raw source files by default: switch to manifest-only for data roots.
- Do not dispatch S1/S2/S6 until evaluator declares G0 PASS.

