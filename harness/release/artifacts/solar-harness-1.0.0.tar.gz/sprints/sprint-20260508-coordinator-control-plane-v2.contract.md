# Sprint Contract — sprint-20260508-coordinator-control-plane-v2

Created: 2026-05-08T15:47:15Z
Status: drafting
Priority: P0
Project: /Users/sihaoli/Documents/Playground 2

## 需求

修复 Solar Harness coordinator 的控制面缺陷：状态机不完备、派单不事务化、pane ownership 不可靠、prompt quarantine 只有局部补丁、cooldown/marker 可能断头、status corrupt 会污染调度、扩展新角色/新 workflow 必须改核心脚本。

目标是交付 Coordinator Control Plane v2：显式状态机、dispatch ledger、queue、ack contract、pane lease、quarantine lifecycle、artifact gate、workflow registry、doctor CLI 和回归测试。

## Definition of Done

- [ ] PRD 已被 Planner 消化，写出 design.md 和 plan.md。
- [ ] Canonical state mapper 覆盖 legacy status/phase/handoff_to 组合。
- [ ] Transition table 或等价配置驱动核心 routing。
- [ ] Dispatch ledger 记录每次派单尝试，含 dispatch_id。
- [ ] Queue 去重、阻塞、重试和优先级语义明确。
- [ ] Ack contract 不再依赖 capture-pane 作为唯一成功判断。
- [ ] Pane ownership acquire/release 绑定 dispatch_id。
- [ ] Prompt quarantine 有 inbox、ledger、marker、resolved 生命周期。
- [ ] Artifact gate 推动 prd_ready/planning_complete/build_complete/done。
- [ ] Cooldown 在 phase/artifact/hash 变化时自动失效。
- [ ] Corrupt status.json 被隔离，其他 sprint 继续调度。
- [ ] Workflow registry 可以新增 dummy role/workflow，无需编辑 coordinator 主循环。
- [ ] coordinator doctor 输出 blocked reason、pane ownership、queue、ledger、corrupt state。
- [ ] bash syntax tests 和新增 regression tests PASS。

## Scope

In:

- /Users/sihaoli/.solar/harness/coordinator.sh
- /Users/sihaoli/.solar/harness/solar-harness.sh
- /Users/sihaoli/.solar/harness/tests 或现有 test-*.sh
- /Users/sihaoli/.solar/harness/config 或等价 registry 目录
- /Users/sihaoli/.solar/harness/run 中 queue/ledger/ack/quarantine 运行态文件
- /Users/sihaoli/.solar/harness/sprints 中 sprint status 兼容读取

Out:

- 替换 tmux。
- 替换 Claude Code TUI。
- 重写所有历史 sprint。
- 直接完成 external integrations 业务需求。
- 引入需要网络服务的重型依赖。

## Constraints

- 保持现有 legacy sprint 可读。
- 不允许无限 C-u/Escape/backspace。
- 不允许单个坏 sprint 阻断全局调度。
- 不允许未绑定 dispatch_id 的 pane release。
- 不允许新增 workflow 时继续修改 coordinator 主循环。
- 所有新状态和失败必须能被 doctor 输出。

## Implementation Files

Planner fills exact file list.

Expected candidates:

- /Users/sihaoli/.solar/harness/coordinator.sh
- /Users/sihaoli/.solar/harness/solar-harness.sh
- /Users/sihaoli/.solar/harness/config/coordinator-state-machine.json
- /Users/sihaoli/.solar/harness/config/workflows/*.json
- /Users/sihaoli/.solar/harness/test-dispatch-modal.sh
- /Users/sihaoli/.solar/harness/test-coordinator-state-machine.sh
- /Users/sihaoli/.solar/harness/test-coordinator-doctor.sh

## Evaluation Dimensions

1. Correctness: D1-D12 from PRD pass.
2. Safety: no live pane destructive mutation beyond dispatch/quarantine rules.
3. Extensibility: dummy workflow proves registry path.
4. Observability: doctor and ledger explain blocked states.
5. Backward compatibility: legacy sprint states still route.
6. Maintainability: coordinator main loop is smaller or more declarative, not larger and more tangled.

