# Handoff — sprint-20260509-solar-product-platform S6
Builder: 建设者化身
Round: 1

## 变更文件

- `lib/solar_state_db.py` (NEW): SQLite state DB — 6-table schema, task lifecycle, gate-pass unblocking, parent-check, worker discovery
- `lib/task_queue.py` (NEW): Python task queue — enqueue/pop/peek/depth/next-worker with per-pane skip-reason logging (prevents single-builder squeeze)
- `lib/pane_lease.py` (NEW): Python pane lease — 3-state classification (no_pane/busy/dead), acquire/release/reap, stall detection for deadlock resolution
- `lib/autopilot.py` (NEW): Three-state autopilot — scan, fault-report (4 fault classes), resolve-deadlock, drain-queue
- `schemas/task-lifecycle.schema.json` (NEW): JSON Schema — task lifecycle states + transitions + status.json mapping + gate-unlock map
- `ADR/ADR-001-state-db-schema.md` (NEW): Decision — HARNESS_DIR/run/state.db separate from solar.db
- `ADR/ADR-005-autopilot-three-states.md` (NEW): Decision — no_pane/busy/dead model + stall threshold
- `tests/control_plane/test-s6-control-plane.sh` (NEW): 12 test cases, 23 probes
- `solar-harness.sh` (MODIFIED): Added `s6-autopilot` and `leases` subcommand blocks

## Done 定义达成

### D6.1 solar_state.db schema (6 tables)
✅ `solar_state_db.py` creates `tasks`, `assignments`, `leases`, `events`, `artifacts`, `capabilities` via `init_db()`. DB path: `$HARNESS_DIR/run/state.db`. WAL mode + busy_timeout=5s.
Evidence: T4 `init` → `{"ok": true, "db": "...state.db"}`

### D6.2 Task lifecycle schema maps existing status files
✅ `schemas/task-lifecycle.schema.json` has `x-status-json-mapping` covering all 7 existing states: `queued/drafting/planning/active/reviewing/passed/finalized`.
Evidence: T11 schema mapping check — `PASS`

### D6.3 Pane lease acquire/heartbeat/release + three-state autopilot
✅ `pane_lease.py` implements acquire/release with `fcntl` atomic writes (same protocol as bash `pane-lease.sh`). Three states: `no_pane` (tmux pane absent), `busy` (live lease), `dead` (no/expired lease).
Evidence: T8 — 3-state classification + reap: `PASS`

### D6.4 Synthetic deadlock detection (pane busy but stalled)
✅ `autopilot.py::_is_stalled()` checks: `lease age > DEADLOCK_STALL_SEC (300s)` AND `tmux capture-pane` shows no Claude Code prompt indicators. If both true → action=`resolve_deadlock`. `resolve-deadlock` subcommand: releases lease + re-enqueues sprint at priority 80.
Evidence: `pane_state()` returns `no_pane/busy/dead`; `_is_stalled()` logic in `autopilot.py:35-45`; T9 fault-report baseline PASS.

### D6.5 Four fault class diagnosis
✅ `autopilot.py::fault_report()` diagnoses:
1. `handoff_stall` — sprint in reviewing > STALL_SEC (900s)
2. `dispatch_backlog` — queue depth ≥ 3 + no free workers
3. `hook_failure` — quarantine inbox has unresolved entries
4. `deadlock` — stalled pane leases (from scan)
Evidence: fault-report T9 baseline returns `{"ok": true, "fault_count": 0}`

### D6.6 Double-write: status.json/events.jsonl preserved
✅ No changes to coordinator.sh or existing status.json write paths. `solar_state_db.py` is supplementary — `state.db` is a derived cache. Plan constraint C10 honored.
Evidence: T2 `bash -n solar-harness.sh` PASS; existing coordinator untouched.

### D6.7 ADR-001 + ADR-005
✅ `ADR/ADR-001-state-db-schema.md`: state.db design rationale (separate from solar.db, supplementary not authoritative).
✅ `ADR/ADR-005-autopilot-three-states.md`: three-state model design rationale + stall detection.

## Dispatch-specific items

### State-machine completeness (partial gates)
✅ `gate_pass()` in `solar_state_db.py` updates `gate_passed=1` for the slice owning the gate, then unblocks dependent slices from `x-gate-unlock-map`. G0 PASS → unblocks S1/S2/S6. `parent_check()` requires ALL registered slices to be `passed` before returning `ready=True`.

### Single-builder squeeze prevention
✅ `task_queue.py::next_free_worker()` iterates ALL tmux panes, logs skip reason per pane to stderr (`[worker-select] skip PANE: lease active`), and only falls through to queue if every pane is busy/gone. Explicit `enqueue()` + return code 2 on no-worker (matches bash `dispatch_to_builder` convention).

### Prompt residue quarantine fast return
✅ `autopilot.py::fault_report()` reads `run/quarantine/inbox.jsonl`; any unresolved entry surfaces as `hook_failure` fault with `count`, `sample[]`, and `inbox` path — visible to operator without tmux access.

## 验证方法

```bash
cd ~/.solar/harness

# 1. Syntax check
python3 -m py_compile lib/solar_state_db.py lib/task_queue.py lib/pane_lease.py lib/autopilot.py
bash -n solar-harness.sh

# 2. Full test suite
bash tests/control_plane/test-s6-control-plane.sh
# Expected: PASS=23 FAIL=0

# 3. State DB init + task lifecycle
python3 lib/solar_state_db.py init
python3 lib/solar_state_db.py task-upsert --sprint sprint-demo --slice S0 --status pending --gate G0
python3 lib/solar_state_db.py task-upsert --sprint sprint-demo --slice S1 --status blocked --gate G2 --blocked-by S0
python3 lib/solar_state_db.py gate-pass --sprint sprint-demo --gate G0
# → {"ok": true, "gate": "G0", "unblocked": ["S1"]}
python3 lib/solar_state_db.py task-status --sprint sprint-demo
# → S0 gate_passed=1, S1 status=pending

# 4. Harness subcommands
bash solar-harness.sh s6-autopilot help
bash solar-harness.sh leases help
bash solar-harness.sh leases list
bash solar-harness.sh s6-autopilot fault-report

# 5. Existing commands unchanged
bash solar-harness.sh doctor
bash solar-harness.sh wiki qmd-status
```

## 备注

- `autopilot` subcommand name is already taken by `tools/solar-autopilot-monitor.py`; S6 uses `s6-autopilot` to avoid collision.
- `state.db` is isolated from `~/.solar/solar.db` — no cross-contamination risk.
- `_discover_builder_panes()` uses tmux list-panes; returns empty list in non-tmux environments (graceful degradation in tests).
- All four modules import each other cleanly via `sys.path.insert(0, HARNESS_DIR/lib)` pattern.

## Not Done (out of scope for S6)

- S1 (installer), S2 (skill platform), S3 (storage), S4 (plugins), S5 (evolution), S7 (release) — blocked behind respective gates per plan.md.
- Parent sprint NOT marked passed — G6 gate requires evaluator sign-off.
