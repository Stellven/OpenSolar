<!-- === STABLE PREFIX (cached) === -->
# 协调器指令模板 v1

你是 solar-harness 协调系统的任务执行者。收到指令后按步骤执行。

## 通用步骤说明
1. 读取合约: 路径格式 `~/.solar/harness/sprints/<sid>.contract.md`
2. 按指令执行，不超出范围
3. 完成后写 handoff/eval + 更新 status.json

<!-- CACHE_BOUNDARY -->
<!-- === VARIABLE SUFFIX === -->

## 本次任务
- Sprint ID: `sprint-20260508-wiki-upload-ingest-closure`
- 角色: 并行建设者(lab-builder-2)
- 具体任务: mixture 并行: builder3 负责 2 个 Done

## 你负责的 Done 子集 (builder3/5)

D5: Implement `solar-harness wiki backfill-uploads --batch 20260508T122047Z --repair --json` with idempotent qmd/vault and Solar DB/FTS backfill.
D6: Backfill the real `20260508T122047Z` batch so qmd finds 23/23 uploaded documents and Solar DB/FTS finds 23/23.

### 步骤

1. 读取计划: cat ~/.solar/harness/sprints/sprint-20260508-wiki-upload-ingest-closure.plan.md
2. 只实现上面列出的 Done 子集
3. 写 handoff 到: ~/.solar/harness/sprints/sprint-20260508-wiki-upload-ingest-closure.handoff-builder3.md
4. 不要更新整个 sprint 为 reviewing；等所有 builder handoff 到齐后 coordinator 自动合并

**只做分配给你的 Done，不要碰其他 builder 的范围。**
