# S2 Eval Dispatch — Skill Lifecycle

Sprint: `sprint-20260509-solar-product-platform`
Role: evaluator

## Scope
Evaluate S2 only. Do not mark parent sprint passed unless all required slices are complete.

## Read First
1. `~/.solar/harness/sprints/sprint-20260509-solar-product-platform.s2-handoff.md`
2. `~/.solar/harness/sprints/sprint-20260509-solar-product-platform.s2-skill-lifecycle-dispatch.md`
3. `~/.solar/harness/sprints/sprint-20260509-solar-product-platform.plan.md`

## Required Checks
- Verify registry/export/eval/promote gates, namespace isolation, backup/conflict behavior, candidate/canary rejection, metrics events, tests/skills result.
- Confirm write scope isolation and no parent false finalization.

## Completion
Write `~/.solar/harness/sprints/sprint-20260509-solar-product-platform.s2-eval.md` and `~/.solar/harness/sprints/sprint-20260509-solar-product-platform.s2-eval.json`.
If S2 passes, update status history with `s2_eval_passed`; keep parent `status=active` until parent-check says all required slices passed.
