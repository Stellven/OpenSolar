# Handoff S1 — sprint-20260508-mirage-unified-vfs
Builder: 建设者化身 (Claude Sonnet 4.6, GLM pane S1 接手)
Round: 1
Slice: S1 — install/doctor/workspace/CLI/exec

## Summary

S1 fully implemented and all owned acceptance criteria (A1, A2, A3, A5-partial, A6-partial) pass.
Mirage SDK is not installed on this machine (degraded mode), but the local-only VFS layer works end-to-end.

## Changed Files

- `~/.solar/harness/config/mirage.solar.yaml`: NEW — workspace manifest with 8 mounts, policy, redact patterns
- `~/.solar/harness/lib/solar_mirage.py`: NEW ~490 lines — doctor, workspace create/status/destroy, mounts, exec (with write boundary enforcement), provision, install stub
- `~/.solar/harness/solar-harness.sh`: EDIT — added `mirage)` case (~25 lines) routing to `solar_mirage.py`; search subcmd delegates to S2's `mirage_search.py`
- `~/.solar/harness/state/mirage/`: Created directory; doctor writes `last-probe.json`; events appended to `events.jsonl` and `sprints/warn.events.jsonl`

## Architecture

```
solar-harness mirage <subcmd> [args]
        │
        ▼
solar-harness.sh  mirage) case
        │
        ▼
lib/solar_mirage.py   argparse subcommands
  ├── cmd_doctor()     → probes SDK, mounts, drive, QMD, Solar DB
  ├── cmd_workspace_*  → JSON state in state/mirage/<id>.json
  ├── cmd_mounts()     → reads config, builds per-mount readiness
  ├── cmd_exec()       → verb allowlist → write boundary → path rewrite → subprocess
  └── cmd_provision()  → dry-run path rewrite plan

config/mirage.solar.yaml
  └── 8 mounts: /knowledge /raw /sprints /solar /cortex /projects /drive /qmd

state/mirage/
  ├── solar-default.json  (workspace state)
  ├── last-probe.json     (doctor cache — read by S3 status-server)
  └── events.jsonl        (mirage_* events)
```

## Verification Evidence

```bash
# A1 — doctor JSON
python3 ~/.solar/harness/lib/solar_mirage.py doctor --json \
  | python3 -c 'import json,sys; d=json.load(sys.stdin); assert d["enabled"] and d["config"]; assert d["drive"]["status"] in ("ok","warn","degraded","disabled"); print("A1 PASS")'
# → A1 PASS  (enabled=True, config=...mirage.solar.yaml, drive=degraded)

# A2 — mounts
solar-harness mirage workspace create --id solar-default --json >/dev/null
solar-harness mirage mounts --json \
  | python3 -c 'import json,sys; d=json.load(sys.stdin); names={m["path"] for m in d["mounts"]}; assert {"/knowledge","/raw","/sprints","/solar","/cortex"}.issubset(names); print("A2 PASS")'
# → A2 PASS

# A3 — exec read commands
solar-harness mirage exec -- 'find /knowledge -name "*.md" | head' >/dev/null && echo "A3a PASS"
solar-harness mirage exec -- 'grep -R "Solar Harness" /sprints | head' >/dev/null && echo "A3b PASS"
# → A3a PASS  A3b PASS

# A5 — drive write denied
solar-harness mirage exec -- 'ls /knowledge' >/dev/null && echo "A5a PASS"
(solar-harness mirage exec -- 'echo test > /drive/solar-write-test.txt' && exit 1 || true) && echo "A5b PASS"
# → A5a PASS  A5b PASS

# A6 — write boundary
solar-harness mirage exec -- 'echo "mirage smoke" > /raw/mirage-smoke.md' && echo "A6a PASS"
(solar-harness mirage exec -- 'echo "bad" > /solar/mirage-bad.txt' && exit 1 || true) && echo "A6b PASS"
rg -n '"event".*"mirage_write_denied"' ~/.solar/harness/sprints/warn.events.jsonl >/dev/null && echo "A6c PASS"
# → A6a PASS  A6b PASS  A6c PASS

# solar-harness.sh syntax
bash -n ~/.solar/harness/solar-harness.sh && echo "syntax OK"
```

All 9 spot-checks PASS.

## Known Risks

1. **`/drive` physical=None**: gdrive mount has no physical root; resolve returns (None, entry). Write attempt caught in argv loop with `mirage_write_denied` event. Message says "path blocked or not found" rather than "drive write denied" — semantically correct but less descriptive. S3 can improve.
2. **`echo` added to allowed_verbs**: Needed for A5/A6 write-test patterns. Echo without redirect is safe; write boundary enforced at redirect target level.
3. **PyYAML dependency**: `import yaml` confirmed available on this machine. Minimal fallback parser also present but untested on the full manifest.
4. **Search subcmd stub**: `solar-harness mirage search` returns "S2 pending" error — intentional, awaiting S2 `mirage_search.py`.
5. **Status server not patched**: S3 responsibility. `last-probe.json` already written by `doctor` — S3 can read it without import.

## Not Done (by design — S2/S3 scope)

- `lib/mirage_search.py` — S2 unified search
- `lib/symphony/status-server.py` mirage section — S3
- `lib/mirage_events.py` — S3 event writer (currently inline in solar_mirage.py)
- `tests/test-mirage-unified-vfs.sh` — S3
- `docs/mirage-unified-vfs.md` — S3
- A4 unified search — S2
- A7 `/status` mirage section — S3
- A8 test suite — S3
