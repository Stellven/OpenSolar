# Handoff — sprint-20260509-solar-product-platform (S3)
Builder: 建设者化身
Round: 1

## 变更文件

- `config/storage.solar.yaml`: Storage config — migration safety defaults, drive degraded policy, qmd incremental mode
- `lib/source_manifest.py`: PDF provenance tracking — SHA-256 verified copy, atomic manifest, never deletes originals
- `lib/qmd_adapter.py`: QMD incremental rebuild adapter — wiki link check, drive status, last-build tracking
- `com.solar.mineru-idle.plist`: launchd idle worker — Background ProcessType, Nice=20, 2GB SoftResourceLimits
- `_sources/.gitkeep`: _sources root skeleton
- `_sources/papers/.gitkeep`: papers subdir
- `_sources/ingested/.gitkeep`: ingested subdir
- `tests/storage/test-s3-storage.sh`: 13-case test suite (fixed T11 || true for set -e compatibility)

## Done 定义达成

1. **D3.1 storage.solar.yaml**: ✅ `config/storage.solar.yaml` has all required keys: `sources:`, `staging:`, `migration:`, `mineru:`, `drive:`, `qmd:`. Contains `dry_run_default: true`, `require_checksum: true`, `preserve_originals: true`, `stop_on_missing_checksum: true`. T2 PASS.

2. **D3.2 source_manifest.py**: ✅ `lib/source_manifest.py` implements scan/migrate/verify/list. SHA-256 verified before copy; copy aborted on mismatch; original NEVER deleted/moved (only shutil.copy2); manifest.json written atomically (tmp → rename); dry-run by default; stop_on_missing_checksum honored. T5/T6/T7/T8 all PASS.

3. **D3.3 mirage 8 mounts**: ✅ `solar-harness mirage doctor --json` returns 8 mounts ≥ 8. T12 PASS (existing mirage.solar.yaml already had all 8 mounts: knowledge/raw/sprints/solar/cortex/projects/drive/qmd).

4. **D3.4 qmd_adapter.py drive-status degraded**: ✅ `GOOGLE_APPLICATION_CREDENTIALS="" python3 lib/qmd_adapter.py drive-status --json` returns `{"status": "degraded", "credential_present": false, ...}`. T9 PASS.

5. **D3.5 launchd plist**: ✅ `com.solar.mineru-idle.plist` — Label=`com.solar.mineru-idle`, ProcessType=`Background`, Nice=20, SoftResourceLimits with VirtualMemory=2147483648 (2GB), ThrottleInterval=60, KeepAlive on crash. T4 PASS.

6. **D3.6 _sources skeleton**: ✅ `_sources/` directory with papers/, ingested/, .gitkeep. T3 PASS.

7. **D3.7 test suite PASS**: ✅ `bash tests/storage/test-s3-storage.sh` → PASS=26 FAIL=0 EXIT=0. All 13 test cases green.

## 验证方法

```bash
cd ~/.solar/harness
bash tests/storage/test-s3-storage.sh
# Expected: === S3 Storage: PASS=26 FAIL=0 ===

# Individual smoke checks:
python3 lib/source_manifest.py scan --raw-dir /tmp/empty_raw --json
GOOGLE_APPLICATION_CREDENTIALS="" python3 lib/qmd_adapter.py drive-status --json
python3 lib/qmd_adapter.py rebuild --dry-run --json
python3 lib/solar_mirage.py doctor --json | python3 -c "import json,sys; d=json.load(sys.stdin); print(len(d['mounts']), 'mounts')"
```

## 备注

- T11 check-links required `|| true` fix because qmd_adapter check-links exits 1 on broken wiki links (real Knowledge dir has some), which killed the script under `set -e`. Fix is correct — the test verifies the field `"ok"` exists in output regardless of value.
- mirage 8 mounts (D3.3) was already satisfied by existing mirage.solar.yaml; added supplementary storage.solar.yaml rather than modifying mirage config.
- No files outside exclusive write scope were modified.
