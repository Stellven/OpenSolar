# Eval Support Report — Wiki Upload Ingest Closure

**Sprint**: sprint-20260508-wiki-upload-ingest-closure
**Reviewer**: lab-builder-2 (read-only eval support)
**Date**: 2026-05-08
**Scope**: Smoke-check evidence aggregation for evaluator. No verdict rendered.

---

## 1. Contract Acceptance Criteria Status

### A1 — Originals Preserved ✅

```
$ find /Users/sihaoli/Knowledge/_raw/file-uploads -maxdepth 1 -type f -name '20260508T122047Z-*' | wc -l
23
```

**Verdict**: PASS. 23/23 originals intact.

### A2 — Dispatch IDs Cannot Collide ⚠️ PARTIAL

**Builder1 handoff claims**: 50 parallel dispatches → 50 unique files, 14 tests pass.
**Builder4 handoff claims**: 30 assertions, 0 failures in dispatch-unique case.

**Issue detected**: The test file at `tests/test-wiki-upload-ingest-closure.sh` appears to be **builder3's 11-test version** (audit/backfill/idempotency only), NOT builder4's 30-assertion version or builder1's dispatch-unique cases. The test file header reads "B3: audit/backfill/idempotency tests".

Running the current test file:
```
$ bash tests/test-wiki-upload-ingest-closure.sh
B3 Tests: 11 passed, 0 failed
```

This covers audit/backfill/idempotency but **does not include dispatch-unique or terminal-state cases** claimed by builder1 and builder4.

**Evidence gap**: The `--case dispatch-unique` and `--case terminal-state` test cases from builder1's handoff are not present in the current file. This may be a file collision between parallel builders.

### A3 — Chained Dispatches Not Falsely Completed ⚠️ UNVERIFIABLE

**Builder1 handoff claims**: 10 tests for terminal states including chained guard.
**Current test file**: Does not contain terminal-state test cases.

**Evidence gap**: Cannot verify from current test file. The state machine changes in `obsidian-wiki-bridge.sh` exist (builder1 modified this file), but the test coverage was apparently overwritten.

### A4 — `.pages` Files Extract Or Fail Explicitly ✅

```
$ ls /Users/sihaoli/Knowledge/_raw/file-uploads/_extracted/*.extracted.txt | wc -l
23
```

**Builder2 handoff claims**: 11/11 .pages files extracted via IWA/snappy, 0 failures.
**Audit confirms**: `silent_missing = []` (0 silent misses).

**Verdict**: PASS. All 23 files have extracted artifacts, including all 11 .pages files.

### A5 — qmd Finds All 23 ✅

```
$ solar-harness wiki audit-uploads --batch 20260508T122047Z --json | python3 -c '...'
vault=23/23, solar_db=23/23, qmd=23/23, silent_missing=0
```

**Verdict**: PASS. 23/23 in qmd.

### A6 — Solar DB/FTS Finds All 23 ✅

```
$ sqlite3 ~/.solar/solar.db "SELECT COUNT(*) FROM obsidian_vault_index WHERE deleted_at IS NULL"
156
$ sqlite3 ~/.solar/solar.db "SELECT COUNT(*) FROM obsidian_vault_index WHERE deleted_at IS NULL AND file_path LIKE 'references/%'"
107
$ sqlite3 ~/.solar/solar.db "SELECT COUNT(*) FROM fts_unified_search WHERE doc_type='obsidian_vault_index'"
157
```

**Verdict**: PASS. All 23 batch files have obsidian_vault_index entries and FTS rows.

### A7 — Backfill Is Idempotent ✅

```
$ solar-harness wiki backfill-uploads --batch 20260508T122047Z --repair --json | python3 -c '...'
stubs_created=0, vault=23/23, db=23/23
```

**Verdict**: PASS. Second run creates 0 stubs, counts unchanged.

### A8 — Full Regression Suite Passes ⚠️ PARTIAL

```
$ bash tests/test-wiki-upload-ingest-closure.sh
B3 Tests: 11 passed, 0 failed
```

The test file passes, but it's only builder3's 11-test subset. It does not include:
- dispatch-unique tests (builder1's D1)
- terminal-state tests (builder1's D2)
- .pages extraction tests (builder2's D3)
- full audit tests (builder2's D4)

---

## 2. Done Checklist Status

| Done | Builder | Status | Evidence |
|------|---------|--------|----------|
| D1: Collision-proof dispatch IDs | B1 | ✅ Code in `obsidian-wiki-bridge.sh` | 14 tests claimed, but test file was overwritten |
| D2: Terminal state machine | B1 | ✅ Code in `obsidian-wiki-bridge.sh` | 10 tests claimed, but test file was overwritten |
| D3: .pages extraction | B2 | ✅ `wiki-upload-extract.py` + 23 extracted artifacts | 23/23 extracted, 0 failures |
| D4: audit-uploads command | B2 | ✅ `wiki-upload-audit.py` + CLI routing | `audit --json` returns correct counts |
| D5: backfill-uploads command | B3 | ✅ `wiki-upload-backfill.py` + CLI routing | 11 unit tests pass |
| D6: Real batch backfill | B3 | ✅ 23/23 vault + DB + qmd | Idempotent, all indexes populated |
| D7: Regression test suite | B4 | ⚠️ CLAIMED but test file shows B3 version | B4 claims 30 assertions, but file has B3's 11 |
| D8: Operator runbook | B5 | ✅ 417-line runbook at `docs/wiki-upload-ingest-closure.md` | Covers all 5 required areas |

---

## 3. Key Findings for Evaluator

### Finding 1: Test File Collision [HIGH]

**What happened**: Builder3 and Builder4 both wrote to `tests/test-wiki-upload-ingest-closure.sh`. The current file is builder3's 11-test audit/backfill version. Builder4's 30-assertion comprehensive version was overwritten.

**Impact**:
- Contract A2 (dispatch-unique) and A3 (terminal-state) have **no surviving automated test coverage**.
- The code changes for D1/D2 exist in `obsidian-wiki-bridge.sh`, but regression protection is lost.

**Recommendation for evaluator**: This is a **merge conflict** that needs resolution. Options:
1. Find builder4's version in git history and merge both test suites
2. Re-run builder4's test assertions to verify they still pass
3. Add dispatch-unique and terminal-state cases back to the test file

### Finding 2: Pending Dispatches Still Exist [MEDIUM]

**Contract says**: "No upload-related pending dispatch remains without a terminal state."

**Reality**: At least 4 batch-related dispatches are still `pending`:
- `wiki-ingest-20260508T122451Z.md` → file #14 (从超节点到微节点)
- `wiki-ingest-20260508T123223Z.md` → file #13 (google-deepmind)
- `wiki-ingest-20260508T123224Z.md` → file #22 (独家对话openai)
- `wiki-ingest-20260508T123255Z.md` → file #01 (谈谈芯片设计)

Plus ~21 non-batch pending dispatches from the same timeframe (system KB entries, session checkpoints).

**Mitigating factor**: All 23 batch files have vault references and DB entries regardless of dispatch status (builder3's backfill created stub refs for all). The pending dispatches are for the *original* chain path, which was bypassed by backfill.

**Recommendation**: Evaluator should decide whether "pending dispatches" blocks PASS or whether the backfill result (23/23 searchable) satisfies the spirit of the contract.

### Finding 3: Builder2 and Builder3 Both Created `wiki-upload-audit.py` [LOW]

Builder2 claims D4 and created `wiki-upload-audit.py`. Builder3 also created the same file for D5 (audit is a dependency of backfill). Both files exist but only one survives on disk. Need to verify which version is active and whether it covers both D4 and D5 requirements.

### Finding 4: 17 of 23 Wiki References Are Stubs [INFO]

Builder3's backfill created 17 stub wiki references with auto-extracted summaries. These stubs have `backfill: true` in frontmatter. They are searchable but lack the detailed distillation that a full wiki-ingest would produce.

This is acceptable per the contract ("idempotent upsert keyed by content hash or stable source path") but worth noting for future enrichment.

---

## 4. Smoke Test Results Summary

| Check | Expected | Actual | Status |
|-------|----------|--------|--------|
| Original file count | 23 | 23 | ✅ |
| Vault references found | 23/23 | 23/23 | ✅ |
| Solar DB indexed | 23/23 | 23/23 | ✅ |
| qmd indexed | 23/23 | 23/23 | ✅ |
| Silent .pages misses | 0 | 0 | ✅ |
| Idempotent backfill | 0 new stubs | 0 new stubs | ✅ |
| Extracted artifacts | 23 | 23 | ✅ |
| DB total rows (obsidian_vault_index) | ≥ 23 | 156 | ✅ |
| FTS total rows | ≥ 23 | 157 | ✅ |
| Test suite passes | All | 11/11 | ✅ |
| Runbook exists | Yes | 417 lines | ✅ |
| Pending batch dispatches | 0 | 4+ | ⚠️ |

---

## 5. Questions for Evaluator

1. **Test file collision**: Should the sprint be blocked until dispatch-unique and terminal-state tests are restored? Or is the code change evidence sufficient?
2. **Pending dispatches**: Does the contract's "no pending dispatch" clause apply strictly, or does 23/23 searchable coverage satisfy the intent?
3. **Stub quality**: Are 17 auto-generated stub references acceptable as "terminal artifacts" or should they be enriched before PASS?
4. **Builder2/B3 audit.py overlap**: Which version is canonical? Should both audit implementations be merged?

---

*Report generated by lab-builder-2 in read-only mode. No files were modified.*
