# Builder Dispatch S2 — Mirage unified search

Sprint: `sprint-20260508-mirage-unified-vfs`

Read:

- `/Users/sihaoli/.solar/harness/sprints/sprint-20260508-mirage-unified-vfs.contract.md`
- `/Users/sihaoli/.solar/harness/sprints/sprint-20260508-mirage-unified-vfs.design.md`
- `/Users/sihaoli/.solar/harness/sprints/sprint-20260508-mirage-unified-vfs.plan.md`

You are not alone in the codebase. Do not revert edits made by others. Do not touch current P0 sprint files.

Own only S2:

- `/Users/sihaoli/.solar/harness/lib/mirage_search.py`
- Search-related additions inside `/Users/sihaoli/.solar/harness/lib/solar_mirage.py`, coordinating with S1 output
- Do not edit `/Users/sihaoli/.solar/harness/lib/solar-knowledge-context.py`; call it if present and degrade if missing

Implement:

- `solar-harness mirage search <query> --json`
- source adapters:
  - `mirage_path`: bounded grep/find over allowed mounts
  - `qmd`: call `solar-harness wiki qmd-search "<query>" --json` if available
  - `solar_db`: call `solar-knowledge-context.py --query ... --json` if present
- normalized hits with `mount`, `path`, `source_type`, `snippet`, `provenance`, `score_or_rank`
- max 10 hits and max 4000 chars by default
- no raw full dumps into output

Do not implement S3 status/tests/docs.

Finish by writing:

`/Users/sihaoli/.solar/harness/sprints/sprint-20260508-mirage-unified-vfs.handoff-s2.md`

