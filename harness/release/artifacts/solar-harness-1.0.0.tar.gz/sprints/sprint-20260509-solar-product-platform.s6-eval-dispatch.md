# S6 Eval Dispatch — Coordinator Control Plane

Sprint: `sprint-20260509-solar-product-platform`
Role: evaluator

## Scope
Evaluate S6 only. Do not mark parent sprint passed unless S1/S2/S6 and remaining required slices are complete.

## Read First
1. `~/.solar/harness/sprints/sprint-20260509-solar-product-platform.s6-handoff.md`
2. `~/.solar/harness/sprints/sprint-20260509-solar-product-platform.s6-control-plane-dispatch.md`
3. `~/.solar/harness/sprints/sprint-20260509-solar-product-platform.plan.md`

## Required Checks
- Verify claimed files exist and tests actually pass.
- Confirm S6 fixes the observed deadheads: `g0_passed`, `slices_dispatched`, `s6_dispatched`, per-slice eval, no false parent finalization.
- Confirm queue/worker-selection behavior avoids silent single-builder squeeze and records skip reasons.

## Completion
Write `~/.solar/harness/sprints/sprint-20260509-solar-product-platform.s6-eval.md` and `~/.solar/harness/sprints/sprint-20260509-solar-product-platform.s6-eval.json`.
If S6 passes, update history with `s6_eval_passed`; keep parent `status=active` until other slices pass.
