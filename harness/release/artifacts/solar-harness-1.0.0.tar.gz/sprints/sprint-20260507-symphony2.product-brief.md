---
sprint_id: sprint-20260507-symphony2
title: Symphony 集成 Sprint 2 — workspace 4 hook 生命周期 + 强隔离 + Sprint 1 prerequisites
source: 监护人昊哥 2026-05-07 (Mission Sprint 2 启动)
predecessor: sprint-20260506-symphony1 (Sprint 1 已 PASS，已同步回 MacBook)
revision: v1
intent: |
  在 Sprint 1 (workflow-loader/scheduler/issue-adapter/workspace-manager/runner) 之上,
  为 Symphony workspace 引入 4 个标准生命周期 hook + 强隔离执行模型:
    - pre_claim_workspace  (workspace 目录创建前)
    - post_claim_workspace (workspace 就绪后，contract 写入前)
    - pre_release_workspace (sprint 结束清理前，归档 proof)
    - post_release_workspace (清理完成后，通知/审计)
  Hook 在受限环境下执行 (sandboxed env, 禁止 mutate live tmux),
  失败时按策略 fail-fast / continue 可配置.

  同时收尾 Sprint 1 留下的 P1 阻塞 (D6 CLAUDECODE guard 环境冲突) —
  没修这个，hook 真实执行路径无法在 Claude Code 嵌套环境内验证。

problem: |
  现状 (Sprint 1 完成后):
    - workspace-manager.sh 仅 create/info/show/clean 四个命令, 无 hook 钩子
    - runner.sh 无 hook 调用点, sprint 进入/退出 workspace 没有任何拦截能力
    - WORKFLOW.solar.md front matter 无 hooks: 段, workflow-loader.py 不支持解析 hooks
    - Sprint 1 D6 已知 bug: runner.sh 的 CLAUDECODE guard 在 Claude Code 嵌套环境内
      让 --dry-run exit 1, 阻塞 P1 真实执行路径验证
    - Workspace 隔离弱: hook 一旦启用, 易把 host env / secrets 泄漏给 hook 脚本
  解决:
    - 扩 WORKFLOW front matter schema 支持 hooks: 6 字段 (4 lifecycle + 全局 timeout/on_failure)
    - workspace-manager.sh + runner.sh 新增 hook 执行器 (run_hook), 注入受限 env
    - 强隔离: hook 进程仅可见白名单 env (SPRINT_ID, WORKSPACE_DIR, WORKSPACE_ROOT, 显式 allowlist)
    - 修 D6 guard: 用 SOLAR_SYMPHONY_DRY_RUN=1 替代 CLAUDECODE 检测, 嵌套环境内 dry-run exit 0
    - workflow-loader.py 解析 hooks: 段, validation 错误统一落到 WorkflowValidationError

priority: P1
priority_reason: |
  P1 而非 P0:
    - Sprint 1 已 PASS, 当前 Symphony 模块能 dry-run, 不阻塞日常 sprint
    - 但 hook 是 Symphony Workspace 真正"生命周期可干预"的核心能力,
      没有 hook 就没法做: artifact 自动归档、跨 sprint 审计、Linear 通知钩子等
    - D6 guard 不修，P1 真实执行测试会被环境拦截
    - 5-7 天工作量, 范围明确, 风险可控

lane_hint: delivery

acceptance:
  - title: WORKFLOW front matter 扩展 hooks: 段
    detail: |
      Symphony SPEC §5.3 hooks 字段，至少支持:
        hooks:
          pre_claim_workspace:  { command: "...", timeout_ms: 30000, on_failure: fail|continue }
          post_claim_workspace: { command: "...", timeout_ms: 30000, on_failure: fail }
          pre_release_workspace:  { command: "...", timeout_ms: 60000, on_failure: continue }
          post_release_workspace: { command: "...", timeout_ms: 30000, on_failure: continue }
          global_timeout_ms: 120000  # 可选，默认 60000
      workflow-loader.py 解析失败抛 WorkflowValidationError, 含字段路径.

  - title: workspace-manager.sh 新增 4 个 hook 调用点
    detail: |
      - workspace-manager.sh create <sid>:
        1. run_hook pre_claim_workspace <sid>  (失败按 on_failure 决定中止/继续)
        2. mkdir 创建 workspace 目录
        3. run_hook post_claim_workspace <sid>
      - workspace-manager.sh clean <sid>:
        1. run_hook pre_release_workspace <sid>
        2. rm -rf 清理目录
        3. run_hook post_release_workspace <sid>
      hook 在 workflow.yml 缺失对应字段时直接跳过 (no-op, exit 0).

  - title: 强隔离 (受限环境执行)
    detail: |
      run_hook 子函数:
        1. 仅注入白名单环境变量:
           SPRINT_ID, WORKSPACE_DIR, WORKSPACE_ROOT, SOLAR_SYMPHONY_HOOK_NAME, PATH
        2. 显式清空 ZHIPU_AUTH_TOKEN / ANTHROPIC_AUTH_TOKEN / 任何 *_TOKEN / *_KEY 变量
        3. 限定 cwd = $WORKSPACE_DIR (尚未创建时 = $HARNESS_DIR/sprints)
        4. timeout 用 perl alarm 或 gtimeout (macOS 兼容), 超时 SIGTERM 然后 SIGKILL
        5. stdout/stderr 落到 ~/.solar/harness/sprints/<sid>.hook-<name>.log
      白名单可通过 hooks.<name>.env_allow: ["VAR1","VAR2"] 扩展.

  - title: 修复 D6 CLAUDECODE guard 环境冲突
    detail: |
      runner.sh 当前用 CLAUDECODE 环境变量判断 "在 Claude Code 内" → exit 1.
      问题: Claude Code 嵌套终端 (开 claude 后再开 claude) 也会带 CLAUDECODE,
      导致测试用 --dry-run 时被误拦.
      修复: 改用 SOLAR_SYMPHONY_DRY_RUN=1 显式标记 dry-run, --dry-run 调用时自动设置.
      真实执行路径 (--run-codex) 仍保留 guard, 但只在 SOLAR_SYMPHONY_REAL=1 时绕过.
      acceptance: 在当前 Claude Code 会话内 runner.sh --dry-run 必须 exit 0.

  - title: 测试 (4 hook + 强隔离 + D6 修复)
    detail: |
      - test-symphony-hooks.sh:
        * pre_claim 失败 fail_on_failure → workspace 不创建, exit 1
        * pre_claim 失败 continue → workspace 创建, post_claim 仍执行
        * post_release 超时 → 触发 SIGTERM, log 含 timeout 标记
        * env 隔离: hook 内 echo $ZHIPU_AUTH_TOKEN 必须空
        * 白名单扩展: env_allow: ["FOO"] 后 hook 内可见 FOO
      - test-symphony-d6-guard.sh:
        * runner.sh --dry-run 在当前 Claude Code 内 exit 0
        * runner.sh --run-codex 不带 SOLAR_SYMPHONY_REAL=1 时 exit 1
      - 总测试: ≥ 8 用例 (4 hook + 1 隔离 + 1 白名单 + 2 D6)

  - title: 文档 + ADR 更新
    detail: |
      - docs/symphony-integration-adr.md 增补 §Hook Lifecycle Design (≥ 200 字)
      - templates/WORKFLOW.solar.md 示例 hooks: 段 (4 个 hook 各 1 例)
      - README 含: hook 执行顺序图 + 失败语义表 + 白名单机制说明

non_goals:
  - 不接 Linear webhook 作为 hook 执行体 (留给 Sprint 3)
  - 不实现 hook 之间的状态传递 (每个 hook 独立, 通过 workspace 文件通信)
  - 不在 hook 内调用 Codex/LLM (hook 是 shell 命令, 非 agent)
  - 不替换 coordinator.sh 主循环
  - 不引入 容器化 / chroot / namespace 强隔离 (env-level 即可)
  - 不强制旧 sprint 立即接入 hook (新 WORKFLOW.solar.md 用 hooks: 即可)

gates:
  gate_a:
    when: Day 2
    pass_criteria:
      - workflow-loader.py 解析 hooks: 段通过, validation error 完备
      - workspace-manager.sh create 调用 pre_claim / post_claim hook
      - D6 CLAUDECODE guard 修复, --dry-run exit 0
    judge: planner (主持) — builder 不自判
  gate_b:
    when: Day 4
    pass_criteria:
      - 4 个 hook 调用点全部接入 (create + clean)
      - 强隔离 env 白名单实现 + token 清空
      - test-symphony-hooks.sh ≥ 5 用例 PASS
      - test-symphony-d6-guard.sh 2 用例 PASS
    judge: planner (主持)
    gate_failure_consequence: |
      Gate B 未过 → Day 5-7 收缩到只修必过项, 文档 + ADR 后移

stop_rules:
  - 核心 acceptance 完成度 < 50% → 暂停并重评
  - hook 执行模型显著复杂化 (引入容器/sandbox 库) → 触发简化审查
  - 测试覆盖率 < 60% → 不放行
  - 工期 > 8 天 → 重新估算并拆 Sprint
  - Day 4 前 Gate B 未过 → 不进入文档/ADR 增强
  - 任何 Sprint 1 已通过测试出现回归 (14/14 → 失败) → 立即 STOP

deliverables:
  - ~/.solar/harness/lib/symphony/hooks.sh (新增, run_hook 实现)
  - ~/.solar/harness/lib/symphony/workspace-manager.sh (修改, 接入 hook)
  - ~/.solar/harness/lib/symphony/runner.sh (修改, D6 guard + hook 执行)
  - ~/.solar/harness/lib/symphony/workflow-loader.py (修改, 解析 hooks: 段)
  - ~/.solar/harness/templates/WORKFLOW.solar.md (修改, 含 hooks: 示例)
  - ~/.solar/harness/test-symphony-hooks.sh (新增)
  - ~/.solar/harness/test-symphony-d6-guard.sh (新增)
  - ~/.solar/harness/docs/symphony-integration-adr.md (扩展)
  - ~/.solar/harness/sprints/sprint-20260507-symphony2.eval.md (审判官 eval)

schedule:
  day_1:
    - WORKFLOW front matter hooks: schema 设计
    - workflow-loader.py 解析 hooks: 实现 + 单测
    - D6 guard 修复 (CLAUDECODE → SOLAR_SYMPHONY_DRY_RUN)
  day_2:
    - hooks.sh 实现 run_hook (env 白名单 + timeout + 日志)
    - workspace-manager.sh 接入 pre_claim / post_claim
    - Gate A
  day_3:
    - workspace-manager.sh 接入 pre_release / post_release
    - 强隔离 token 清空 + env_allow 白名单扩展
  day_4:
    - test-symphony-hooks.sh (≥ 5 用例)
    - test-symphony-d6-guard.sh (2 用例)
    - Gate B
  day_5:
    - ADR §Hook Lifecycle Design 撰写 (≥ 200 字)
    - WORKFLOW.solar.md 4 hook 示例
    - README hook 执行顺序图 + 失败语义表
  day_6:
    - 端到端 smoke: 1 个完整 sprint 全程触发 4 hook
    - 验证 Sprint 1 14/14 测试无回归
  day_7:
    - 审判官 deepseek-r1 eval
    - handoff.md + 监护人 review

crew:
  builder_main: glm-5.1
  builder_fallback: deepseek-v3
  evaluator: deepseek-r1
  gate_judge: planner

references:
  - Sprint 1 实现: ~/.solar/harness/lib/symphony/
  - Sprint 1 ADR: ~/.solar/harness/docs/symphony-integration-adr.md
  - Sprint 1 PM pre-draft: ~/.solar/harness/pm-predrafts/symphony-p1-readiness.md (D6 guard 痛点)
  - Symphony SPEC: https://github.com/openai/symphony/blob/main/SPEC.md (§5 hooks)
  - 同步教训: ~/.claude/projects/-Users-sihaoli/memory/architecture-mac-mini-symphony-sprint1-2026-05-07.md

handoff_to: planner

planner_hint: |
  本 brief 在 Sprint 1 (passed) 之上扩展 workspace 生命周期能力。
  关键约束:
    - 7 天硬上限, 工期 > 8 天必须暂停重估
    - hook env 隔离是核心，不能为方便而泄漏 token
    - D6 guard 修复是 P1 真实执行路径的前置阻塞，第一天必须修
    - Gate A (Day 2) / Gate B (Day 4) 由 planner 主持，builder 不能自判
    - 任何 Sprint 1 测试回归 → 立即 STOP
    - 不引入容器/namespace 隔离 (env-level 即可，避免范围膨胀)

  生成 sprint contract 时:
    - 派工: builder=glm-5.1 主, deepseek-v3 处理 hook 边界条件 (timeout/SIGKILL 兼容)
    - 评估: deepseek-r1 红队 (重点查 env 泄漏 + race condition)
    - 强制: 每个 acceptance 项必须含 "如何验证" 命令 (CR 题干)

  与 mac mini PM pre-draft 的关系:
    pre-draft 列出 5 个候选 (D6/Linear/Codex/scheduler/workspace),
    本 brief 选了 D6 + workspace hooks 作为 Sprint 2 焦点,
    Linear API + 真实 Codex 留给 Sprint 3 (与本 Mission 总规划吻合)。
