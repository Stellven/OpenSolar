# Handoff — Builder 1

Sprint: `sprint-20260508-wiki-upload-ingest-closure`
Builder: 1/5
Done: D1 + D2
Completed: 2026-05-08

## Summary

Implemented collision-proof dispatch IDs and terminal state machine for the wiki ingest pipeline. All 14 tests pass.

## Changed Files

| File | Action | Description |
|------|--------|-------------|
| `integrations/obsidian-wiki-bridge.sh` | **Modified** | Collision-proof `_bridge_safe_ts()`, state machine `_bridge_dispatch_set_state()`, updated all dispatch templates |
| `tests/test-wiki-upload-ingest-closure.sh` | **Created** | Test cases `dispatch-unique` (4 tests) and `terminal-state` (10 tests) |

## Done 达成

### D1: Collision-Proof Dispatch IDs ✅

**Problem**: `_bridge_safe_ts()` used `date -u '+%Y%m%dT%H%M%SZ'` (second-resolution). When 50+ dispatches created in the same second, filenames collided.

**Solution**: 
- `_bridge_safe_ts()` now uses `compgen -G` to check if ANY file with the same timestamp exists (across all action types: ingest, update, query, result files)
- Appends `-N` suffix (starting at `-2`) on collision
- Safety valve at 1000 attempts with `$$-$RANDOM` fallback

**Evidence**: Test creates 50 dispatches in rapid succession → 50 unique files (48 with collision suffixes).

### D2: Terminal Ingest State Machine ✅

**States**: `dispatched` → `running` → `completed` | `failed` | `skipped` | `chained`

**New functions**:
- `_bridge_dispatch_valid_states()`: Returns valid state list
- `_bridge_dispatch_set_state(<file> <new_state> [--force])`: Validates and applies transitions with:
  - Terminal state guard: Cannot leave terminal state without `--force`
  - Chained guard: Dispatches with `parent_dispatch:` frontmatter cannot use `completed` (must use `chained`)
  - Timestamp tracking: Appends `<state>_at: <ISO timestamp>` on each transition
  - Invalid state rejection

**Template changes**:
- All dispatch templates changed from `status: pending` to `status: dispatched`
- Added `dispatched_at:` and `target_pane:` fields to frontmatter

## Verification Evidence

```bash
$ bash tests/test-wiki-upload-ingest-closure.sh
=== Case: dispatch-unique ===
  ✅ Single dispatch creates file
  ✅ 50 dispatches create 50 unique files
  ✅ Zero duplicate file paths
  ✅ All 50 files have status=dispatched

=== Case: terminal-state ===
  ✅ All 6 states recognized
  ✅ dispatched → running
  ✅ running → completed
  ✅ Terminal state guard: blocked completed → running
  ✅ --force overrides terminal state guard
  ✅ Invalid state 'foobar' rejected
  ✅ Chained dispatch rejects 'completed', must use 'chained'
  ✅ Chained dispatch accepts 'chained' state
  ✅ dispatched → failed accepted
  ✅ dispatched → skipped accepted

Results: 14 passed, 0 failed
```

## Known Risks

1. **Performance**: `compgen -G` scans the dispatch directory on every collision check. With very large directories (1000+ files), this could be slow. Mitigated by the 1000-attempt safety valve.
2. **macOS-only sed**: The state machine uses macOS `sed -i ''` syntax. Linux fallback is included but untested.
3. **Backward compatibility**: Existing dispatch files with `status: pending` will still work — `_bridge_dispatch_set_state` reads whatever the current status is.

## Not Done

- No changes to `solar-harness.sh` dispatch routing (only `obsidian-wiki-bridge.sh` was in B1 scope)
- No `.pages` extraction (B2 scope)
- No audit/backfill (B3 scope)
- No runbook (B5 scope)
