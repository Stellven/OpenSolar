# Product Brief — sprint-20260507-obsidian-wiki

Created: 2026-05-07T20:31:16Z
Priority: P1
Lane: delivery
Source: https://github.com/Ar9av/obsidian-wiki

## Intent

Integrate `Ar9av/obsidian-wiki` into Solar Harness as a durable project memory layer. Solar should be able to install/configure the Obsidian Wiki framework, export sprint artifacts into a vault-ready raw source, trigger wiki update/ingest/query workflows, and expose wiki health through existing harness status surfaces.

This is not a fork or rewrite of obsidian-wiki. Treat upstream as an external skill framework and build a thin, non-interactive Solar integration layer around it.

## Upstream Facts

- Repository provides a markdown-skill framework for AI agents to maintain an Obsidian knowledge base.
- Setup flow writes `~/.obsidian-wiki/config`, symlinks `.skills/*` into agent skill directories, and installs global skills such as `wiki-update` and `wiki-query`.
- Core wiki pattern is `Ingest -> Extract -> Resolve -> Schema`.
- Vault structure includes `index.md`, `log.md`, `hot.md`, `.manifest.json`, `_raw/`, `projects/`, `concepts/`, `entities/`, `skills/`, `references/`, `synthesis/`, and `journal/`.
- Important skills for Solar are `wiki-setup`, `wiki-update`, `wiki-ingest`, `wiki-query`, `wiki-status`, `codex-history-ingest`, `claude-history-ingest`, `openclaw-history-ingest`, `memory-bridge`, `wiki-capture`, and `wiki-export`.

## User Outcome

After this sprint:

1. `solar-harness wiki install --vault <path>` configures obsidian-wiki without interactive prompts.
2. `solar-harness wiki status` reports repo/config/vault/skills health.
3. `solar-harness wiki export-sprint <sid>` writes a raw wiki source that summarizes contract, plan, handoff, eval, status, and events for that sprint.
4. `solar-harness wiki update [--project <path>]` runs a Solar-safe project sync handoff using obsidian-wiki skills.
5. `solar-harness wiki query "<question>"` routes a query to the compiled vault instructions.
6. Status server includes an Obsidian Wiki readiness block.

## Non-Goals

- Do not vendor-copy all upstream skill content into Solar source files.
- Do not require QMD.
- Do not require Obsidian app automation.
- Do not ingest secrets or raw full logs by default.
- Do not block Solar sprint execution if wiki integration is not configured.

## Risks

- Upstream `setup.sh` is interactive; Solar needs a non-interactive path.
- Symlinking into agent skill directories can overwrite real directories if careless.
- Sprint artifacts may contain sensitive content; export must redact or default to summaries.
- Current harness has active sprint traffic; new integration must not assume idle panes.

