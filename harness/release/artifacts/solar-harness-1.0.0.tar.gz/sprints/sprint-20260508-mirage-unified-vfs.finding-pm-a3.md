# PM Finding — A3 Sandbox Escape (Round 3 必查)

**Sprint**: sprint-20260508-mirage-unified-vfs
**Logged by**: PM dual-sign (双签 — solar 治理官签发)
**Logged at**: 2026-05-08T16:18:00Z
**Severity**: P0 (安全)
**Round**: 必须在 round 3 evaluator 验收时复现并裁定

## 现象 (PM 实测)

`solar-harness.sh mirage exec` 没有真正约束路径，host 文件可以直接通过 absolute path 读出，违反 PRD A3 与 Constraints "Mount allowlist 必须显式，禁止默认挂 /Users/sihaoli 整个家目录"。

## 复现命令 (evaluator 必跑)

```bash
bash ~/.solar/harness/solar-harness.sh mirage exec -- 'head -3 /Users/sihaoli/.zshrc'
```

## 实测结果

```
export PATH=~/.npm-global/bin:$PATH

# Java and Maven (installed by Claude Code)
```

→ exec 直接吐出 host `~/.zshrc` 内容，**没有 sandbox/chroot/路径前缀检查**。

## 对照：写保护是工作的

```
$ bash ~/.solar/harness/solar-harness.sh mirage exec -- 'echo x > /knowledge/_test.md'
ERROR: write denied to /knowledge (mode=ro)
```

写侧拒绝正确；读侧没拦。问题在读路径 dispatcher 没做 mount-prefix 校验。

## 同时发现的小 bug (建议一并修)

`mirage exec --json` 模式下，`exit_code` 在某些失败路径上返回 `null`，stderr 也没正确进 JSON 字段。raw 模式（不带 --json）可以看到错误，但 JSON 模式吞了。这影响 evaluator 自动化判定 A6。

## PM 建议的验收增量 (给 round 3 evaluator)

请在 round 3 eval 中追加以下断言（pass 才能 PASS）：

| # | 断言 | Pass 标准 |
|---|------|-----------|
| A3-1 | `mirage exec -- 'cat /Users/sihaoli/.zshrc'` | exit_code != 0 且 stderr 含 `mount not allowed` 或类似 |
| A3-2 | `mirage exec -- 'ls /etc/passwd'` | 同上 |
| A3-3 | `mirage exec --json -- 'echo x > /knowledge/x.md'` | JSON 中 exit_code != 0 且 stderr 非空 |
| A3-4 | `mirage exec -- 'find /knowledge -name "*.md" \| head'` | 仍然成功（保证不是把 exec 完全锁死） |

## 不绕过 evaluator

PM 不直接改合约 round 4。这条 finding 留给 round 3 evaluator 在跑 eval 时复核：

- 若 evaluator 复现并标记 FAIL → planner 自动开 round 4 修复（已是流程）。
- 若 evaluator 漏掉 → PM 在 review 阶段拦回。

## 信任链证据

PM 是在 host 上用真实 shell 复现的，非模拟。evaluator 在 pane 3 复跑应得到相同结果；若 pane 3 跑出 `mount not allowed` 之类拦截，说明 builder 已修，恭喜 — 但仍需在 eval.md 中写出复现命令与 stdout 作为证据。
